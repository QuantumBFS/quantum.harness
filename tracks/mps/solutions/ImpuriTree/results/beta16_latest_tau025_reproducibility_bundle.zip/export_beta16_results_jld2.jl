#!/usr/bin/env julia

using Dates
using JLD2

length(ARGS) == 2 || error("usage: export_beta16_results_jld2.jl RESULTS_ROOT OUTPUT.jld2")

const RESULTS_ROOT = abspath(ARGS[1])
const OUTPUT_PATH = abspath(ARGS[2])

function csv_rows(path)
    lines = readlines(path)
    isempty(lines) && error("empty CSV: $path")
    header = split(first(lines), ',')
    data = [split(line, ',') for line in Iterators.drop(lines, 1)]
    all(length(row) == length(header) for row in data) ||
        error("inconsistent CSV row width: $path")
    return header, data
end

function summary_dict(path)
    header, data = csv_rows(path)
    length(data) == 1 || error("expected one summary row: $path")
    return Dict(String(key) => String(value) for (key, value) in zip(header, data[1]))
end

function numeric_table(path, columns)
    header, data = csv_rows(path)
    positions = Dict(name => findfirst(==(name), header) for name in columns)
    any(isnothing, values(positions)) && error("missing requested column in $path")
    return Dict(
        name => [parse(Float64, row[positions[name]]) for row in data]
        for name in columns
    )
end

function load_case(directory)
    summary_path = only(filter(path -> endswith(path, "_summary.csv"), readdir(directory; join=true)))
    tau_path = only(filter(path -> endswith(path, "_tau.csv"), readdir(directory; join=true)))
    iw_path = only(filter(path -> endswith(path, "_iw.csv"), readdir(directory; join=true)))
    return Dict{String,Any}(
        "summary" => summary_dict(summary_path),
        "tau" => numeric_table(tau_path, ["tau", "value_real", "value_imag"]),
        "iw" => numeric_table(iw_path, ["index", "omega", "value_real", "value_imag"]),
        "source_files" => Dict(
            "summary" => basename(summary_path),
            "tau" => basename(tau_path),
            "iw" => basename(iw_path),
        ),
    )
end

u2_dir = joinpath(
    RESULTS_ROOT,
    "esprit9_beta16_u2_tdvp05_tau025_chi96_mt16_latest_49d97da",
)
u8_dir = joinpath(
    RESULTS_ROOT,
    "esprit9_beta16_u8_tdvp05_tau025_chi96_mt16_latest_49d97da",
)

isdir(u2_dir) || error("missing U=2 directory: $u2_dir")
isdir(u8_dir) || error("missing U=8 directory: $u8_dir")

cases = Dict{String,Any}(
    "u2_ed_minus1" => load_case(u2_dir),
    "u8_ed_minus4" => load_case(u8_dir),
)

metadata = Dict{String,Any}(
    "format_version" => 1,
    "description" => "9-bath SIAM beta=16 TDVP2 results",
    "beta" => 16.0,
    "tau_sampling_interval" => 0.25,
    "tdvp_max_step" => 0.5,
    "requested_max_bond_dimension" => 96,
    "julia_threads" => 16,
    "graft_commit" => "49d97da62d36f85b82faa2f508015c9a52dba1a0",
    "graftimpurity_commit" => "0a320ce85ea3529c19d619a4d22320973f7c3f7b",
    "greenfunc_commit" => "fa7b48bf7bb34e9894d7a4e6f6c0bd5d9398feb9",
    "bath_sha256" => "81a622d68dde59252b6916bf36f3a26fa512991f02ac96a63af6ff3424235978",
    "exported_at_utc" => string(now(UTC)),
)

mkpath(dirname(OUTPUT_PATH))
jldsave(OUTPUT_PATH; metadata, cases)

loaded = JLD2.load(OUTPUT_PATH)
keys(loaded) == Set(["metadata", "cases"]) ||
    Set(keys(loaded)) == Set(["metadata", "cases"]) ||
    error("unexpected top-level keys after reload")
length(loaded["cases"]) == 2 || error("expected two cases after reload")

println("JLD2_PATH=$OUTPUT_PATH")
println("JLD2_CASES=", join(sort(collect(keys(loaded["cases"]))), ","))
