# Beta=16 Green-Function Calculation Workflow Using the Latest Graft

## 1. Purpose

This workflow computes the finite-temperature impurity Green's functions

\[
G(\tau)=-\langle T_\tau d_\uparrow(\tau)d_\uparrow^\dagger(0)\rangle
\]

and \(G(i\omega_n)\) for two particle-hole-symmetric, nine-bath single-impurity Anderson models:

- \(U=2,\ \epsilon_d=-1\)
- \(U=8,\ \epsilon_d=-4\)

Only the latest isolated Graft environment is used. The previous Graft version is not part of this workflow.

## 2. Software versions and paths

The calculation uses the following fixed revisions:

| Package | Commit |
|---|---|
| Graft.jl | `49d97da62d36f85b82faa2f508015c9a52dba1a0` |
| GraftImpurity.jl | `0a320ce85ea3529c19d619a4d22320973f7c3f7b` |
| GreenFunc.jl | `fa7b48bf7bb34e9894d7a4e6f6c0bd5d9398feb9` |

Remote paths:

```text
Test root:
/lustre/ISSP2/xtng/tests/team_c_evolution

Isolated latest-Graft environment:
/lustre/ISSP2/xtng/tests/team_c_evolution/graft_latest_20260730_opt

Julia:
$HOME/apps/julia/1.12.6/bin/julia

Calculation driver:
/lustre/ISSP2/xtng/tests/team_c_evolution/scripts/gtau_iw_case.jl

Bath input:
/lustre/ISSP2/xtng/tests/team_c_evolution/inputs/esprit9_bath_stabilized_strict.csv
```

The bath-file SHA256 is:

```text
81a622d68dde59252b6916bf36f3a26fa512991f02ac96a63af6ff3424235978
```

## 3. Physical and numerical parameters

| Parameter | Value |
|---|---:|
| Number of bath sites per spin | 9 |
| Physical sites | 20 |
| Purified sites | 40 |
| Inverse temperature \(\beta\) | 16 |
| \(G(\tau)\) sampling interval | 0.25 |
| Number of \(\tau\) samples | 65 |
| TDVP maximum evolution step | 0.5 |
| Matsubara frequencies | 16 |
| Maximum bond dimension | 96 |
| TDVP algorithm | Uniform second-order two-site TDVP |
| TDVP truncation absolute tolerance | `1e-8` |
| Particle-hole symmetry | Enabled |
| Dense reference | Disabled |
| Julia threads | 16 |
| BLAS threads | 1 |

The \(G(\tau)\) sampling interval and TDVP evolution step are independent:

```text
G(tau) sampling: tau = 0, 0.25, ..., 16
TDVP maximum step: 0.5
```

Particle-hole symmetry means only the samples with \(\tau\leq\beta/2\) are propagated explicitly; the remaining samples are obtained by symmetry.

## 4. Environment verification

Connect to the iilab login node:

```bash
tssh mu01
```

Verify that Julia loads the isolated latest source tree:

```bash
ROOT=/lustre/ISSP2/xtng/tests/team_c_evolution/graft_latest_20260730_opt

JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
  "$HOME/apps/julia/1.12.6/bin/julia" \
  --startup-file=no \
  --project="$ROOT/GraftImpurity.jl" \
  -e 'using Graft, GraftImpurity, GreenFunc;
      println(pathof(Graft));
      println(pathof(GraftImpurity));
      println(pathof(GreenFunc))'
```

The printed paths must all be below `graft_latest_20260730_opt`.

## 5. PBS script for U=2, epsilon_d=-1

Save as:

```text
iilab_run_esprit9_beta16_u2_tdvp05_tau025_chi96_mt16_latest.pbs
```

```bash
#!/bin/bash
#PBS -N tc-b16u2-new
#PBS -q paraque3
#PBS -l nodes=1:ppn=16
#PBS -l walltime=10:00:00
#PBS -j oe

set -euo pipefail

TEST_ROOT="/lustre/ISSP2/xtng/tests/team_c_evolution"
RESULTS="$TEST_ROOT/results/esprit9_beta16_u2_tdvp05_tau025_chi96_mt16_latest_49d97da"
JULIA_BIN="$HOME/apps/julia/1.12.6/bin/julia"
GRAFT_ROOT="$TEST_ROOT/graft_latest_20260730_opt"
GRAFT_PROJECT="$GRAFT_ROOT/GraftImpurity.jl"

mkdir -p "$RESULTS"
cd "$TEST_ROOT"

export JULIA_NUM_THREADS=16
export OPENBLAS_NUM_THREADS=1
export TEAMC_TAU_THREADED=1
export TEAMC_NBATH=9
export TEAMC_BETA=16
export TEAMC_NTAU=65
export TEAMC_NIW=16
export TEAMC_MODEL_U=2
export TEAMC_BATH_CSV="$TEST_ROOT/inputs/esprit9_bath_stabilized_strict.csv"
export TEAMC_BATH_METHOD="esprit_rank9_stabilized_physical_real_poles"
export TEAMC_BATH_MIN_COUPLING=0.04
export TEAMC_DENSE_REFERENCE=0
export TEAMC_PH_SYMMETRY=1
export TEAMC_TDVP_DT=0.5
export TEAMC_TDVP_TRUNC_ATOL=1e-8
export TEAMC_PROFILE=esprit9_beta16_u2_tdvp05_tau025_chi96_mt16_latest_49d97da
export TEAMC_GRAFT_COMMIT=49d97da62d36f85b82faa2f508015c9a52dba1a0
export TEAMC_GRAFTIMPURITY_COMMIT=0a320ce85ea3529c19d619a4d22320973f7c3f7b
export TEAMC_GREENFUNC_COMMIT=fa7b48bf7bb34e9894d7a4e6f6c0bd5d9398feb9

echo "TEAMC_ESPRIT9_U2_TDVP05_TAU025_CHI96 job_id=${PBS_JOBID:-unknown}"
echo "TEAMC_ESPRIT9_U2_TDVP05_TAU025_CHI96 host=$(hostname)"
echo "TEAMC_ESPRIT9_U2_TDVP05_TAU025_CHI96 model_u=2 model_ed=-1"
echo "TEAMC_ESPRIT9_U2_TDVP05_TAU025_CHI96 bath_sha256=$(sha256sum "$TEAMC_BATH_CSV")"
echo "TEAMC_ESPRIT9_U2_TDVP05_TAU025_CHI96 graft=$TEAMC_GRAFT_COMMIT"
echo "TEAMC_ESPRIT9_U2_TDVP05_TAU025_CHI96 graftimpurity=$TEAMC_GRAFTIMPURITY_COMMIT"
echo "TEAMC_ESPRIT9_U2_TDVP05_TAU025_CHI96 greenfunc=$TEAMC_GREENFUNC_COMMIT"

"$JULIA_BIN" --startup-file=no \
    --project="$GRAFT_PROJECT" \
    "$TEST_ROOT/scripts/gtau_iw_case.jl" \
    tdvp2 96 16 "$TEAMC_PROFILE" "$RESULTS"
```

## 6. PBS script for U=8, epsilon_d=-4

Save as:

```text
iilab_run_esprit9_beta16_u8_tdvp05_tau025_chi96_mt16_latest.pbs
```

```bash
#!/bin/bash
#PBS -N tc-b16u8-new
#PBS -q paraque3
#PBS -l nodes=1:ppn=16
#PBS -l walltime=10:00:00
#PBS -j oe

set -euo pipefail

TEST_ROOT="/lustre/ISSP2/xtng/tests/team_c_evolution"
RESULTS="$TEST_ROOT/results/esprit9_beta16_u8_tdvp05_tau025_chi96_mt16_latest_49d97da"
JULIA_BIN="$HOME/apps/julia/1.12.6/bin/julia"
GRAFT_ROOT="$TEST_ROOT/graft_latest_20260730_opt"
GRAFT_PROJECT="$GRAFT_ROOT/GraftImpurity.jl"

mkdir -p "$RESULTS"
cd "$TEST_ROOT"

export JULIA_NUM_THREADS=16
export OPENBLAS_NUM_THREADS=1
export TEAMC_TAU_THREADED=1
export TEAMC_NBATH=9
export TEAMC_BETA=16
export TEAMC_NTAU=65
export TEAMC_NIW=16
export TEAMC_MODEL_U=8
export TEAMC_BATH_CSV="$TEST_ROOT/inputs/esprit9_bath_stabilized_strict.csv"
export TEAMC_BATH_METHOD="esprit_rank9_stabilized_physical_real_poles"
export TEAMC_BATH_MIN_COUPLING=0.04
export TEAMC_DENSE_REFERENCE=0
export TEAMC_PH_SYMMETRY=1
export TEAMC_TDVP_DT=0.5
export TEAMC_TDVP_TRUNC_ATOL=1e-8
export TEAMC_PROFILE=esprit9_beta16_u8_tdvp05_tau025_chi96_mt16_latest_49d97da
export TEAMC_GRAFT_COMMIT=49d97da62d36f85b82faa2f508015c9a52dba1a0
export TEAMC_GRAFTIMPURITY_COMMIT=0a320ce85ea3529c19d619a4d22320973f7c3f7b
export TEAMC_GREENFUNC_COMMIT=fa7b48bf7bb34e9894d7a4e6f6c0bd5d9398feb9

echo "TEAMC_ESPRIT9_U8_TDVP05_TAU025_CHI96 job_id=${PBS_JOBID:-unknown}"
echo "TEAMC_ESPRIT9_U8_TDVP05_TAU025_CHI96 host=$(hostname)"
echo "TEAMC_ESPRIT9_U8_TDVP05_TAU025_CHI96 model_u=8 model_ed=-4"
echo "TEAMC_ESPRIT9_U8_TDVP05_TAU025_CHI96 bath_sha256=$(sha256sum "$TEAMC_BATH_CSV")"
echo "TEAMC_ESPRIT9_U8_TDVP05_TAU025_CHI96 graft=$TEAMC_GRAFT_COMMIT"
echo "TEAMC_ESPRIT9_U8_TDVP05_TAU025_CHI96 graftimpurity=$TEAMC_GRAFTIMPURITY_COMMIT"
echo "TEAMC_ESPRIT9_U8_TDVP05_TAU025_CHI96 greenfunc=$TEAMC_GREENFUNC_COMMIT"

"$JULIA_BIN" --startup-file=no \
    --project="$GRAFT_PROJECT" \
    "$TEST_ROOT/scripts/gtau_iw_case.jl" \
    tdvp2 96 16 "$TEAMC_PROFILE" "$RESULTS"
```

## 7. Submission

Validate both scripts before submission:

```bash
cd /lustre/ISSP2/xtng/tests/team_c_evolution

bash -n iilab_run_esprit9_beta16_u2_tdvp05_tau025_chi96_mt16_latest.pbs
bash -n iilab_run_esprit9_beta16_u8_tdvp05_tau025_chi96_mt16_latest.pbs
```

Submit both jobs:

```bash
/opt/tsce4/torque6/bin/qsub \
  iilab_run_esprit9_beta16_u2_tdvp05_tau025_chi96_mt16_latest.pbs

/opt/tsce4/torque6/bin/qsub \
  iilab_run_esprit9_beta16_u8_tdvp05_tau025_chi96_mt16_latest.pbs
```

The submitted jobs documented here are:

```text
511.mu01  U=2, epsilon_d=-1
512.mu01  U=8, epsilon_d=-4
```

## 8. Monitoring

Check the user queue:

```bash
/opt/tsce4/torque6/bin/qstat -u "$USER"
```

Inspect resource use for one job:

```bash
/opt/tsce4/torque6/bin/qstat -f 511.mu01 |
  egrep 'Job_Name|job_state|queue =|exec_host|Resource_List.nodes|resources_used.cput|resources_used.mem|resources_used.walltime'
```

Repeat with `512.mu01` for the U=8 calculation.

The expected allocation is:

```text
queue = paraque3
nodes = 1:ppn=16
walltime limit = 10:00:00
```

## 9. Output files

Each calculation writes three CSV files into its isolated result directory:

```text
*_tau.csv
*_iw.csv
*_summary.csv
```

The result directories are:

```text
/lustre/ISSP2/xtng/tests/team_c_evolution/results/esprit9_beta16_u2_tdvp05_tau025_chi96_mt16_latest_49d97da

/lustre/ISSP2/xtng/tests/team_c_evolution/results/esprit9_beta16_u8_tdvp05_tau025_chi96_mt16_latest_49d97da
```

## 10. Acceptance checks

A job disappearing from `qstat` is not sufficient evidence of success. Verify:

1. All three CSV files exist.
2. The summary contains `beta=16`, `ntau=65`, `tdvp_dt=0.5`, and `requested_chi=96`.
3. `all_finite=true`.
4. `all_linear_solves_converged=true`.
5. `actual_max_chi <= 96`.
6. `julia_threads=16` and `blas_threads=1`.
7. The three recorded commits match the versions listed above.
8. The log contains no `ERROR`, `LoadError`, `OutOfMemory`, unexpected `NaN`, or `Inf`.
9. Particle-hole symmetry is visible numerically:

   \[
   G(\tau)\simeq G(\beta-\tau).
   \]

The primary performance value is `measured_wall_seconds` in the summary CSV. `warmup_seconds` is reported separately and should not be added to the formal measured runtime unless total end-to-end cost is being discussed.

## 11. JLD2 result bundle

The two accepted cases are also stored in:

```text
esprit9_beta16_latest_tau025_chi96.jld2
```

Top-level keys:

```text
metadata
cases
```

Case keys:

```text
u2_ed_minus1
u8_ed_minus4
```

Each case contains:

```text
summary       String-keyed summary metadata
tau           tau, value_real, and value_imag arrays
iw            index, omega, value_real, and value_imag arrays
source_files  Original CSV filenames
```

Load and inspect the file with:

```julia
using JLD2

data = JLD2.load("esprit9_beta16_latest_tau025_chi96.jld2")
metadata = data["metadata"]
u2 = data["cases"]["u2_ed_minus1"]
u8 = data["cases"]["u8_ed_minus4"]

@assert metadata["tau_sampling_interval"] == 0.25
@assert metadata["tdvp_max_step"] == 0.5
@assert length(u2["tau"]["tau"]) == 65
@assert length(u8["tau"]["tau"]) == 65
```
