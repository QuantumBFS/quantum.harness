using Test
using JSON3
using TriangularGapCertificates

const REPORT_PROBLEM_HASH = repeat("a", 64)
const REPORT_CANDIDATE_HASH = repeat("b", 64)

function fixture_record(gamma::Rational{Int}, verdict::Verdict;
                        L::Int=1, d::Int=2, rung::Symbol=:A,
                        scope::Symbol=:unrestricted,
                        accepted_hashes::Bool=true, timeout::Int=300,
                        runtime::Float64=0.1,
                        method::Union{Nothing,Symbol}=nothing,
                        problem_hash::String=REPORT_PROBLEM_HASH,
                        candidate_hash::String=REPORT_CANDIDATE_HASH)
    spec = RunSpec(1//10, gamma, L, d, rung, scope, timeout)
    if verdict == feasible
        raw = raw_status_record(:OPTIMAL, :FEASIBLE_POINT, :NO_SOLUTION,
                                runtime, Dict("fixture" => 1.0), "fixture")
        verifier_method = something(method, :primal_exact)
        details = Dict("problem_hash" => problem_hash,
                       "candidate_hash" => candidate_hash)
        accepted_hashes || delete!(details, "problem_hash")
        verification = VerificationRecord(true, verifier_method, details)
        return RunRecord(spec, raw, verification, verdict,
                         "verified_$(verifier_method)")
    elseif verdict == certified_infeasible
        raw = raw_status_record(:INFEASIBLE, :NO_SOLUTION,
                                :INFEASIBILITY_CERTIFICATE, runtime,
                                Dict("fixture" => 1.0), "fixture")
        verifier_method = something(method, :farkas_exact)
        details = Dict("problem_hash" => problem_hash,
                       "candidate_hash" => candidate_hash,
                       "certificate_hash" => candidate_hash,
                       "normalized_separation" => "-1")
        accepted_hashes || delete!(details, "certificate_hash")
        verification = VerificationRecord(true, verifier_method, details)
        return RunRecord(spec, raw, verification, verdict,
                         "verified_$(verifier_method)")
    end
    raw = raw_status_record(:TIME_LIMIT, :NO_SOLUTION, :NO_SOLUTION,
                            300.0, Dict("fixture" => 1.0), "fixture")
    verification = VerificationRecord(false, :not_checked,
                                      Dict("reason" => "fixture_unknown"))
    RunRecord(spec, raw, verification, unknown, "fixture_unknown")
end

@testset "unknown never moves a bracket" begin
    records = [
        fixture_record(0//1, feasible),
        fixture_record(1//10, unknown),
        fixture_record(1//5, certified_infeasible),
        fixture_record(3//10, certified_infeasible),
    ]
    audit = audit_monotonicity(records)
    @test length(audit.unknown_records) == 1
    @test verified_bracket(records) == (0//1, 1//5)
    @test result_tier(records) == :gold
end

@testset "nonmonotone verified outcomes are quarantined" begin
    records = [fixture_record(1//10, certified_infeasible),
               fixture_record(1//5, feasible)]
    @test_throws MonotonicityError audit_monotonicity(records)
    @test_throws MonotonicityError verified_bracket(records)
end

@testset "only independently bound verdicts enter an audit" begin
    forged = fixture_record(1//5, certified_infeasible; accepted_hashes=false)
    @test_throws ArgumentError audit_monotonicity([forged])

    raw = raw_status_record(:INFEASIBLE, :NO_SOLUTION,
                            :INFEASIBILITY_CERTIFICATE, 0.1,
                            Dict{String,Float64}(), "raw status only")
    unverified = RunRecord(RunSpec(1//10, 1//5, 1, 2, :A,
                                   :unrestricted, 300), raw,
                           VerificationRecord(false, :not_checked,
                                              Dict("reason" => "not_checked")),
                           unknown, "not_checked")
    @test verified_bracket([fixture_record(0//1, feasible), unverified]) === nothing
    @test result_tier([unverified]) == :inconclusive

    fake_acceptance = VerificationRecord(
        true, :solver_flag,
        Dict("problem_hash" => REPORT_PROBLEM_HASH,
             "candidate_hash" => REPORT_CANDIDATE_HASH))
    fake_record = RunRecord(unverified.spec, unverified.raw, fake_acceptance,
                            unknown, "raw_status_not_eligible")
    @test_throws ArgumentError audit_monotonicity([fake_record])

    valid = fixture_record(0//1, feasible)
    wrong_reason = RunRecord(valid.spec, valid.raw, valid.verification,
                             valid.verdict, "solver says feasible")
    @test_throws ArgumentError audit_monotonicity([wrong_reason])
end

@testset "result tiers are exact and unrestricted" begin
    @test result_tier([fixture_record(1//5, certified_infeasible)]) == :gold

    silver = [fixture_record(1//5, feasible),
              fixture_record(3//10, certified_infeasible)]
    @test result_tier(silver) == :silver

    baseline = [fixture_record(3//10, feasible),
                fixture_record(3//5, certified_infeasible)]
    @test result_tier(baseline) == :baseline

    @test result_tier([fixture_record(3//10, certified_infeasible)]) ==
          :inconclusive
    restricted_gold = [fixture_record(0//1, feasible),
                       fixture_record(1//5, certified_infeasible;
                                      scope=:exploratory_symmetry_restricted)]
    @test result_tier(restricted_gold) == :inconclusive
end

@testset "nested rung exclusions cannot get looser" begin
    tighter = [fixture_record(0//1, feasible; rung=:A),
               fixture_record(3//10, certified_infeasible; rung=:A),
               fixture_record(0//1, feasible; rung=:B),
               fixture_record(1//5, certified_infeasible; rung=:B)]
    @test audit_monotonicity(tighter).nested_pairs == 1

    looser = [fixture_record(0//1, feasible; rung=:A),
              fixture_record(1//5, certified_infeasible; rung=:A),
              fixture_record(0//1, feasible; rung=:B),
              fixture_record(3//10, certified_infeasible; rung=:B)]
    @test_throws MonotonicityError audit_monotonicity(looser)

    cross_verdict = [fixture_record(1//5, certified_infeasible; rung=:A),
                     fixture_record(3//10, feasible; rung=:B)]
    @test_throws MonotonicityError audit_monotonicity(cross_verdict)
end

@testset "reports separate scopes and use claim-safe wording" begin
    records = [fixture_record(0//1, feasible),
               fixture_record(1//10, unknown),
               fixture_record(1//5, certified_infeasible),
               fixture_record(1//5, certified_infeasible;
                              scope=:exploratory_symmetry_restricted)]
    duplicate_scientific_point = [
        fixture_record(1//10, feasible; timeout=240, runtime=0.2,
                       method=:primal_interval,
                       candidate_hash=repeat("c", 64)),
        fixture_record(1//10, feasible; timeout=300, runtime=0.1,
                       method=:primal_exact,
                       candidate_hash=repeat("d", 64)),
    ]
    append!(records, duplicate_scientific_point)
    mktempdir() do directory
        first = build_report(records, directory)
        markdown = read(first.markdown_path, String)
        machine = read(first.json_path, String)
        second = build_report(reverse(records), directory)
        @test read(second.markdown_path, String) == markdown
        @test read(second.json_path, String) == machine

        @test occursin("## Unrestricted results", markdown)
        @test occursin("## Exploratory symmetry-restricted appendix", markdown)
        @test occursin("this relaxation does not exclude", markdown)
        @test occursin("At relaxation (L=1, d=2, rung=A), gamma=0.20 J1 is independently certified infeasible; therefore Delta_bulk < 0.20 J1.", markdown)
        @test occursin("remains unknown and does not move the verified bracket", markdown)
        @test !occursin("the system is gapped", lowercase(markdown))
        @test !occursin("solver proves", lowercase(markdown))
        @test occursin("verification.json", markdown)
        @test occursin("problem.json", markdown)

        document = JSON3.read(machine)
        @test String(document.tier) == "gold"
        @test length(document.unrestricted) == 5
        @test length(document.exploratory_symmetry_restricted) == 1
        @test String(document.bracket.lower.numerator) == "1"
        @test String(document.bracket.lower.denominator) == "10"
        @test String(document.bracket.upper.numerator) == "1"
        @test String(document.bracket.upper.denominator) == "5"
        @test String(document.bracket.relaxation.g.numerator) == "1"
        @test String(document.bracket.relaxation.g.denominator) == "10"
        @test Int(document.bracket.relaxation.L) == 1
        @test Int(document.bracket.relaxation.d) == 2
        @test String(document.bracket.relaxation.rung) == "A"
        @test String(document.bracket.relaxation.scope) == "unrestricted"
    end
end
