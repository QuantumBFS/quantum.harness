using Test
using TriangularGapCertificates

const _RAW_FIXTURE = RawSolveRecord(:TEST, :TEST, :TEST, 0.0,
                                    Dict{String,Float64}(), "fixture")

function _hand_farkas_ray(problem; separation=-1.0, hash=canonical_hash(problem),
                          block=[1.0;;])
    FarkasCandidate(Float64[], [Matrix{Float64}(block)], separation, hash)
end

@testset "independent exact certificate verifier" begin
    positive = scalar_psd_fixture(1)
    negative = scalar_psd_fixture(-1)

    good_primal = verify_primal(positive, Float64[])
    @test good_primal.accepted
    @test good_primal.method == :primal_exact
    @test good_primal.details["problem_hash"] == canonical_hash(positive)
    @test haskey(good_primal.details, "candidate_hash")

    ray = _hand_farkas_ray(negative)
    good_ray = verify_farkas(negative, ray)
    @test good_ray.accepted
    @test good_ray.method == :farkas_exact
    @test good_ray.details["problem_hash"] == canonical_hash(negative)
    @test haskey(good_ray.details, "candidate_hash")
    @test good_ray.details["separation"] == "-1"

    bad_ray = FarkasCandidate(ray.dual_equalities, ray.dual_psd_blocks,
                              -ray.separation, ray.problem_hash)
    @test !verify_farkas(negative, bad_ray).accepted
end

@testset "exact symmetric LDLT handles singularity and reports failures" begin
    singular = Rational{BigInt}.([1 1; 1 1])
    @test exact_psd_ldlt(singular).accepted

    zero_pivot_failure = Rational{BigInt}.([0 1; 1 0])
    failed = exact_psd_ldlt(zero_pivot_failure; block_index=7)
    @test !failed.accepted
    @test failed.details["block"] == "7"
    @test failed.details["pivot"] == "1"
    @test failed.details["reason"] == "nonzero_zero_pivot_row"

    negative = Rational{BigInt}.([1 0; 0 -1//100000000])
    failed_negative = exact_psd_ldlt(negative; block_index=3)
    @test !failed_negative.accepted
    @test failed_negative.details["pivot"] == "2"
end

@testset "adversarial primal candidates are rejected" begin
    equality_problem = ConicFeasibility(
        ["x"], [([1 => 1//1], 0//1)],
        [PSDBlock(1, [(1, 1, 1//1)], AffineEntry[])],
        Dict("gamma" => "0"),
    )
    @test verify_primal(equality_problem, [0.0]).accepted
    @test verify_primal(equality_problem, [1e-8]).method == :primal_exact
    @test !verify_primal(equality_problem, [NaN]).accepted
    @test !verify_primal(equality_problem, [Inf]).accepted
    @test !verify_primal(equality_problem, Float64[]).accepted

    affine_psd = ConicFeasibility(
        ["x"], Tuple[],
        [PSDBlock(1, [(1, 1, 0//1)], [AffineEntry(1, 1, 1, 1//1)])],
        Dict("gamma" => "0"),
    )
    @test verify_primal(affine_psd, [0.0]).accepted
    @test !verify_primal(affine_psd, [-1e-8]).accepted

    wrong_hash_artifact = SolverArtifact(_RAW_FIXTURE, "wrong", Float64[],
                                          nothing, nothing, "fixture", "1")
    @test !verify_primal(scalar_psd_fixture(1), wrong_hash_artifact).accepted
end

@testset "adversarial Farkas rays are rejected" begin
    negative = scalar_psd_fixture(-1)
    ray = _hand_farkas_ray(negative)
    @test !verify_farkas(negative,
        FarkasCandidate(Float64[], Matrix{Float64}[], -1.0,
                        canonical_hash(negative))).accepted
    @test !verify_farkas(negative,
        FarkasCandidate(Float64[], [[NaN;;]], -1.0,
                        canonical_hash(negative))).accepted
    @test !verify_farkas(negative,
        FarkasCandidate(Float64[], [[Inf;;]], -1.0,
                        canonical_hash(negative))).accepted
    @test !verify_farkas(negative,
        FarkasCandidate(Float64[], [[-1e-8;;]], 1e-8,
                        canonical_hash(negative))).accepted
    @test !verify_farkas(negative,
        FarkasCandidate(Float64[], [[1.0;;]], -1.0, "wrong")).accepted

    different_gamma = ConicFeasibility(String[], Tuple[],
        [PSDBlock(1, [(1, 1, -1//1)], AffineEntry[])],
        Dict("fixture" => "scalar_psd", "gamma" => "1/10"))
    @test canonical_hash(different_gamma) != canonical_hash(negative)
    @test !verify_farkas(different_gamma, ray).accepted

    artifact = SolverArtifact(_RAW_FIXTURE, canonical_hash(negative), nothing,
                              Float64[], [[1.0;;]], "fixture", "1")
    verified = verify_farkas(negative, artifact)
    @test verified.accepted
    @test verified.details["candidate_hash"] != ""
end

@testset "candidate binding prevents persisted-record replay" begin
    problem = scalar_psd_fixture(-1)
    first = verify_farkas(problem, _hand_farkas_ray(problem))
    changed = verify_farkas(problem, _hand_farkas_ray(problem; separation=-2.0,
                                                       block=[2.0;;]))
    @test first.accepted && changed.accepted
    @test first.details["problem_hash"] == changed.details["problem_hash"]
    @test first.details["candidate_hash"] != changed.details["candidate_hash"]
    @test verification_matches(first, canonical_hash(problem),
                               first.details["candidate_hash"])
    @test !verification_matches(first, canonical_hash(problem),
                                changed.details["candidate_hash"])
end

@testset "interval fallback is conservative" begin
    @test !interval_psd_bound([1.0 0.0; 0.0 -1e-8]).accepted
    @test !interval_psd_bound([NaN;;]).accepted
end

@testset "exact RREF correction preserves deterministic free coordinates" begin
    problem = ConicFeasibility(
        ["x"], [([1 => 1//1], 0//1)],
        [PSDBlock(1, [(1, 1, -1//1)],
                  [AffineEntry(1, 1, 1, 1//1)])],
        Dict("fixture" => "correctable_farkas"),
    )
    # Identity is y + z = 0.  y is the deterministic pivot and z is free.
    corrected = verify_farkas(problem,
        FarkasCandidate([-1.0 + 2e-12], [[1.0;;]], -1.0,
                        canonical_hash(problem)))
    @test corrected.accepted
    @test corrected.method == :farkas_exact
    @test corrected.details["pivot_coordinates"] == "eq:1"
    @test corrected.details["free_coordinates"] == "psd:1:1:1"
    @test corrected.details["corrected_coordinates"] == "eq:1"

    destroyed = verify_farkas(problem,
        FarkasCandidate([1.0], [[-1.0;;]], 1.0,
                        canonical_hash(problem)))
    @test !destroyed.accepted
end

@testset "exact RREF performs later row swaps" begin
    input = Rational{BigInt}.([1 0 0; 0 0 1; 0 1 0])
    reduced, pivots = TriangularGapCertificates._exact_rref(input)
    @test reduced == Rational{BigInt}.([1 0 0; 0 1 0; 0 0 1])
    @test pivots == [1, 2, 3]
end

@testset "primal exact correction and common-box fallback" begin
    corrected_problem = ConicFeasibility(
        ["x", "y"], [([1 => 1//1], 0//1)],
        [PSDBlock(1, [(1, 1, 1//1)], AffineEntry[])],
        Dict("fixture" => "primal_correction"),
    )
    corrected = verify_primal(corrected_problem, [2e-12, 3.0])
    @test corrected.accepted
    @test corrected.method == :primal_exact
    @test corrected.details["pivot_coordinates"] == "x:1:x"
    @test corrected.details["free_coordinates"] == "x:2:y"
    @test corrected.details["corrected_coordinates"] == "x:1:x"

    threshold = BigInt(1) // BigInt(10)^14
    interval_problem = ConicFeasibility(
        ["x", "y"], [([1 => 1//1], 0//1)],
        [PSDBlock(1, [(1, 1, -threshold)],
                  [AffineEntry(1, 1, 2, 1//1)])],
        Dict("fixture" => "primal_interval"),
    )
    interval = verify_primal(interval_problem, [0.0, 1e-13])
    @test interval.accepted
    @test interval.method == :primal_interval
    @test interval.details["inclusion"] == "proved"
    @test interval.details["pivot_coordinates"] == "x:1:x"
    artifact = SolverArtifact(_RAW_FIXTURE, canonical_hash(interval_problem),
                              [0.0, 1e-13], nothing, nothing, "fixture", "1")
    @test verify_primal(interval_problem, artifact).method == :primal_interval

    inclusion_failure = verify_primal(interval_problem, [1e-8, 1e-13])
    @test !inclusion_failure.accepted
    @test inclusion_failure.method == :inconclusive_interval
    @test inclusion_failure.details["reason"] == "krawczyk_inclusion_failed"

    psd_failure = verify_primal(interval_problem, [0.0, 1e-31])
    @test !psd_failure.accepted
    @test psd_failure.method == :inconclusive_interval
end

@testset "interval fallback proves one common affine certificate box" begin
    problem = scalar_psd_fixture(-1)
    # Exact reconstruction maps this tiny ray to zero.  A 256-bit common box
    # remains strictly positive in the cone and strictly negative in separation.
    tiny = verify_farkas(problem,
        FarkasCandidate(Float64[], [[1e-13;;]], -1e-13,
                        canonical_hash(problem)))
    @test tiny.accepted
    @test tiny.method == :farkas_interval
    @test tiny.details["inclusion"] == "proved"
    @test parse(BigFloat, tiny.details["separation_upper"]) < 0

    tiny_artifact = SolverArtifact(_RAW_FIXTURE, canonical_hash(problem), nothing,
                                   Float64[], [[1e-13;;]], "fixture", "1")
    @test verify_farkas(problem, tiny_artifact).method == :farkas_interval

    crossing = verify_farkas(problem,
        FarkasCandidate(Float64[], [[1e-31;;]], -1e-31,
                        canonical_hash(problem)))
    @test !crossing.accepted
    @test crossing.method == :inconclusive_interval
end

@testset "multirow Farkas common box uses later row swap" begin
    problem = ConicFeasibility(
        ["x1", "x2", "x3"],
        [([1 => 1//1], 0//1),
         ([3 => 1//1], 0//1),
         ([2 => 1//1], 0//1)],
        [PSDBlock(1, [(1, 1, -1//1)], AffineEntry[])],
        Dict("fixture" => "farkas_later_swap"),
    )
    exact = verify_farkas(problem,
        FarkasCandidate([0.0, 2e-12, 0.0], [[1.0;;]], -1.0,
                        canonical_hash(problem)))
    @test exact.accepted
    @test exact.method == :farkas_exact
    @test exact.details["corrected_coordinates"] == "eq:2"

    tiny = verify_farkas(problem,
        FarkasCandidate([0.0, 0.0, 0.0], [[1e-13;;]], -1e-13,
                        canonical_hash(problem)))
    @test tiny.accepted
    @test tiny.method == :farkas_interval
    @test tiny.details["pivot_coordinates"] == "eq:1,eq:2,eq:3"
    @test tiny.details["free_coordinates"] == "psd:1:1:1"

    failed = verify_farkas(problem,
        FarkasCandidate([0.0, 1e-8, 0.0], [[1e-13;;]], -1e-13,
                        canonical_hash(problem)))
    @test !failed.accepted
    @test failed.method == :inconclusive_interval
    @test failed.details["reason"] == "krawczyk_inclusion_failed"
end

@testset "declared Farkas separation is diagnostic, not tolerance logic" begin
    problem = scalar_psd_fixture(-1)
    verification = verify_farkas(problem,
        FarkasCandidate(Float64[], [[1.0;;]], -1.0 + 1e-11,
                        canonical_hash(problem)))
    @test verification.accepted
    @test verification.method == :farkas_exact
    @test verification.details["separation"] == "-1"
    @test haskey(verification.details, "declared_separation")
end


@testset "matrix-vector candidate hashing is structured and order-sensitive" begin
    problem = scalar_psd_fixture(-1)
    first = verify_farkas(problem,
        FarkasCandidate(Float64[], [[1.0 0.0; 0.0 1.0]], -1.0,
                        canonical_hash(problem)))
    # Wrong dimension is rejected, but its raw structured content still gets a
    # distinct binding hash rather than falling through generic vector repr.
    second = verify_farkas(problem,
        FarkasCandidate(Float64[], [[1.0;;]], -1.0,
                        canonical_hash(problem)))
    @test first.details["candidate_hash"] != second.details["candidate_hash"]
end
