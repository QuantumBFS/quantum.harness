using Test
using JSON3
using TriangularGapCertificates

const E2E_FEASIBLE_HASH =
    "d637284712d039a759c7ae920f9726f51d89447242ac59ce7b41bec9a4ac5b29"
const E2E_INFEASIBLE_HASH =
    "6cba4d319d60b87f8b574797257c68b20acf6a6537c5698e18150ea010095733"

const E2E_FEASIBLE_FIXTURE = JSON3.read("""
{"format":"triangular-gap-recorded-fixture-v1","spec":{"constant":{"numerator":"1","denominator":"1"}},"artifact":{"problem_hash":"$E2E_FEASIBLE_HASH","primal_values":[]}}
""")
const E2E_INFEASIBLE_FIXTURE = JSON3.read("""
{"format":"triangular-gap-recorded-fixture-v1","spec":{"constant":{"numerator":"-1","denominator":"1"}},"artifact":{"problem_hash":"$E2E_INFEASIBLE_HASH","dual_equalities":[],"dual_psd_blocks":[[[1.0]]],"separation":-1.0}}
""")

function _e2e_rebuild_problem(fixture)
    String(fixture.format) == "triangular-gap-recorded-fixture-v1" ||
        throw(ArgumentError("unsupported recorded fixture format"))
    value = parse(BigInt, String(fixture.spec.constant.numerator)) //
            parse(BigInt, String(fixture.spec.constant.denominator))
    scalar_psd_fixture(value)
end

mutable struct EndToEndRecordedSolver <: AbstractSolverBackend
    calls::Int
end

function TriangularGapCertificates.solve_problem(problem::ConicFeasibility,
                                                  backend::EndToEndRecordedSolver,
                                                  ::Real)
    backend.calls += 1
    if Dict(problem.metadata)["gamma"] == "1/5"
        raw = raw_status_record(:TIME_LIMIT, :NO_SOLUTION, :NO_SOLUTION, 300.0,
                                Dict("fixture" => 1.0),
                                "recorded solver-free timeout fixture")
        return SolverArtifact(raw, canonical_hash(problem), nothing, nothing,
                              nothing, "recorded-fixture", "1")
    end
    values = zeros(length(problem.variable_names))
    normalization = findfirst(==("L(1)"), problem.variable_names)
    normalization === nothing || (values[normalization] = 1.0)
    raw = raw_status_record(:OPTIMAL, :FEASIBLE_POINT, :NO_SOLUTION, 0.125,
                            Dict("fixture" => 1.0), "recorded solver-free fixture")
    SolverArtifact(raw, canonical_hash(problem), values, nothing, nothing,
                   "recorded-fixture", "1")
end

@testset "solver-free Phase-1 end-to-end acceptance" begin
    feasible_problem = _e2e_rebuild_problem(E2E_FEASIBLE_FIXTURE)
    infeasible_problem = _e2e_rebuild_problem(E2E_INFEASIBLE_FIXTURE)
    @test canonical_hash(feasible_problem) == E2E_FEASIBLE_HASH
    @test canonical_hash(infeasible_problem) == E2E_INFEASIBLE_HASH
    @test conic_json(parse_conic_json(conic_json(feasible_problem))) ==
          conic_json(feasible_problem)
    @test conic_json(parse_conic_json(conic_json(infeasible_problem))) ==
          conic_json(infeasible_problem)

    feasible_verification = verify_primal(
        feasible_problem, Float64.(E2E_FEASIBLE_FIXTURE.artifact.primal_values))
    infeasible_artifact = E2E_INFEASIBLE_FIXTURE.artifact
    infeasible_verification = verify_farkas(
        infeasible_problem,
        FarkasCandidate(Float64.(infeasible_artifact.dual_equalities),
                        [Float64[block[row][col]
                                 for row in eachindex(block),
                                     col in eachindex(block)]
                         for block in infeasible_artifact.dual_psd_blocks],
                        Float64(infeasible_artifact.separation),
                        String(infeasible_artifact.problem_hash)))
    @test feasible_verification.accepted
    @test feasible_verification.method == :primal_exact
    @test infeasible_verification.accepted
    @test infeasible_verification.method == :farkas_exact

    mktempdir() do root
        feasible_spec = RunSpec(1//10, 0//1, 1, 0, :A,
                                :unrestricted, 300)
        solver = EndToEndRecordedSolver(0)
        persisted_feasible = run_one(feasible_spec; output_root=root, solver)
        @test solver.calls == 1
        @test persisted_feasible.verdict == feasible
        @test load_run(artifact_directory(root, feasible_spec)) == persisted_feasible

        unknown_spec = RunSpec(1//10, 1//5, 1, 0, :A,
                               :unrestricted, 300)
        persisted_unknown = run_one(unknown_spec; output_root=root, solver)
        @test solver.calls == 2
        @test persisted_unknown.verdict == unknown
        @test !persisted_unknown.verification.accepted
        @test load_run(artifact_directory(root, unknown_spec)) == persisted_unknown

        for (spec, record) in ((feasible_spec, persisted_feasible),
                               (unknown_spec, persisted_unknown))
            directory = artifact_directory(root, spec)
            @test all(name -> isfile(joinpath(directory, name)),
                      ("spec.json", "problem.json", "solver_artifact.json",
                       "verification.json", "run_record.json"))
            spec_document = JSON3.read(read(joinpath(directory, "spec.json"),
                                            String))
            loaded_spec = TriangularGapCertificates._parse_spec(spec_document)
            @test loaded_spec == spec
            rebuilt_patch = build_patch(loaded_spec.L)
            rebuilt_basis = rung_a(rebuilt_patch, loaded_spec)
            rebuilt_problem = build_gap_relaxation(rebuilt_patch,
                                                   rebuilt_basis, loaded_spec)
            stored_problem = parse_conic_json(read(joinpath(
                directory, "problem.json"), String))
            artifact_document = JSON3.read(read(joinpath(
                directory, "solver_artifact.json"), String))
            @test canonical_hash(rebuilt_problem) == canonical_hash(stored_problem)
            @test String(artifact_document.problem_hash) ==
                  canonical_hash(rebuilt_problem)
            @test load_run(directory) == record
        end

        records = [persisted_feasible, persisted_unknown]
        audit = audit_monotonicity(records)
        @test audit.unknown_records == [persisted_unknown]
        @test verified_bracket(records) === nothing
        @test result_tier(records) == :inconclusive

        report_directory = joinpath(root, "report")
        first = build_report(records, report_directory; artifact_root=root)
        markdown = read(first.markdown_path, String)
        machine = read(first.json_path, String)
        second = build_report(reverse(records), report_directory;
                              artifact_root=root)
        @test read(second.markdown_path, String) == markdown
        @test read(second.json_path, String) == machine
        report_document = JSON3.read(machine)
        @test String(report_document.tier) == "inconclusive"
        @test length(report_document.unrestricted) == 2
        @test occursin("this relaxation does not exclude", markdown)
        @test occursin("remains unknown", markdown)
        @test !occursin("therefore Delta_bulk <", markdown)
        for row in report_document.unrestricted
            @test isfile(normpath(joinpath(report_directory,
                                           String(row.problem_path))))
            @test isfile(normpath(joinpath(report_directory,
                                           String(row.certificate_path))))
        end

        run_document = JSON3.read(read(joinpath(
            artifact_directory(root, feasible_spec), "run_record.json"), String))
        @test Float64(run_document.raw.runtime_seconds) == 0.125
        @test Int(run_document.problem_sizes.variables) == 1
        @test length(run_document.problem_sizes.psd_block_dimensions) == 2
    end

    patch = build_patch(1)
    inner = rung_a(patch, 2; scope=:unrestricted)
    outer = rung_b(patch, 2; scope=:unrestricted)
    @test assert_nested(inner, outer)
    @test outer.words[1:length(inner.words)] == inner.words

    root = dirname(@__DIR__)
    for relative in ("README.md", "docs/certificate-format.md",
                     "docs/phase1-runbook.md")
        @test isfile(joinpath(root, relative))
    end
    runbook = read(joinpath(root, "docs", "phase1-runbook.md"), String)
    @test occursin("cp Manifest.toml results/phase1/environment-Manifest.toml",
                   runbook)
    @test occursin("julia --project=. scripts/run_gap_grid.jl --L 1 --d 2 --rung A --timeout 300 --output results/phase1", runbook)
    @test occursin("julia --project=. scripts/run_gap_grid.jl --L 1 --d 2 --rung B --timeout 300 --output results/phase1", runbook)
    @test occursin("julia --project=. scripts/verify_run.jl --root results/phase1 --g 1/10 --gamma 1/5 --L 1 --d 2 --rung B --scope unrestricted", runbook)
end
