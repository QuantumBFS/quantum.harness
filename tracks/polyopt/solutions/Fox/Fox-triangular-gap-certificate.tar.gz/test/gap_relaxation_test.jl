using Test
using LinearAlgebra
using TriangularGapCertificates

const GapExactComplex = Complex{Rational{BigInt}}

@testset "streamed builder is byte-identical to the dense reference" begin
    patch = build_patch(1)
    basis = rung_a(patch, 1)
    spec = RunSpec(1//10, 1//5, 1, 1, :A, :unrestricted, 300)
    dense = TriangularGapCertificates._build_gap_relaxation_dense_reference(patch, basis, spec)
    streamed = build_gap_relaxation(patch, basis, spec)

    @test conic_json(streamed) == conic_json(dense)
    @test canonical_hash(streamed) == canonical_hash(dense)
    @test all(TriangularGapCertificates._direct_moment_entry(s, t) == moment_entry(s, t)
              for s in basis.words, t in basis.words)
end

@testset "streamed realification matches the dense block and diagnoses coordinates" begin
    identity = StateMonomial()
    x = StateMonomial((StateSymbol(PauliWord([(1, :X)])),))
    y = StateMonomial((StateSymbol(PauliWord([(1, :Y)])),))
    z = StateMonomial((StateSymbol(PauliWord([(1, :Z)])),))
    p11 = StatePolynomial(identity, GapExactComplex(1))
    p12 = StatePolynomial(Dict(
        x => GapExactComplex(2//1, 3//1),
        y => GapExactComplex(-4//1, 5//1),
    ))
    p22 = StatePolynomial(z, GapExactComplex(7))
    matrix = [p11 p12; adjoint(p12) p22]
    monomials = Set{StateMonomial}()
    for polynomial in matrix, (monomial, _) in polynomial.terms
        push!(monomials, monomial)
    end
    ordered_monomials = sort!(collect(monomials);
        by=TriangularGapCertificates.state_monomial_order_key)
    names = Tuple(TriangularGapCertificates.state_variable_name(monomial)
                  for monomial in ordered_monomials)
    entry(row, col) = matrix[row, col]

    streamed = TriangularGapCertificates._streamed_realified_psd_block(2, entry, names)
    @test streamed == realified_psd_block(matrix, names)

    nonhermitian_entry(row, col) = row == 1 && col == 2 ? p12 :
                                   row == 2 && col == 1 ? p12 : matrix[row, col]
    offdiagonal_error = try
        TriangularGapCertificates._discover_hermitian_monomials!(
            Set{StateMonomial}(), 2, nonhermitian_entry)
        nothing
    catch error
        error
    end
    @test offdiagonal_error isa ArgumentError
    @test occursin("(1,2)", sprint(showerror, offdiagonal_error))

    imaginary_diagonal = StatePolynomial(x, GapExactComplex(0//1, 1//1))
    imaginary_diagonal_entry(row, col) = row == 1 && col == 1 ?
                                         imaginary_diagonal : matrix[row, col]
    diagonal_error = try
        TriangularGapCertificates._discover_hermitian_monomials!(
            Set{StateMonomial}(), 2, imaginary_diagonal_entry)
        nothing
    catch error
        error
    end
    @test diagonal_error isa ArgumentError
    @test occursin("(1,1)", sprint(showerror, diagonal_error))

    kinetic_error = try
        TriangularGapCertificates._assert_hermitian_entries(2, nonhermitian_entry)
        nothing
    catch error
        error
    end
    @test kinetic_error isa ArgumentError
    @test occursin("(1,2)", sprint(showerror, kinetic_error))
end

const SYNTHETIC_IDENTITY_MONOMIAL = StateMonomial()
const SYNTHETIC_X_MONOMIAL =
    StateMonomial((StateSymbol(PauliWord([(1, :X)])),))

function synthetic_hermitian_entry(row, col)
    identity_coefficient, x_coefficient = if row == col
        (GapExactComplex(2), GapExactComplex(-3))
    elseif row < col
        (GapExactComplex(2//1, 3//1), GapExactComplex(-4//1, 5//1))
    else
        (GapExactComplex(2//1, -3//1), GapExactComplex(-4//1, -5//1))
    end
    StatePolynomial(Dict(
        SYNTHETIC_IDENTITY_MONOMIAL => identity_coefficient,
        SYNTHETIC_X_MONOMIAL => x_coefficient,
    ))
end

function dense_discovered_block(dimension, names)
    matrix = [synthetic_hermitian_entry(row, col)
              for row in 1:dimension, col in 1:dimension]
    TriangularGapCertificates.assert_hermitian(matrix)
    monomials = TriangularGapCertificates.polynomial_monomials(matrix)
    monomials, realified_psd_block(matrix, names)
end

function streamed_discovered_block(dimension, names)
    monomials = Set{StateMonomial}()
    provisional_indices = Dict{StateMonomial,Int}()
    provisional_monomials = StateMonomial[]
    entries = TriangularGapCertificates._discover_realified_psd_entries!(
        monomials, provisional_indices, provisional_monomials,
        dimension, synthetic_hermitian_entry)
    monomials, TriangularGapCertificates._streamed_realified_psd_block(
        dimension, entries, provisional_monomials, names)
end

@testset "streamed realification reduces warm allocations" begin
    synthetic_monomials = sort!(
        [SYNTHETIC_IDENTITY_MONOMIAL, SYNTHETIC_X_MONOMIAL];
        by=TriangularGapCertificates.state_monomial_order_key)
    names = Tuple(TriangularGapCertificates.state_variable_name(monomial)
                  for monomial in synthetic_monomials)
    for dimension in (80, 120)
        dense_result = dense_discovered_block(dimension, names)
        streamed_result = streamed_discovered_block(dimension, names)

        @test streamed_result == dense_result

        dense_allocations = @allocated dense_discovered_block(dimension, names)
        streamed_allocations = @allocated streamed_discovered_block(dimension, names)

        @test streamed_allocations <= 65 * dense_allocations ÷ 100
    end
end

@testset "gap matrix formula follows S26-S28 exactly" begin
    patch = build_patch(1)
    hamiltonian = triangular_hamiltonian(patch, 1//10)
    basis = rung_a(patch, 1)
    s = basis.words[2]
    t = basis.words[3]

    kinetic = (state_polynomial(adjoint(s) * commutator(hamiltonian, t)) -
               state_polynomial(commutator(hamiltonian, adjoint(s)) * t)) / 2
    variance = moment_entry(s, t) -
               state_polynomial(adjoint(s)) * state_polynomial(t)

    @test gap_entry(s, t, hamiltonian, 0//1) == kinetic
    @test gap_entry(s, t, hamiltonian, 1//5) == kinetic - (1//5) * variance
    @test moment_entry(s, t) == state_polynomial(adjoint(s) * t)
    @test isempty(commutator(hamiltonian, NCStateMonomial((), PauliWord())).terms)
end

@testset "operator commutator remains exact" begin
    x = ExactOperator(Dict(PauliWord([(1, :X)]) => GapExactComplex(1)))
    y = ExactOperator(Dict(PauliWord([(1, :Y)]) => GapExactComplex(1)))
    expected = ExactOperator(Dict(PauliWord([(1, :Z)]) => GapExactComplex(0, 2//1)))

    @test commutator(x, y) == expected
end

@testset "state-polynomial storage is immutable and canonical" begin
    x = StateMonomial((StateSymbol(PauliWord([(1, :X)])),))
    y = StateMonomial((StateSymbol(PauliWord([(1, :Y)])),))
    first_polynomial = StatePolynomial(Dict(x => GapExactComplex(1),
                                            y => GapExactComplex(2)))
    second_polynomial = StatePolynomial(Dict(y => GapExactComplex(2),
                                             x => GapExactComplex(1)))
    nc = NCStatePolynomial(Dict(NCStateMonomial((), PauliWord([(1, :X)])) =>
                                GapExactComplex(1)))

    @test first_polynomial.terms isa Tuple
    @test nc.terms isa Tuple
    @test first_polynomial.terms == second_polynomial.terms
    @test_throws MethodError push!(first_polynomial.terms, first(first_polynomial.terms))
    @test_throws MethodError push!(nc.terms, first(nc.terms))
    @test_throws MethodError StatePolynomial(first_polynomial.terms)
    @test_throws MethodError NCStatePolynomial(nc.terms)
end

@testset "relaxation assembly is exact ordered and deterministic" begin
    patch = build_patch(1)
    basis = rung_a(patch, 1)
    spec = RunSpec(1//10, 0//1, 1, 1, :A, :unrestricted, 300)
    first_problem = build_gap_relaxation(patch, basis, spec)
    second_problem = build_gap_relaxation(patch, basis, spec)

    @test validate_conic(first_problem)
    @test canonical_hash(first_problem) == canonical_hash(second_problem)
    @test length(first_problem.psd_blocks) == 2
    @test first_problem.psd_blocks[1].dimension == 2 * length(basis.words)
    @test first_problem.psd_blocks[2].dimension ==
          2 * parse(Int, Dict(first_problem.metadata)["inner_word_count"])
    @test first_problem.equalities[1][2] == 1//1
    @test count(eq -> eq[2] == 1//1, first_problem.equalities) == 1
    @test all(entry -> entry.coefficient isa Rational{BigInt},
              Iterators.flatten(block.variable_entries for block in first_problem.psd_blocks))

    metadata = Dict(first_problem.metadata)
    @test metadata["constraint_order"] ==
          "normalization,moment_psd,stationarity_real,stationarity_imag,gap_psd"
    @test metadata["scope"] == "unrestricted"
    @test metadata["boundary_condition"] == "open_outer_patch"
    @test parse(Int, metadata["inner_word_count"]) > 0
    @test parse(Int, metadata["skipped_word_count"]) > 0
    @test metadata["gamma"] == "0/1"
    @test metadata["closure_method"] == "exact_halo_commutator"
    @test metadata["open_hamiltonian_match"] == "true"
    @test occursin("generated_operator=", metadata["skipped_words"])
    @test occursin("outside_coordinates=", metadata["skipped_words"])
end

@testset "gamma zero gap block is the exact kinetic realification" begin
    patch = build_patch(1)
    basis = rung_a(patch, 1)
    hamiltonian = triangular_hamiltonian(patch, 1//10)
    spec = RunSpec(1//10, 0//1, 1, 1, :A, :unrestricted, 300)
    inner = (basis.words[1],)
    problem = build_gap_relaxation(patch, basis, spec; requested_inner_words=inner)
    kinetic = [gap_entry(s, t, hamiltonian, 0//1) for s in inner, t in inner]

    @test problem.psd_blocks[2] == realified_psd_block(kinetic, problem.variable_names)
end


@testset "exact halo commutator rejects a generated crossing term" begin
    patch = build_patch(1)
    boundary_index = patch.index[Axial(1, 0)]
    boundary = NCStateMonomial((), PauliWord([(boundary_index, :X)]))
    identity = NCStateMonomial((), PauliWord())
    basis = RelaxationBasis(:A, :unrestricted, (identity, boundary))
    spec = RunSpec(1//10, 0//1, 1, 1, :A, :unrestricted, 300)
    problem = build_gap_relaxation(patch, basis, spec)
    metadata = Dict(problem.metadata)

    @test metadata["inner_word_count"] == "1"
    @test metadata["skipped_word_count"] == "1"
    @test problem.psd_blocks[1].dimension == 4
    @test problem.psd_blocks[2].dimension == 2
    @test occursin("outside_coordinates=", metadata["skipped_words"])
    @test occursin("generated_operator=", metadata["skipped_words"])
    @test_throws ArgumentError build_gap_relaxation(
        patch, basis, spec; requested_inner_words=(boundary,))
end

@testset "stationarity equalities group real before imaginary parts" begin
    patch = build_patch(2)
    center_index = patch.index[Axial(0, 0)]
    center = NCStateMonomial((), PauliWord([(center_index, :X)]))
    identity = NCStateMonomial((), PauliWord())
    basis = RelaxationBasis(:A, :unrestricted, (center, identity))
    spec = RunSpec(1//10, 0//1, 2, 1, :A, :unrestricted, 300)
    problem = build_gap_relaxation(
        patch, basis, spec; requested_inner_words=(center, identity))

    @test length(problem.equalities) == 5
    @test isempty(problem.equalities[2][1])
    @test isempty(problem.equalities[3][1])
    @test !isempty(problem.equalities[4][1])
    @test isempty(problem.equalities[5][1])
end

@testset "explicit partially supported inner words are rejected" begin
    patch = build_patch(1)
    basis = rung_a(patch, 1)
    boundary_word = first(filter(word -> !isempty(word.operator_word.factors), basis.words))
    spec = RunSpec(1//10, 0//1, 1, 1, :A, :unrestricted, 300)

    @test_throws ArgumentError build_gap_relaxation(
        patch, basis, spec; requested_inner_words=(boundary_word,))
end

function direct_expectation(monomial::StateMonomial, psi, site_count, cache)
    prod((get!(cache, symbol.word) do
                 real(dot(psi, dense_matrix(ExactOperator(Dict(symbol.word => GapExactComplex(1))),
                                             site_count) * psi))
             end for symbol in monomial.symbols); init=1.0)
end

function evaluate_polynomial(polynomial::StatePolynomial, psi, site_count, cache)
    sum((ComplexF64(coefficient) * direct_expectation(monomial, psi, site_count, cache)
         for (monomial, coefficient) in polynomial.terms); init=0.0 + 0.0im)
end

function evaluate_psd_block(block::PSDBlock, values)
    matrix = zeros(Float64, block.dimension, block.dimension)
    for (row, col, coefficient) in block.constant_entries
        matrix[row, col] += Float64(coefficient)
    end
    for entry in block.variable_entries
        matrix[entry.row, entry.col] += Float64(entry.coefficient) * values[entry.variable]
    end
    matrix + triu(matrix, 1)'
end

@testset "seven-site open-H eigenvector diagnostic" begin
    patch = build_patch(1)
    hamiltonian = triangular_hamiltonian(patch, 1//10)
    matrix = independent_ed_matrix(patch, 1//10)
    decomposition = eigen(Hermitian(matrix))
    psi = decomposition.vectors[:, 1]
    basis = rung_a(patch, 1)
    count_sites = length(patch.sites)
    cache = Dict{PauliWord,Float64}()
    inner_words, _, _, _ = TriangularGapCertificates.buffered_inner_words(
        patch, basis, hamiltonian)

    stationarity = [evaluate_polynomial(state_polynomial(commutator(hamiltonian, word)),
                                        psi, count_sites, cache) for word in basis.words]
    moment = [evaluate_polynomial(moment_entry(s, t), psi, count_sites, cache)
              for s in basis.words, t in basis.words]
    kinetic = [evaluate_polynomial(gap_entry(s, t, hamiltonian, 0//1), psi, count_sites, cache)
               for s in inner_words, t in inner_words]

    spec = RunSpec(1//10, 0//1, 1, 1, :A, :unrestricted, 300)
    problem = build_gap_relaxation(patch, basis, spec)
    symbolic_entries = StatePolynomial[]
    append!(symbolic_entries, vec([moment_entry(s, t) for s in basis.words, t in basis.words]))
    append!(symbolic_entries,
            vec([gap_entry(s, t, hamiltonian, 0//1) for s in inner_words, t in inner_words]))
    append!(symbolic_entries,
            [state_polynomial(commutator(hamiltonian, word)) for word in inner_words])
    monomial_by_name = Dict("L(1)" => StateMonomial())
    for polynomial in symbolic_entries, (monomial, _) in polynomial.terms
        monomial_by_name[TriangularGapCertificates.state_variable_name(monomial)] = monomial
    end
    values = [direct_expectation(monomial_by_name[name], psi, count_sites, cache)
              for name in problem.variable_names]
    equality_residuals = [
        sum(Float64(coefficient) * values[index] for (index, coefficient) in coefficients;
            init=0.0) - Float64(rhs)
        for (coefficients, rhs) in problem.equalities
    ]
    psd_values = evaluate_psd_block.(problem.psd_blocks, Ref(values))

    @test maximum(abs, stationarity) < 1e-10
    @test norm(moment - moment') < 1e-10
    @test norm(kinetic - kinetic') < 1e-10
    @test eigmin(Hermitian(moment)) > -1e-10
    @test eigmin(Hermitian(kinetic)) > -1e-10
    @test maximum(abs, equality_residuals) < 1e-10
    @test all(block -> eigmin(Hermitian(block)) > -1e-10, psd_values)
    @test Dict(problem.metadata)["diagnostic_scope"] ==
          "finite_open_patch_checks_do_not_imply_thermodynamic_claims"
end
