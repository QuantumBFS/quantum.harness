using Test
using JSON3
using SHA
using TriangularGapCertificates

function _write_cli_fixture(directory)
    problem = scalar_psd_fixture(-1)
    write(joinpath(directory, "problem.json"), conic_json(problem))
    artifact = (
        format="triangular-gap-solver-artifact-v1",
        problem_hash=canonical_hash(problem),
        primal_values=nothing,
        dual_equalities=Float64[],
        dual_psd_blocks=[[[1.0]]],
        solver_name="fixture",
        solver_version="1",
    )
    write(joinpath(directory, "solver_artifact.json"), JSON3.write(artifact))
    problem
end

@testset "standalone verifier is optimizer independent and atomic" begin
    mktempdir() do directory
        problem = _write_cli_fixture(directory)
        command = `$(Base.julia_cmd()) --startup-file=no --compiled-modules=no --project=$(dirname(@__DIR__)) $(joinpath(dirname(@__DIR__), "scripts", "verify_run.jl")) $directory`
        @test success(pipeline(command; stdout=devnull, stderr=devnull))
        verification_path = joinpath(directory, "verification.json")
        @test isfile(verification_path)
        document = JSON3.read(read(verification_path, String))
        @test Bool(document.accepted)
        @test String(document.method) == "farkas_exact"
        @test String(document.details.problem_hash) == canonical_hash(problem)
        @test !any(contains("verification.json.tmp"), readdir(directory))

        write(joinpath(directory, "solver_artifact.json"), JSON3.write((
            problem_hash="wrong", primal_values=nothing,
            dual_equalities=Float64[], dual_psd_blocks=[[[1.0]]],
        )))
        @test !success(pipeline(command; stdout=devnull, stderr=devnull))
        rejected = JSON3.read(read(verification_path, String))
        @test !Bool(rejected.accepted)
        @test String(rejected.details.reason) == "problem_hash_mismatch"
        @test String(rejected.details.problem_hash) == canonical_hash(problem)
    end
end

function _selector_spec_json()
    JSON3.write((
        g=(numerator="1", denominator="10"),
        gamma=(numerator="1", denominator="5"),
        L=2,
        d=2,
        rung="A",
        scope="unrestricted",
        timeout_seconds=300,
    ))
end

@testset "selector requires one valid content-addressed spec directory" begin
    mktempdir() do root
        encoded_spec = _selector_spec_json()
        suffix = bytes2hex(SHA.sha256(codeunits(encoded_spec)))[1:12]
        run_id = "g-0.10__gamma-0.20__L-2__d-2__rung-A__scope-unrestricted__" * suffix
        directory = joinpath(root, run_id)
        mkdir(directory)
        _write_cli_fixture(directory)
        write(joinpath(directory, "spec.json"), encoded_spec)
        script = joinpath(dirname(@__DIR__), "scripts", "verify_run.jl")
        command = `$(Base.julia_cmd()) --startup-file=no --compiled-modules=no --project=$(dirname(@__DIR__)) $script --root $root --g 0.10 --gamma 0.20 --L 2 --d 2 --rung A --scope unrestricted`
        @test success(pipeline(command; stdout=devnull, stderr=devnull))
        @test isfile(joinpath(directory, "verification.json"))

        invalid = joinpath(root, "not-content-addressed")
        mkdir(invalid)
        _write_cli_fixture(invalid)
        write(joinpath(invalid, "spec.json"), encoded_spec)
        rm(directory; recursive=true)
        @test !success(pipeline(command; stdout=devnull, stderr=devnull))
        @test !isfile(joinpath(invalid, "verification.json"))
    end
end
