using Test
using TriangularGapCertificates

@testset "state-polynomial monomials have a unique normal form" begin
    x1 = PauliWord([(1, :X)])
    y1 = PauliWord([(1, :Y)])

    monomial = NCStateMonomial((StateSymbol(y1), StateSymbol(PauliWord()), StateSymbol(x1)), PauliWord())

    @test monomial.symbols == (StateSymbol(x1), StateSymbol(y1))
    @test total_degree(monomial) == 2
    @test NCStateMonomial((StateSymbol(x1),), x1).operator_word == x1
    @test adjoint(StateSymbol(x1)) == StateSymbol(x1)
end

@testset "relaxation rungs are deterministic and nested" begin
    patch = build_patch(1)
    a = rung_a(patch, 2)
    b = rung_b(patch, 2; pair_radius=2)

    @test assert_nested(a, b)
    @test a.words == rung_a(patch, 2).words
    @test a.words isa Tuple
    @test_throws MethodError push!(rung_a(patch, 2).words, first(a.words))
    @test a.hash == rung_a(patch, 2).hash
    @test all(total_degree(w) <= 2 for w in b.words)
    @test any(length(support(w.operator_word)) == 2 for w in b.words)
    @test any(w -> w.operator_word == PauliWord([(1, :X), (2, :Y)]), b.words)
    @test any(w -> isempty(w.operator_word.factors) && !isempty(w.symbols), a.words)
    @test a.scope == :unrestricted == b.scope
    @test length(b.words) > length(a.words)
    @test length(a.hash) == 64
end

@testset "Rung B enforces its frozen unrestricted policy" begin
    patch = build_patch(1)
    @test_throws ArgumentError rung_b(patch, 0)
    @test_throws ArgumentError rung_b(patch, 1)
    @test_throws ArgumentError rung_b(patch, 2; pair_radius=1)
    @test_throws ArgumentError rung_b(patch, 2; pair_radius=3)
    @test_throws ArgumentError rung_a(patch, 2; scope=:invalid)
    @test_throws ArgumentError RelaxationBasis(:A, :unrestricted, (PauliWord(),))

    production = rung_a(patch, 2)
    exploratory = rung_a(patch, 2; scope=:exploratory_symmetry_restricted)
    @test production.scope == :unrestricted
    @test exploratory.scope == :exploratory_symmetry_restricted
    @test exploratory.scope != production.scope
end

@testset "nested-basis assertion identifies a changed prefix" begin
    patch = build_patch(1)
    a = rung_a(patch, 1)
    broken = RelaxationBasis(:A, :unrestricted, reverse(a.words))

    error = try
        assert_nested(a, broken)
        nothing
    catch caught
        caught
    end
    @test error isa ArgumentError
    @test occursin("index", sprint(showerror, error))
end
