using Test
using TriangularGapCertificates
using SHA

mutable struct CountingEntries{T} <: AbstractVector{T}
    values::Vector{T}
    reads::Int
end

Base.size(entries::CountingEntries) = size(entries.values)
Base.getindex(entries::CountingEntries, index::Int) = begin
    entries.reads += 1
    entries.values[index]
end

@testset "canonical conic form" begin
    feasible_problem = scalar_psd_fixture(1//1)
    impossible_problem = scalar_psd_fixture(-1//1)
    @test validate_conic(feasible_problem)
    @test validate_conic(impossible_problem)
    @test canonical_hash(feasible_problem) == canonical_hash(scalar_psd_fixture(1//1))
end

@testset "conic constructors canonicalize exact affine data" begin
    constants = [(1, 1, 1//3), (1, 1, 2//3), (2, 2, 1//1), (2, 2, -1//1)]
    affine = [AffineEntry(1, 2, 1, 1//3), AffineEntry(1, 2, 1, 2//3),
              AffineEntry(2, 2, 2, 1//1), AffineEntry(2, 2, 2, -1//1)]
    block = PSDBlock(2, constants, affine)
    problem = ConicFeasibility(["x", "y"],
        [([2 => 1//3, 1 => 2//3, 1 => 1//3], 1//1)], [block],
        Dict("z" => "last", "a" => "first"))

    @test block.constant_entries == ((1, 1, BigInt(1)//BigInt(1)),)
    @test block.variable_entries == (AffineEntry(1, 2, 1, BigInt(1)//BigInt(1)),)
    @test problem.equalities == (((1 => BigInt(1)//BigInt(1), 2 => BigInt(1)//BigInt(3)), BigInt(1)//BigInt(1)),)
    @test problem.metadata == ("a" => "first", "z" => "last")
    @test validate_conic(problem)
end

@testset "conic constructors own their inputs" begin
    names = ["x"]
    constants = [(1, 1, 1//1)]
    affine = AffineEntry[]
    equalities = [([1 => 1//1], 1//1)]
    blocks = [PSDBlock(1, constants, affine)]
    metadata = Dict("origin" => "caller")
    problem = ConicFeasibility(names, equalities, blocks, metadata)
    original_hash = canonical_hash(problem)

    names[1] = "changed"
    constants[1] = (1, 1, -1//1)
    push!(affine, AffineEntry(1, 1, 1, 2//1))
    equalities[1] = ([1 => 2//1], 2//1)
    blocks[1] = scalar_psd_fixture(-1//1).psd_blocks[1]
    metadata["origin"] = "changed"

    @test problem.variable_names == ("x",)
    @test canonical_hash(problem) == original_hash
    @test problem.metadata == ("origin" => "caller",)
end

@testset "conic validation rejects malformed entries" begin
    @test_throws ArgumentError PSDBlock(2, [(2, 1, 1//1)], AffineEntry[])
    @test_throws ArgumentError PSDBlock(2, Tuple{Int,Int,Rational{Int}}[], [AffineEntry(2, 1, 1, 1//1)])
    @test_throws ArgumentError PSDBlock(1, [(2, 2, 1//1)], AffineEntry[])
    @test_throws ArgumentError ConicFeasibility(["x"], [([2 => 1//1], 0//1)], PSDBlock[], Dict{String,String}())
end

@testset "canonical conic constructors have no raw bypass" begin
    exact_one = BigInt(1) // BigInt(1)
    @test_throws MethodError PSDBlock(1, ((1, 1, exact_one),), (), Val(:canonical))
    @test_throws MethodError ConicFeasibility((), (), (), (), Val(:canonical))

    block = PSDBlock(2,
        [(2, 2, 1//1), (1, 1, 1//1), (1, 1, 2//1)],
        [AffineEntry(1, 2, 1, 1//1), AffineEntry(1, 2, 1, -1//1)])
    @test block.constant_entries == ((1, 1, BigInt(3)//BigInt(1)),
                                     (2, 2, BigInt(1)//BigInt(1)))
    @test isempty(block.variable_entries)
    @test all(entry -> entry[3] isa Rational{BigInt}, block.constant_entries)

    problem = ConicFeasibility(["x"], [([1 => 1//2, 1 => 1//2], 0//1)],
        [PSDBlock(1, Tuple{Int,Int,Rational{Int}}[],
                  [AffineEntry(1, 1, 1, 1//1)])],
        ["z" => "last", "a" => "first"])
    @test problem.equalities == (((1 => exact_one,), BigInt(0)//BigInt(1)),)
    @test problem.metadata == ("a" => "first", "z" => "last")
    @test validate_conic(problem)
end

@testset "sorted PSD entries use the same canonical semantics" begin
    sorted_variables = [
        AffineEntry(1, 1, 1, 1//2),
        AffineEntry(1, 1, 1, 1//3),
        AffineEntry(1, 2, 2, -2//1),
        AffineEntry(2, 2, 1, 5//7),
    ]
    sorted_constants = [(1, 1, 1//2), (1, 1, -1//2), (2, 2, 3//4)]
    sorted_block = PSDBlock(2, sorted_constants, sorted_variables)
    unsorted_block = PSDBlock(2, reverse(sorted_constants), reverse(sorted_variables))

    @test sorted_block == unsorted_block
    @test sorted_block.constant_entries == ((2, 2, BigInt(3)//BigInt(4)),)
    @test sorted_block.variable_entries == (
        AffineEntry(1, 1, 1, BigInt(5)//BigInt(6)),
        AffineEntry(1, 2, 2, -2//1),
        AffineEntry(2, 2, 1, 5//7),
    )
    @test TriangularGapCertificates._canonical_psd_constants(2, sorted_constants) ==
          sorted_block.constant_entries
    @test TriangularGapCertificates._canonical_psd_variables(2, sorted_variables) ==
          sorted_block.variable_entries
end

@testset "PSD canonicalization accepts one-pass iterators" begin
    constants = Channel{Tuple{Int,Int,Rational{Int}}}(2)
    put!(constants, (1, 1, 1//2))
    put!(constants, (1, 1, 1//2))
    close(constants)

    @test PSDBlock(1, constants, AffineEntry[]).constant_entries ==
          ((1, 1, BigInt(1)//BigInt(1)),)

    variables = Channel{AffineEntry}(2)
    put!(variables, AffineEntry(1, 1, 1, 1//2))
    put!(variables, AffineEntry(1, 1, 1, 1//2))
    close(variables)

    @test PSDBlock(1, Tuple{Int,Int,Rational{Int}}[], variables).variable_entries ==
          (AffineEntry(1, 1, 1, BigInt(1)//BigInt(1)),)
end

@testset "sorted PSD arrays are canonicalized in one traversal" begin
    constants = CountingEntries([(1, 1, 1//2), (1, 1, 1//2), (2, 2, 3//4)], 0)
    variables = CountingEntries([
        AffineEntry(1, 1, 1, 1//2),
        AffineEntry(1, 1, 1, 1//2),
        AffineEntry(2, 2, 1, 3//4),
    ], 0)

    block = PSDBlock(2, constants, variables)

    @test block.constant_entries == ((1, 1, BigInt(1)//BigInt(1)),
                                     (2, 2, BigInt(3)//BigInt(4)))
    @test block.variable_entries == (AffineEntry(1, 1, 1, BigInt(1)//BigInt(1)),
                                     AffineEntry(2, 2, 1, BigInt(3)//BigInt(4)))
    @test constants.reads == length(constants)
    @test variables.reads == length(variables)
end

@testset "conic JSON is stable and exact" begin
    first = ConicFeasibility(["x"], [([1 => -2//3], 5//7)],
        [PSDBlock(1, [(1, 1, 11//13)], [AffineEntry(1, 1, 1, -17//19)])],
        Dict("z" => "last", "a" => "first"))
    second = ConicFeasibility(["x"], [([1 => -2//3], 5//7)],
        [PSDBlock(1, [(1, 1, 11//13)], [AffineEntry(1, 1, 1, -17//19)])],
        Dict("a" => "first", "z" => "last"))
    encoded = conic_json(first)
    restored = parse_conic_json(encoded)

    @test occursin("\"numerator\":\"-17\"", encoded)
    @test occursin("\"denominator\":\"19\"", encoded)
    @test restored == first
    @test hash(restored) == hash(first)
    @test canonical_hash(restored) == canonical_hash(first)
    @test conic_json(first) == conic_json(second)
    @test canonical_hash(first) == canonical_hash(second)
end

@testset "canonical SHA-256 native backend preserves exact digests" begin
    module_under_test = TriangularGapCertificates
    @test isdefined(module_under_test, :_native_sha256_hex)
    @test isdefined(module_under_test, :_canonical_sha256_hex)

    if isdefined(module_under_test, :_native_sha256_hex) &&
       isdefined(module_under_test, :_canonical_sha256_hex)
        native_sha256_hex = getfield(module_under_test, :_native_sha256_hex)
        canonical_sha256_hex = getfield(module_under_test, :_canonical_sha256_hex)
        openssl_command = Cmd(["openssl", "dgst", "-sha256"])
        abc_digest = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"

        if Sys.which("openssl") !== nothing
            @test native_sha256_hex("abc", openssl_command) == abc_digest
            @test native_sha256_hex("abc", openssl_command) ==
                  bytes2hex(SHA.sha256(codeunits("abc")))
        end

        julia_executable = joinpath(Sys.BINDIR, Base.julia_exename())
        malformed_command = Cmd([
            julia_executable,
            "--startup-file=no",
            "-e",
            "read(stdin); print(\"not-a-sha256-digest\")",
        ])
        nonzero_command = Cmd([
            julia_executable,
            "--startup-file=no",
            "-e",
            "read(stdin); print(\"$abc_digest\"); exit(7)",
        ])
        missing_command = Cmd(["triangular-gap-openssl-does-not-exist", "dgst", "-sha256"])

        @test native_sha256_hex("abc", malformed_command) === nothing
        @test native_sha256_hex("abc", nonzero_command) === nothing
        @test native_sha256_hex("abc", missing_command) === nothing

        captured_process = Ref{Any}(nothing)
        sleeping_command = Cmd([
            julia_executable,
            "--startup-file=no",
            "-e",
            "sleep(30)",
        ])
        open_with_closed_input = function (command)
            process = open(command, "r+")
            captured_process[] = process
            close(process.in)
            process
        end
        @test applicable(
            native_sha256_hex,
            "forced write failure",
            sleeping_command,
            open_with_closed_input,
        )
        if applicable(
            native_sha256_hex,
            "forced write failure",
            sleeping_command,
            open_with_closed_input,
        )
            @test native_sha256_hex(
                "forced write failure",
                sleeping_command,
                open_with_closed_input,
            ) === nothing
            process = captured_process[]
            running_after_return = process_running(process)
            input_open_after_return = isopen(process.in)
            output_open_after_return = isopen(process.out)
            if running_after_return
                try
                    kill(process)
                catch
                end
                try
                    wait(process)
                catch
                end
            end
            @test !running_after_return
            @test process_exited(process)
            @test !input_open_after_return
            @test !output_open_after_return
        end

        large_payload = repeat("0123456789abcdef", 65_536)
        large_digest = "aca1cd027e979588d14b877b7b0cb8585ad9fec599eb45801992ee5382b3760f"
        @test ncodeunits(large_payload) == 1_048_576
        @test canonical_sha256_hex(large_payload; native_command=missing_command) ==
              large_digest
        @test canonical_sha256_hex(large_payload;
              native_helper=(data, command) -> error("injected native failure")) == large_digest

        native_calls = Ref(0)
        recording_helper = function (data, command)
            native_calls[] += 1
            bytes2hex(SHA.sha256(codeunits(data)))
        end
        @test canonical_sha256_hex("small canonical payload";
              native_helper=recording_helper) ==
              "21d7d25f3327a201fade662960845b242fc8a20c544c66ebe9c9da6acf399c37"
        @test native_calls[] == 0
        @test canonical_sha256_hex(large_payload; native_helper=recording_helper) == large_digest
        @test native_calls[] == 1

        if Sys.which("openssl") !== nothing
            @test native_sha256_hex(large_payload, openssl_command) == large_digest
        end
    end
end

@testset "native SHA-256 output parsing is strict" begin
    module_under_test = TriangularGapCertificates
    @test isdefined(module_under_test, :_parse_native_sha256_output)
    if isdefined(module_under_test, :_parse_native_sha256_output)
        parse_output = getfield(module_under_test, :_parse_native_sha256_output)
        digest = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        @test parse_output("SHA2-256(stdin)= $digest\n") == digest
        @test parse_output("SHA2-256(stdin)= $(uppercase(digest))\n") == digest
        @test parse_output("$digest $digest\n") === nothing
        @test parse_output("$digest trailing-text\n") === nothing
        @test parse_output("$(digest[1:end-1])\n") === nothing
        @test parse_output("0$digest\n") === nothing
        @test parse_output("x$digest\n") === nothing
        @test parse_output("$(digest)z\n") === nothing
    end
end

@testset "canonical bytes and cached digest remain unchanged" begin
    problem = scalar_psd_fixture(1//1)
    canonical_bytes =
        "{\"format\":\"triangular-gap-conic-v1\",\"variable_names\":[],\"equalities\":[]," *
        "\"psd_blocks\":[{\"dimension\":1,\"constant_entries\":[{\"row\":1,\"col\":1," *
        "\"coefficient\":{\"numerator\":\"1\",\"denominator\":\"1\"}}]," *
        "\"variable_entries\":[]}],\"metadata\":[{\"key\":\"fixture\"," *
        "\"value\":\"scalar_psd\"}]}"
    expected_digest = "d637284712d039a759c7ae920f9726f51d89447242ac59ce7b41bec9a4ac5b29"

    @test conic_json(problem) == canonical_bytes
    @test bytes2hex(SHA.sha256(codeunits(canonical_bytes))) == expected_digest
    @test canonical_hash(problem) == expected_digest
    @test canonical_hash(problem) == expected_digest
    @test TriangularGapCertificates._canonical_hash_cache_digest[] == expected_digest
end

@testset "canonical hashes are cached per immutable problem instance" begin
    warmup_problem = scalar_psd_fixture(2//1)
    canonical_hash(warmup_problem)
    lock(TriangularGapCertificates._canonical_hash_cache_lock) do
        TriangularGapCertificates._canonical_hash_cache_problem[] = nothing
        TriangularGapCertificates._canonical_hash_cache_digest[] = nothing
    end

    problem = scalar_psd_fixture(1//1)
    expected = bytes2hex(SHA.sha256(codeunits(conic_json(problem))))

    first_allocated = @allocated first_digest = canonical_hash(problem)
    second_allocated = @allocated second_digest = canonical_hash(problem)

    @test first_digest == expected
    @test second_digest == expected
    @test second_allocated * 10 < first_allocated
end

@testset "canonical hash cache replaces its previous problem" begin
    first_problem = scalar_psd_fixture(1//1)
    second_problem = scalar_psd_fixture(1//1)
    expected = bytes2hex(SHA.sha256(codeunits(conic_json(second_problem))))

    @test first_problem == second_problem
    @test first_problem !== second_problem
    canonical_hash(first_problem)
    second_digest = canonical_hash(second_problem)
    repeated_second_digest = canonical_hash(second_problem)

    @test TriangularGapCertificates._canonical_hash_cache_problem[] === second_problem
    @test TriangularGapCertificates._canonical_hash_cache_digest[] == expected
    @test second_digest == expected
    @test repeated_second_digest == expected
end

@testset "malformed conic JSON is rejected" begin
    scalar_json = conic_json(scalar_psd_fixture(1//1))
    @test_throws ArgumentError parse_conic_json(replace(
        scalar_json, "triangular-gap-conic-v1" => "unknown-conic-format"))
    @test_throws ArgumentError parse_conic_json(replace(
        scalar_json, "\"denominator\":\"1\"" => "\"denominator\":\"0\"", count=1))

    triangle_problem = ConicFeasibility(String[], Tuple[],
        [PSDBlock(2, [(1, 2, 1//1)], AffineEntry[])], Dict{String,String}())
    triangle_json = conic_json(triangle_problem)
    @test_throws ArgumentError parse_conic_json(replace(
        triangle_json, "\"row\":1,\"col\":2" => "\"row\":2,\"col\":1", count=1))

    affine_problem = ConicFeasibility(["x"], Tuple[],
        [PSDBlock(1, Tuple{Int,Int,Rational{Int}}[], [AffineEntry(1, 1, 1, 1//1)])],
        Dict{String,String}())
    affine_json = conic_json(affine_problem)
    @test_throws ArgumentError parse_conic_json(replace(
        affine_json, "\"variable\":1" => "\"variable\":2", count=1))
end
