using Test
using JSON3
using SHA
using TriangularGapCertificates

mutable struct RunnerFakeSolver <: AbstractSolverBackend
    calls::Int
    runtime::Float64
    termination::Symbol
    primal_status::Symbol
    dual_status::Symbol
end

RunnerFakeSolver(calls::Int, runtime::Float64) =
    RunnerFakeSolver(calls, runtime, :OPTIMAL, :FEASIBLE_POINT, :NO_SOLUTION)

function TriangularGapCertificates.solve_problem(problem::ConicFeasibility,
                                                  backend::RunnerFakeSolver,
                                                  timeout_seconds::Real)
    backend.calls += 1
    values = zeros(length(problem.variable_names))
    normalization = findfirst(==("L(1)"), problem.variable_names)
    normalization === nothing || (values[normalization] = 1.0)
    raw = raw_status_record(backend.termination, backend.primal_status,
                            backend.dual_status,
                            backend.runtime, Dict("fixture" => 1.0), "fixture")
    SolverArtifact(raw, canonical_hash(problem), values, nothing, nothing,
                   "runner-fixture", "1")
end

struct RunnerErrorIfCalled <: AbstractSolverBackend end
TriangularGapCertificates.solve_problem(::ConicFeasibility,
    ::RunnerErrorIfCalled, ::Real) = error("resume invoked solver")

mutable struct GammaUnknownSolver <: AbstractSolverBackend
    calls::Int
end

function TriangularGapCertificates.solve_problem(problem::ConicFeasibility,
                                                  backend::GammaUnknownSolver,
                                                  timeout_seconds::Real)
    backend.calls += 1
    gamma = Dict(problem.metadata)["gamma"]
    if gamma == "3/10"
        raw = raw_status_record(:TIME_LIMIT, :NO_SOLUTION, :NO_SOLUTION, 300.0,
                                Dict{String,Float64}(), "fixture timeout")
        return SolverArtifact(raw, canonical_hash(problem), nothing, nothing,
                              nothing, "runner-fixture", "1")
    end
    RunnerFakeSolver(0, 0.1) |> fake -> solve_problem(problem, fake, timeout_seconds)
end

function _runner_spec(; gamma=0//1, scope=:unrestricted, timeout=300)
    RunSpec(1//10, gamma, 1, 1, :A, scope, timeout)
end

@testset "runner content address is canonical" begin
    spec = RunSpec(1//10, 1//5, 2, 2, :B, :unrestricted, 300)
    directory = artifact_directory("root", spec)
    @test startswith(basename(directory),
        "g-0.10__gamma-0.20__L-2__d-2__rung-B__scope-unrestricted__")
    @test length(split(basename(directory), "__")[end]) == 12
    @test artifact_directory("root", spec) == directory
end

@testset "valid candidates cannot bypass raw status gates" begin
    for termination in (:TIME_LIMIT, :SLOW_PROGRESS)
        mktempdir() do root
            spec = _runner_spec()
            fake = RunnerFakeSolver(0, 3.0, termination,
                                    :FEASIBLE_POINT, :NO_SOLUTION)
            first = run_one(spec; output_root=root, solver=fake)
            @test first.verification.accepted
            @test first.verdict == unknown
            @test startswith(first.reason, "raw_status_not_eligible")
            second = run_one(spec; output_root=root,
                             solver=RunnerErrorIfCalled())
            @test second == first
        end
    end

    for (runtime, timeout) in ((301.0, 300), (241.0, 240))
        mktempdir() do root
            spec = _runner_spec(timeout=timeout)
            fake = RunnerFakeSolver(0, runtime)
            first = run_one(spec; output_root=root, solver=fake)
            @test first.verification.accepted
            @test first.verdict == unknown
            @test startswith(first.reason, "over_runtime_limit")
            @test run_one(spec; output_root=root,
                          solver=RunnerErrorIfCalled()) == first
        end
    end

    primal = VerificationRecord(true, :primal_exact, Dict{String,String}())
    farkas = VerificationRecord(true, :farkas_exact, Dict{String,String}())
    spec300 = _runner_spec(timeout=300)
    spec240 = _runner_spec(timeout=240)
    primal_boundary = raw_status_record(:OPTIMAL, :FEASIBLE_POINT,
        :NO_SOLUTION, 300.0, Dict{String,Float64}(), "")
    farkas_over = raw_status_record(:INFEASIBLE, :NO_SOLUTION,
        :INFEASIBILITY_CERTIFICATE, 301.0, Dict{String,Float64}(), "")
    declared_over = raw_status_record(:OPTIMAL, :FEASIBLE_POINT,
        :NO_SOLUTION, 241.0, Dict{String,Float64}(), "")
    declared_boundary = raw_status_record(:OPTIMAL, :FEASIBLE_POINT,
        :NO_SOLUTION, 240.0, Dict{String,Float64}(), "")
    @test TriangularGapCertificates._run_verdict(spec300, primal_boundary, primal) == feasible
    @test TriangularGapCertificates._run_verdict(spec300, farkas_over, farkas) == unknown
    @test startswith(TriangularGapCertificates._final_reason(
        spec300, farkas_over, farkas), "over_runtime_limit")
    @test TriangularGapCertificates._run_verdict(spec240, declared_over, primal) == unknown
    @test TriangularGapCertificates._run_verdict(
        spec240, declared_boundary, primal) == feasible
end

@testset "runner is immutable and resumable" begin
    mktempdir() do root
        spec = _runner_spec()
        fake = RunnerFakeSolver(0, 0.25)
        first = run_one(spec; output_root=root, solver=fake)
        @test fake.calls == 1
        directory = artifact_directory(root, spec)
        for name in ("spec.json", "problem.json", "solver_artifact.json",
                     "verification.json", "run_record.json")
            @test isfile(joinpath(directory, name))
        end
        record_document = JSON3.read(read(joinpath(directory, "run_record.json"), String))
        @test Bool(record_document.headline)
        @test String(record_document.spec.g.numerator) == "1"
        @test String(record_document.spec.g.denominator) == "10"
        @test hasproperty(record_document, :code_tree_hash)
        @test hasproperty(record_document, :dependency_versions)
        @test hasproperty(record_document, :geometry)
        @test hasproperty(record_document, :basis)
        @test hasproperty(record_document, :problem_sizes)
        @test hasproperty(record_document, :files)

        original_record = read(joinpath(directory, "run_record.json"), String)
        contradictory = merge(NamedTuple(record_document),
            (spec=merge(NamedTuple(record_document.spec),
                        (gamma=(numerator="1", denominator="5"),)),))
        write(joinpath(directory, "run_record.json"), JSON3.write(contradictory))
        @test_throws ArgumentError load_run(directory)
        write(joinpath(directory, "run_record.json"), original_record)

        second = run_one(spec; output_root=root, solver=RunnerErrorIfCalled())
        @test second == first
        @test load_run(directory) == first
    end
end

@testset "resume re-verifies identities and quarantines corruption" begin
    mktempdir() do root
        spec = _runner_spec()
        fake = RunnerFakeSolver(0, 0.1)
        run_one(spec; output_root=root, solver=fake)
        directory = artifact_directory(root, spec)

        # A sibling temporary file plus no completion marker is a partial run.
        write(joinpath(directory, ".orphan.tmp"), "interrupted")
        rm(joinpath(directory, "run_record.json"))
        run_one(spec; output_root=root, solver=fake)
        @test fake.calls == 2

        # Self-consistent file hashes are not enough: an altered candidate and a
        # forged accepted verification must not be resumed.
        artifact_path = joinpath(directory, "solver_artifact.json")
        artifact = JSON3.read(read(artifact_path, String))
        forged_artifact = merge(NamedTuple(artifact), (primal_values=[9.0],))
        write(artifact_path, JSON3.write(forged_artifact))
        record_path = joinpath(directory, "run_record.json")
        record = JSON3.read(read(record_path, String))
        files = Dict(String(k) => String(v) for (k, v) in pairs(record.files))
        files["solver_artifact.json"] = bytes2hex(SHA.sha256(read(artifact_path)))
        forged_record = merge(NamedTuple(record), (files=files,))
        write(record_path, JSON3.write(forged_record))
        run_one(spec; output_root=root, solver=fake)
        @test fake.calls == 3
        @test isdir(joinpath(root, "corrupt"))
        @test !isempty(readdir(joinpath(root, "corrupt")))

        # Corrupt problem JSON is also quarantined, then rebuilt.
        write(joinpath(directory, "problem.json"), "not-json")
        run_one(spec; output_root=root, solver=fake)
        @test fake.calls == 4
        @test length(readdir(joinpath(root, "corrupt"))) >= 2
    end
end

function _rewrite_run_hash!(directory, name)
    path = joinpath(directory, "run_record.json")
    document = JSON3.read(read(path, String))
    files = Dict(String(k) => String(v) for (k, v) in pairs(document.files))
    files[name] = bytes2hex(SHA.sha256(read(joinpath(directory, name))))
    write(path, JSON3.write(merge(NamedTuple(document), (files=files,))))
end

@testset "resume binds stored problem to the addressed spec" begin
    mktempdir() do root
        # Degree zero makes both gamma points exactly feasible, so all old
        # verifier/hash checks pass and only deterministic spec reconstruction
        # can detect this replay.
        target_spec = RunSpec(1//10, 0//1, 1, 0, :A, :unrestricted, 300)
        source_spec = RunSpec(1//10, 1//5, 1, 0, :A, :unrestricted, 300)
        target_solver = RunnerFakeSolver(0, 0.1)
        run_one(target_spec; output_root=root, solver=target_solver)
        run_one(source_spec; output_root=root, solver=RunnerFakeSolver(0, 0.1))
        target = artifact_directory(root, target_spec)
        source = artifact_directory(root, source_spec)
        for name in ("problem.json", "solver_artifact.json", "verification.json")
            cp(joinpath(source, name), joinpath(target, name); force=true)
            _rewrite_run_hash!(target, name)
        end
        @test_throws ArgumentError load_run(target)
        run_one(target_spec; output_root=root, solver=target_solver)
        @test target_solver.calls == 2
        @test !isempty(readdir(joinpath(root, "corrupt")))
    end
end

@testset "resume audits every duplicated verification and metadata field" begin
    mktempdir() do root
        spec = _runner_spec()
        run_one(spec; output_root=root, solver=RunnerFakeSolver(0, 0.1))
        directory = artifact_directory(root, spec)

        verification_path = joinpath(directory, "verification.json")
        original_verification = read(verification_path, String)
        verification = JSON3.read(original_verification)
        details = Dict(String(k) => String(v) for (k, v) in pairs(verification.details))
        details["separation"] = "forged-but-hashes-unchanged"
        write(verification_path, JSON3.write(
            merge(NamedTuple(verification), (details=details,))))
        _rewrite_run_hash!(directory, "verification.json")
        @test_throws ArgumentError load_run(directory)

        repair = RunnerFakeSolver(0, 0.1)
        run_one(spec; output_root=root, solver=repair)
        @test repair.calls == 1
        @test isdir(joinpath(root, "corrupt"))
        @test length(readdir(joinpath(root, "corrupt"))) == 1

        # The rerun restored a fully valid record; now forge only duplicated fields.
        original_verification = read(verification_path, String)
        record_path = joinpath(directory, "run_record.json")
        original_record = read(record_path, String)
        record = JSON3.read(original_record)
        forged_geometry = merge(NamedTuple(record.geometry), (hash="forged",))
        write(record_path, JSON3.write(
            merge(NamedTuple(record), (geometry=forged_geometry,))))
        @test_throws ArgumentError load_run(directory)

        write(record_path, original_record)
        record = JSON3.read(original_record)
        forged_verification = merge(NamedTuple(record.verification),
                                    (margin="forged",))
        write(record_path, JSON3.write(
            merge(NamedTuple(record), (verification=forged_verification,))))
        @test_throws ArgumentError load_run(directory)
    end
end

@testset "restricted runs are never headline results" begin
    mktempdir() do root
        spec = _runner_spec(scope=:exploratory_symmetry_restricted)
        run_one(spec; output_root=root, solver=RunnerFakeSolver(0, 0.1))
        document = JSON3.read(read(joinpath(artifact_directory(root, spec),
                                           "run_record.json"), String))
        @test !Bool(document.headline)
    end
end

@testset "phase-1 grid preserves declared order" begin
    mktempdir() do root
        records = run_phase1_grid(; L=1, d=0, rung=:A, output_root=root,
                                  solver=RunnerFakeSolver(0, 0.1),
                                  timeout_seconds=300)
        @test [record.spec.gamma for record in records] ==
              [0//1, 3//10, 1//5, 1//10, 3//5, 6//5, 12//5, 24//5]
    end
end

@testset "unknown at gamma 0.30 never triggers escalation" begin
    mktempdir() do root
        solver = GammaUnknownSolver(0)
        records = run_phase1_grid(; L=1, d=0, rung=:A, output_root=root,
                                  solver, timeout_seconds=300)
        @test [record.spec.gamma for record in records] ==
              [0//1, 3//10, 1//5, 1//10]
        @test records[2].verdict == unknown
        @test solver.calls == 4
    end
end

@testset "Rung B timeout fallback is a whole declared rung" begin
    config = (L=2, d=2, rung=:B)
    @test TriangularGapCertificates._fallback_config(config, NamedTuple[]) ==
          (L=2, d=2, rung=:A)
    declared = [(L=1, d=2, rung=:B)]
    @test TriangularGapCertificates._fallback_config(config, declared) == only(declared)

    verification = VerificationRecord(false, :not_checked,
                                      Dict("reason" => "fixture"))
    for (status, runtime, timeout) in ((:TIME_LIMIT, 0.0, 300),
                                       (:SLOW_PROGRESS, 0.0, 300),
                                       (:OPTIMAL, 300.0, 300),
                                       (:OPTIMAL, 240.0, 240))
        raw = raw_status_record(status, :NO_SOLUTION, :NO_SOLUTION, runtime,
                                Dict{String,Float64}(), "")
        spec = RunSpec(1//10, 0//1, 2, 2, :B, :unrestricted, timeout)
        record = RunRecord(spec, raw, verification, unknown, "fixture")
        @test TriangularGapCertificates._needs_fallback(record)
    end
end

include(joinpath(dirname(@__DIR__), "scripts", "run_gap_grid.jl"))

@testset "grid CLI accepts only its frozen interface" begin
    parsed = _parse_grid_arguments(
        ["--L", "2", "--d", "2", "--rung", "B", "--output", "runs",
         "--timeout", "240"])
    @test parsed == (L=2, d=2, rung=:B, output="runs", timeout=240)
    @test_throws ArgumentError _parse_grid_arguments(
        ["--L", "2", "--d", "2", "--rung", "B", "--output", "runs",
         "--g", "0.12"])
    @test_throws ArgumentError _parse_grid_arguments(
        ["--L", "2", "--d", "2", "--rung", "C", "--output", "runs"])
    @test_throws ArgumentError _parse_grid_arguments(
        ["--L", "2", "--d", "2", "--rung", "A"])
end
