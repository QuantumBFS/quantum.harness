using Test
using TriangularGapCertificates

@testset "triangular shells" begin
    patch = build_patch(2)
    @test length(patch.sites) == 19
    @test length(patch.e1) == 42
    @test length(patch.e2) == 30
    @test length(unique(patch.e1)) == length(patch.e1)
    @test length(unique(patch.e2)) == length(patch.e2)
    @test isempty(intersect(Set(patch.e1), Set(patch.e2)))
    center = patch.index[Axial(0, 0)]
    @test count(e -> center in e, patch.e1) == 6
    @test count(e -> center in e, patch.e2) == 6
end

@testset "erosion retains only complete supports" begin
    patch = build_patch(2)
    inner = eroded_sites(patch, [Axial(1,0), Axial(0,1), Axial(1,-1), Axial(1,1), Axial(2,-1), Axial(1,-2)])
    @test Axial(0,0) in inner
    @test !(Axial(2,0) in inner)
end

@testset "geometry manifest independently validates edge shells" begin
    patch = build_patch(2)
    manifest_a = geometry_manifest(patch)
    manifest_b = geometry_manifest(build_patch(2))

    @test all(edge -> begin
        a, b = patch.sites[edge[1]], patch.sites[edge[2]]
        dq, dr = a.q - b.q, a.r - b.r
        dq^2 + dq * dr + dr^2 == 1
    end, patch.e1)
    @test all(edge -> begin
        a, b = patch.sites[edge[1]], patch.sites[edge[2]]
        dq, dr = a.q - b.q, a.r - b.r
        dq^2 + dq * dr + dr^2 == 3
    end, patch.e2)
    @test all(edge -> edge[1] != edge[2], vcat(patch.e1, patch.e2))
    @test manifest_a.hash == manifest_b.hash

    malformed_e1 = copy(patch.e1)
    pop!(malformed_e1)
    malformed = TriangularPatch(patch.L, patch.sites, patch.index, malformed_e1, patch.e2)
    @test_throws ArgumentError geometry_manifest(malformed)
end
