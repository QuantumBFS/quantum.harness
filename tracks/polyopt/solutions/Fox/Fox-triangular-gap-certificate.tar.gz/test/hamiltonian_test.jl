using Test
using LinearAlgebra
using TriangularGapCertificates

@testset "Heisenberg normalization" begin
    bond = heisenberg_bond(1, 2, 1//1)
    @test sort(round.(eigvals(Hermitian(dense_matrix(bond, 2))), digits=12)) == [-0.75, 0.25, 0.25, 0.25]

    triangle = heisenberg_bond(1, 2, 1//1) + heisenberg_bond(2, 3, 1//1) + heisenberg_bond(1, 3, 1//1)
    values = sort(round.(eigvals(Hermitian(dense_matrix(triangle, 3))), digits=12))
    @test values == [-0.75, -0.75, -0.75, -0.75, 0.75, 0.75, 0.75, 0.75]
end

@testset "Independent ED validates mixed triangular Hamiltonian" begin
    patch = build_patch(1)
    exact_matrix = dense_matrix(triangular_hamiltonian(patch, 1//10), 7)
    ed_matrix = independent_ed_matrix(patch, 1//10)

    @test all(isapprox.(exact_matrix, ed_matrix; atol=1e-12, rtol=0))
end

@testset "J2 coefficient changes remain isolated to J2 edges" begin
    patch = build_patch(1)
    delta = triangular_hamiltonian(patch, 1//5) + ExactOperator(Dict(
        word => -coefficient for (word, coefficient) in triangular_hamiltonian(patch, 1//10)
    ))

    @test !isempty(delta)
    @test all(support(word) in Set(patch.e2) for word in keys(delta.terms))
    @test all(real(coefficient) == 1//40 && imag(coefficient) == 0//1 for coefficient in values(delta.terms))
end
