using Test
using TriangularGapCertificates

patch = build_patch(1)
basis = rung_a(patch, 2)
spec = RunSpec(1//10, 0//1, 1, 2, :A, :unrestricted, 300)

first_elapsed = @elapsed first_problem = build_gap_relaxation(patch, basis, spec)
first_hash = canonical_hash(first_problem)
first_dimensions = Tuple(block.dimension for block in first_problem.psd_blocks)
println("first_hash=$first_hash dimensions=$first_dimensions first_elapsed=$first_elapsed")
flush(stdout)
first_problem = nothing
GC.gc()
second_elapsed = @elapsed second_problem = build_gap_relaxation(patch, basis, spec)
second_hash = canonical_hash(second_problem)
println("second_hash=$second_hash second_elapsed=$second_elapsed")
flush(stdout)

@test first_hash == second_hash
@test first_dimensions[1] == 2 * length(basis.words)
@test validate_conic(second_problem)
println("d2_hash=$first_hash dimensions=$first_dimensions " *
        "first_elapsed=$first_elapsed second_elapsed=$second_elapsed")
