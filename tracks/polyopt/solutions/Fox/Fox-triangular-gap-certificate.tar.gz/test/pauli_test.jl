using Test
using TriangularGapCertificates

const ExactComplex = Complex{Rational{BigInt}}

@testset "Pauli word normal form" begin
    x = PauliWord([(1, :X)])
    y = PauliWord([(1, :Y)])
    z2 = PauliWord([(2, :Z)])

    @test multiply(x, y) == (ExactComplex(0//1, 1//1), PauliWord([(1, :Z)]))
    @test multiply(y, x) == (ExactComplex(0//1, -1//1), PauliWord([(1, :Z)]))
    @test multiply(x, z2) == (ExactComplex(1//1, 0//1), PauliWord([(1, :X), (2, :Z)]))
    @test multiply(x, x) == (ExactComplex(1//1, 0//1), PauliWord())
end

@testset "Pauli algebra is exact and canonical" begin
    axes = (:I, :X, :Y, :Z)
    oneword(axis) = axis == :I ? PauliWord() : PauliWord([(1, axis)])

    for a in axes, b in axes, c in axes
        phase_ab, word_ab = multiply(oneword(a), oneword(b))
        phase_left, word_left = multiply(word_ab, oneword(c))
        phase_bc, word_bc = multiply(oneword(b), oneword(c))
        phase_right, word_right = multiply(oneword(a), word_bc)
        @test (phase_ab * phase_left, word_left) == (phase_bc * phase_right, word_right)
    end

    x1 = PauliWord([(1, :X)])
    y2 = PauliWord([(2, :Y)])
    @test multiply(x1, y2) == multiply(y2, x1)
    @test adjoint_word(PauliWord([(2, :Z), (1, :X)])) == PauliWord([(1, :X), (2, :Z)])
    @test support(PauliWord([(3, :X), (1, :Z)])) == (1, 3)
    @test_throws ArgumentError PauliWord([(1, :X), (1, :Y)])
    @test PauliWord((PauliFactor(2, :Z), PauliFactor(1, :X))) == PauliWord([(1, :X), (2, :Z)])
    @test_throws ArgumentError PauliWord((PauliFactor(1, :X), PauliFactor(1, :Y)))

    xy_phase, xy = multiply(x1, PauliWord([(1, :Y)]))
    yx_phase, yx = multiply(PauliWord([(1, :Y)]), x1)
    cancelled = ExactOperator(Dict(xy => xy_phase)) + ExactOperator(Dict(yx => yx_phase))
    @test isempty(cancelled)

    op_a = ExactOperator(Dict(PauliWord([(2, :Z)]) => ExactComplex(1//1), PauliWord([(1, :X)]) => ExactComplex(-1//2)))
    op_b = ExactOperator(Dict(PauliWord([(1, :X)]) => ExactComplex(-1//2), PauliWord([(2, :Z)]) => ExactComplex(1//1)))
    @test operator_hash(op_a) == operator_hash(op_b)
end
