using Test
using TriangularGapCertificates

@testset "public verdict requires verification" begin
    spec = RunSpec(1//10, 1//5, 1, 2, :A, :unrestricted, 300)
    raw = RawSolveRecord(:INFEASIBLE, :NO_SOLUTION, :INFEASIBILITY_CERTIFICATE, 1.2, Dict{String,Float64}(), "")
    @test public_verdict(raw, VerificationRecord(false, :not_checked, Dict{String,String}())) == unknown
    @test public_verdict(raw, VerificationRecord(true, :farkas_exact, Dict("margin" => "1/1000"))) == certified_infeasible

    primal = VerificationRecord(true, :primal_exact, Dict{String,String}())
    farkas = VerificationRecord(true, :farkas_interval, Dict{String,String}())
    @test public_verdict(RawSolveRecord(:OPTIMAL, :NEARLY_FEASIBLE_POINT,
        :NO_SOLUTION, 0.0, Dict{String,Float64}(), ""), primal) == feasible
    @test public_verdict(RawSolveRecord(:TIME_LIMIT, :FEASIBLE_POINT,
        :NO_SOLUTION, 0.0, Dict{String,Float64}(), ""), primal) == unknown
    @test public_verdict(RawSolveRecord(:NUMERICAL_ERROR, :FEASIBLE_POINT,
        :NO_SOLUTION, 0.0, Dict{String,Float64}(), ""), primal) == unknown
    @test public_verdict(RawSolveRecord(:INFEASIBLE, :NO_SOLUTION,
        :NEARLY_INFEASIBILITY_CERTIFICATE, 0.0,
        Dict{String,Float64}(), ""), farkas) == certified_infeasible
    @test public_verdict(RawSolveRecord(:SLOW_PROGRESS, :NO_SOLUTION,
        :INFEASIBILITY_CERTIFICATE, 0.0,
        Dict{String,Float64}(), ""), farkas) == unknown
    @test public_verdict(RawSolveRecord(:INFEASIBLE, :NO_SOLUTION,
        :UNKNOWN_RESULT_STATUS, 0.0,
        Dict{String,Float64}(), ""), farkas) == unknown

    @test public_verdict(RawSolveRecord(:OPTIMAL, :FEASIBLE_POINT,
        :NO_SOLUTION, 301.0, Dict{String,Float64}(), ""), primal) == unknown
    @test public_verdict(RawSolveRecord(:INFEASIBLE, :NO_SOLUTION,
        :INFEASIBILITY_CERTIFICATE, 301.0,
        Dict{String,Float64}(), ""), farkas) == unknown
    @test public_verdict(RawSolveRecord(:OPTIMAL, :FEASIBLE_POINT,
        :NO_SOLUTION, 300.0, Dict{String,Float64}(), ""), primal) == feasible
end

@testset "restricted runs are not headline runs" begin
    @test is_headline(RunSpec(1//10, 1//5, 1, 2, :A, :unrestricted, 300))
    @test !is_headline(RunSpec(1//10, 1//5, 1, 2, :A, :exploratory_symmetry_restricted, 300))
end
