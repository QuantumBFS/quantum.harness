using Test
using TriangularGapCertificates
import MathOptInterface

const SolverTestMOI = MathOptInterface

@testset "candidate reads use exhaustive MOI status allowlists" begin
    statuses = collect(instances(SolverTestMOI.ResultStatusCode))
    expected_statuses = Set((
        SolverTestMOI.NO_SOLUTION,
        SolverTestMOI.FEASIBLE_POINT,
        SolverTestMOI.NEARLY_FEASIBLE_POINT,
        SolverTestMOI.INFEASIBLE_POINT,
        SolverTestMOI.INFEASIBILITY_CERTIFICATE,
        SolverTestMOI.NEARLY_INFEASIBILITY_CERTIFICATE,
        SolverTestMOI.REDUCTION_CERTIFICATE,
        SolverTestMOI.NEARLY_REDUCTION_CERTIFICATE,
        SolverTestMOI.UNKNOWN_RESULT_STATUS,
        SolverTestMOI.OTHER_RESULT_STATUS,
    ))
    primal_point_statuses = Set((SolverTestMOI.FEASIBLE_POINT,
                                 SolverTestMOI.NEARLY_FEASIBLE_POINT))
    farkas_ray_statuses = Set((SolverTestMOI.INFEASIBILITY_CERTIFICATE,
                               SolverTestMOI.NEARLY_INFEASIBILITY_CERTIFICATE))

    @test Set(statuses) == expected_statuses
    for status in statuses
        @test TriangularGapCertificates._has_primal_point(status) ==
              (status in primal_point_statuses)
        @test TriangularGapCertificates._has_farkas_dual_ray(status) ==
              (status in farkas_ray_statuses)
    end
end

@testset "raw statuses are never collapsed" begin
    for status in (:OPTIMAL, :INFEASIBLE, :SLOW_PROGRESS, :TIME_LIMIT,
                   :NUMERICAL_ERROR, :OTHER_ERROR)
        raw = raw_status_record(status, :UNKNOWN_RESULT_STATUS,
                                :UNKNOWN_RESULT_STATUS, 5.0,
                                Dict{String,Float64}(), "")
        @test raw.termination_status == status
        @test raw.primal_status == :UNKNOWN_RESULT_STATUS
        @test raw.dual_status == :UNKNOWN_RESULT_STATUS
    end
    slow = raw_status_record(:SLOW_PROGRESS, :NO_SOLUTION, :NO_SOLUTION,
                             300.0, Dict{String,Float64}(),
                             "solver made slow progress")
    @test public_verdict(slow,
        VerificationRecord(false, :not_checked, Dict{String,String}())) == unknown

    moi_raw = raw_status_record(SolverTestMOI.SLOW_PROGRESS,
                                SolverTestMOI.UNKNOWN_RESULT_STATUS,
                                SolverTestMOI.NO_SOLUTION, 1.0,
                                Dict{String,Float64}(), "raw MOI status")
    @test moi_raw.termination_status == :SLOW_PROGRESS
    @test moi_raw.primal_status == :UNKNOWN_RESULT_STATUS
    @test moi_raw.dual_status == :NO_SOLUTION
end

@testset "solver artifacts preserve candidates and identity" begin
    raw = raw_status_record(:OPTIMAL, :FEASIBLE_POINT, :FEASIBLE_POINT,
                            0.25, Dict("iterations" => 4.0), "ok")
    artifact = SolverArtifact(raw, "problem-hash", [1.0, -2.0],
                              [3.0], [reshape([4.0], 1, 1)],
                              "fake", "1.2.3")
    @test artifact.raw === raw
    @test artifact.problem_hash == "problem-hash"
    @test artifact.primal_values == [1.0, -2.0]
    @test artifact.dual_equalities == [3.0]
    @test artifact.dual_psd_blocks == [reshape([4.0], 1, 1)]
    @test artifact.solver_name == "fake"
    @test artifact.solver_version == "1.2.3"

    empty_artifact = SolverArtifact(raw, "problem-hash", nothing, nothing,
                                    nothing, "fake", "1.2.3")
    @test isnothing(empty_artifact.primal_values)
    @test isnothing(empty_artifact.dual_equalities)
    @test isnothing(empty_artifact.dual_psd_blocks)
end

struct FakeSolverBackend <: AbstractSolverBackend
    artifact::SolverArtifact
end

TriangularGapCertificates.solve_problem(problem::ConicFeasibility,
                                        backend::FakeSolverBackend,
                                        timeout_seconds::Real) = backend.artifact

@testset "backend dispatch can expose an explicit no-candidate solve" begin
    raw = raw_status_record(:TIME_LIMIT, :NO_SOLUTION, :NO_SOLUTION, 1.0,
                            Dict{String,Float64}(), "time limit")
    expected = SolverArtifact(raw,
        canonical_hash(scalar_psd_fixture(1//1)), nothing, nothing, nothing,
        "fake", "test")
    actual = solve_problem(scalar_psd_fixture(1//1),
                           FakeSolverBackend(expected), 1.0)
    @test actual === expected
    @test public_verdict(actual.raw,
        VerificationRecord(false, :not_checked, Dict{String,String}())) == unknown
end

@testset "MOSEK scalar PSD fixtures" begin
    positive = solve_problem(scalar_psd_fixture(1//1), MosekBackend(), 10.0)
    negative = solve_problem(scalar_psd_fixture(-1//1), MosekBackend(), 10.0)
    errors = filter(!isempty, [positive.raw.message, negative.raw.message])
    license_failure = any(message -> occursin(r"(?i)license|MSK_RES_ERR_LICENSE", message),
                          errors) &&
                      (positive.raw.termination_status == :OTHER_ERROR ||
                       negative.raw.termination_status == :OTHER_ERROR)
    if license_failure
        exact_error = join(errors, "\n")
        @info "MOSEK license unavailable" exact_error
        @test_broken isempty(exact_error)
    else
        @test positive.raw.termination_status == :OPTIMAL
        @test positive.raw.primal_status == :FEASIBLE_POINT
        @test positive.raw.dual_status == :FEASIBLE_POINT
        @test positive.problem_hash == canonical_hash(scalar_psd_fixture(1//1))
        @test positive.solver_name == "Mosek"
        @test positive.primal_values !== nothing
        @test isnothing(positive.dual_equalities)
        @test isnothing(positive.dual_psd_blocks)

        @test negative.raw.termination_status == :INFEASIBLE
        @test negative.raw.primal_status == :NO_SOLUTION
        @test negative.raw.dual_status == :INFEASIBILITY_CERTIFICATE
        @test negative.problem_hash == canonical_hash(scalar_psd_fixture(-1//1))
        @test isnothing(negative.primal_values)
        @test negative.dual_equalities !== nothing
        @test negative.dual_psd_blocks !== nothing
    end
end

@testset "MOSEK conversion retains equalities and upper-triangle affine data" begin
    problem = ConicFeasibility(["x"], [([1 => 1//1], 2//1)],
        [PSDBlock(2, [(1, 2, 1//2), (2, 2, 1//1)],
                  [AffineEntry(1, 1, 1, 1//1)])],
        Dict("fixture" => "mixed_affine"))
    artifact = solve_problem(problem, MosekBackend(), 10.0)
    if artifact.raw.termination_status == :OTHER_ERROR &&
       occursin(r"(?i)license|MSK_RES_ERR_LICENSE", artifact.raw.message)
        @info "MOSEK license unavailable" exact_error=artifact.raw.message
        @test_broken isempty(artifact.raw.message)
    else
        @test artifact.raw.termination_status == :OPTIMAL
        @test artifact.raw.primal_status == :FEASIBLE_POINT
        @test artifact.primal_values !== nothing
        @test only(artifact.primal_values) ≈ 2.0 atol=1e-8
        @test artifact.problem_hash == canonical_hash(problem)
    end
end

@testset "solver conversion exceptions produce no candidates" begin
    enormous = BigInt(10)^400 // BigInt(1)
    problem = ConicFeasibility(String[], Tuple[],
        [PSDBlock(1, [(1, 1, enormous)], AffineEntry[])],
        Dict("fixture" => "float_overflow"))
    artifact = solve_problem(problem, MosekBackend(), 1.0)
    @test artifact.raw.termination_status == :OTHER_ERROR
    @test artifact.raw.primal_status == :NO_SOLUTION
    @test artifact.raw.dual_status == :NO_SOLUTION
    @test !isempty(artifact.raw.message)
    @test isnothing(artifact.primal_values)
    @test isnothing(artifact.dual_equalities)
    @test isnothing(artifact.dual_psd_blocks)
    @test_throws ArgumentError solve_problem(problem, MosekBackend(), 0.0)
end
