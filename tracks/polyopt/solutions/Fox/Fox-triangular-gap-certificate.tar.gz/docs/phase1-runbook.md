# Phase-1 runbook

This runbook freezes the Phase-1 calculation for the triangular-lattice
\(J_1\)-\(J_2\) model at exact \(g=1/10\). Run every command from the repository
root. A valid MOSEK installation and license are required for production solves.

## 1. Verify the environment

```bash
julia --project=. -e 'using Pkg; Pkg.instantiate(); Pkg.test()'
```

The solver-free suite must pass. If MOSEK is unlicensed, integration tests report
the exact license error as broken; this does not authorize a production claim or
an optimizer substitution.

## 2. Run the frozen grids

Preserve the exact environment lockfile beside the run tree before solving:

```bash
mkdir -p results/phase1
cp Manifest.toml results/phase1/environment-Manifest.toml
```

The source-tree hash in each run record also binds the repository Manifest, and
`dependency_versions` repeats the resolved package versions for audit.

```bash
julia --project=. scripts/run_gap_grid.jl --L 1 --d 2 --rung A --timeout 300 --output results/phase1
julia --project=. scripts/run_gap_grid.jl --L 1 --d 2 --rung B --timeout 300 --output results/phase1
```

Each command fixes `g=1/10` and `scope=unrestricted`. It evaluates gamma in the
order `0`, `3/10`, `1/5`, `1/10`. If `3/10` is independently feasible and no
certified upper endpoint exists, it tries `3/5`, `6/5`, `12/5`, and `24/5` in
order. The `300` seconds is a per-formal-run limit, not a limit for the whole
grid. Reaching it, `SLOW_PROGRESS`, a numerical exception, or a license failure
is `unknown`.

Do not kill a build and label it infeasible. Rung B at `d=2` is intentionally a
large exact basis/PSD assembly. If the solver returns a resource or time status,
retain its raw `unknown` artifact and use only the runner's declared whole-rung
fallback; never delete words from a named rung. If exact assembly itself cannot
complete, no `run_record.json` exists and there is no scientific outcome to
classify: report that point as operationally unrun, not as an infeasibility
certificate or a fabricated `unknown` artifact.

Rung-A acceptance requires the `gamma=0` row to be `feasible`, all geometry and
Hamiltonian tests to pass, and raw statuses to remain uncollapsed. Rung B must
retain the byte-identical ordered Rung-A basis prefix; `assert_nested` is part of
the acceptance suite.

## 3. Inspect the artifacts

Every completed content-addressed run directory contains:

```text
spec.json
problem.json
solver_artifact.json
verification.json
run_record.json
```

`run_record.json` records the geometry and basis hashes, variable/equality and
PSD-block sizes, affine-entry counts, raw termination/primal/dual statuses,
diagnostics, actual runtime, solver identity, independent-verifier result,
three-valued reason, source/dependency identity, and hashes of the other four
files. A missing or invalid completion record is not evidence.

For the requested four-point grid, confirm that gamma `0`, `1/10`, `1/5`, and
`3/10` are all visible. `unknown` rows must remain visible. Main-table evidence
must have `scope=unrestricted`; exploratory symmetry-restricted records belong
only in the appendix.

## 4. Reverify a candidate in a fresh process

For the Rung-B `gamma=1/5` selector, run exactly:

```bash
julia --project=. scripts/verify_run.jl --root results/phase1 --g 1/10 --gamma 1/5 --L 1 --d 2 --rung B --scope unrestricted
```

Selector mode requires all seven selectors: `root`, `g`, `gamma`, `L`, `d`,
`rung`, and `scope`. Rational selectors accept forms such as `1/10` and `0.10`.
The verifier walks below `root`, accepts only canonical content-addressed
directories containing `spec.json`, `problem.json`, and
`solver_artifact.json`, and errors when zero or more than one directory matches
the exact selector set. It writes `verification.json` atomically and exits zero
only for an accepted proof. The interval fallback, when needed, always runs at
256-bit precision; there is no CLI precision switch.

The expected completed file set is the five-file list above. The standalone
verifier itself needs `problem.json` and `solver_artifact.json`; selector mode
also needs `spec.json`. After it succeeds, `load_run` must still validate the
complete five-file hash chain. No paper claim is allowed until independent
verification succeeds in a fresh Julia process with identical problem and
candidate/certificate hashes.

If any point is `certified_infeasible`, re-run the selector command for that
exact point in a fresh process. Compare the printed method/margin and the hashes
in `verification.json` and `run_record.json`. Any changed hash or failed recheck
returns the point to `unknown`.

## 5. Regenerate the deterministic report

```bash
julia --project=. -e 'using TriangularGapCertificates; root=abspath("results/phase1"); dirs=String[]; for (directory, _, files) in walkdir(root); "run_record.json" in files && push!(dirs, directory); end; records=load_run.(sort!(dirs)); build_report(records, joinpath(root, "report"); artifact_root=root)'
```

Run the command twice and compare `results/phase1/report/report.md` and
`report.json` byte-for-byte. The report builder audits exact-gamma monotonicity
and Rung-A/B nesting before writing. It excludes restricted rows from the main
table, retains `unknown`, and derives the scientific tier only from accepted
unrestricted outcomes. Feasible wording is “this relaxation does not exclude”;
it must never be paraphrased as “the system is gapped.”

The only permitted exclusion sentence is:

```text
At relaxation (L={L}, d={d}, rung={rung}), gamma={gamma} J1 is independently certified infeasible; therefore Delta_bulk < {gamma} J1.
```

## 6. Publication checklist

- The exact model, Pauli `1/4` normalization, geometry, and open local window
  checks pass.
- Rung A is independently feasible at `gamma=0`.
- The Rung-B basis is an exact ordered superset of Rung A.
- Every row retains matrix sizes, raw status, diagnostics, runtime, hashes, and
  a three-valued reason in its run record.
- Gamma monotonicity and nested-rung audits pass with `unknown` ignored for
  bracketing but retained in the report.
- Every claimed exclusion passes the fresh-process verifier with identical
  hashes.
- The result tier is read from `report.json`; it is never assumed in advance.

If these gates do not all pass, report the achieved tier as `inconclusive` and
describe the raw `unknown` outcomes. Do not infer a physical gap from solver
termination flags.
