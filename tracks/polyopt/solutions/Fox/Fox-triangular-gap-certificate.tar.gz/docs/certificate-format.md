# Canonical conic and certificate format

This document describes the `triangular-gap-conic-v1`,
`triangular-gap-solver-artifact-v1`, and
`triangular-gap-verification-v1` contracts implemented by the package. The
optimizer produces candidates; only the independent verifier turns an accepted
candidate into evidence.

## Canonical primal convention

The feasibility problem is stored as

\[
A x=b,\qquad F_k(x)=F_{k,0}+\sum_i x_iF_{k,i}\succeq0.
\]

Variables retain their declared order and unique names. Equality coefficients
are combined, zero terms are removed, and indices are strictly increasing.
Every symmetric matrix is stored once in its upper triangle with one-based
`row <= col` indices. Constant entries are ordered by `(row,col)` and affine
entries by `(row,col,variable)`; duplicate entries are summed and exact zeros
are removed. Reading a block mirrors each off-diagonal entry into the lower
triangle. Metadata keys are unique and lexicographically sorted.

The symmetric Frobenius product used by the dual therefore counts a stored
diagonal coefficient once and a stored off-diagonal coefficient twice. This is
the same convention used when the canonical problem is converted to JuMP/MOI.

## Exact rational JSON

Every exact rational in `spec.json` and `problem.json` is a JSON object whose
numerator and denominator are base-10 strings:

```json
{"numerator":"-1","denominator":"10"}
```

The denominator must be strictly positive. Canonical conic problem data parse
to reduced `Rational{BigInt}` values. The smaller `RunSpec` fields parse to exact
`Rational{Int}` values and are constrained to the Phase-1 parameter range.
Both serialize back to one canonical numerator/denominator byte sequence. Exact
specification and problem data are never encoded as JSON binary floats. Solver
candidates in `solver_artifact.json` are floating-point arrays; they are
explicitly untrusted until reconstruction and verification succeed.

`conic_json(problem)` writes fields in the frozen format order. The problem hash
is lowercase hexadecimal SHA-256 of those canonical JSON bytes, without the
newline added by the artifact writer.

## Farkas ray and sign convention

For equality multiplier `y` and symmetric dual blocks
\(Z_k\succeq0\), the accepted infeasibility convention is

\[
A^T y+\sum_k(F_{k,i}\bullet Z_k)_i=0,
\qquad
\sum_k F_{k,0}\bullet Z_k-b^Ty<0.
\]

The final scalar is called the separation. The candidate-declared separation is
only a finite negative sign diagnostic. The verifier recomputes separation from
the problem and the corrected ray; no solver residual or tolerance can replace
the strict negative proof. A valid ray must also be nonzero.

## Exact acceptance path

Floating coordinates are rationally reconstructed and then corrected with an
exact rational RREF solve so that one common candidate satisfies every affine
identity exactly. Free coordinates retain their deterministic reconstructed
values; pivot coordinates are recomputed.

Every corrected primal or dual PSD block is checked by exact symmetric
\(LDL^T\) elimination. Each pivot must be nonnegative. If a pivot is zero, all
remaining entries in that pivot row must also be exactly zero; otherwise the
block is rejected. A Farkas ray is accepted as `farkas_exact` only when all
blocks pass, the recomputed exact separation is strictly negative, and the ray
has nonzero one-norm. Primal points use the analogous exact affine correction
and block checks and are accepted as `primal_exact`.

## 256-bit interval fallback

If exact reconstruction does not close the proof, JSON candidate numbers have
already been loaded as `Float64`; the verifier does not retain or certify their
original JSON lexemes. It converts each finite value through Julia's canonical
`string(value)` decimal, parses that decimal exactly as a rational center, and
constructs an internal symmetric box with radius
`max(abs(center)/10^14, 1/10^30)`. It then runs at 256-bit `BigFloat` precision
with outward-rounded intervals. An exact-RREF-preconditioned Rump/Krawczyk
inclusion test must prove that one common affine-feasible point lies strictly
inside this internally constructed box. Separate residual intervals containing
zero are not enough.

The same included box must uniformly satisfy every cone constraint. The current
implementation proves this with interval Gershgorin lower bounds. For a Farkas
ray, the separation interval over that same box must have a strictly negative
upper endpoint. Successful fallbacks are `primal_interval` or
`farkas_interval`. Failure of inclusion, PSD closure, or strict separation is
inconclusive.

## Hash and audit chain

The persisted chain is:

1. Canonical `spec.json` is SHA-256 hashed. Its first 12 hexadecimal characters
   complete the directory name, together with exact `g`, `gamma`, `L`, `d`,
   rung, and scope selectors.
2. The spec deterministically rebuilds geometry, Hamiltonian, ordered basis,
   and canonical `problem.json`. The solver artifact must carry exactly that
   problem hash.
3. The candidate hash covers a domain tag plus the full ordered primal vector,
   or the full equality vector, PSD matrices, declared separation, and problem
   hash for a Farkas candidate. An accepted Farkas `certificate_hash` equals
   this candidate hash.
4. `verification.json` binds acceptance, method, problem hash, and candidate
   hash. Accepted Farkas records additionally bind `certificate_hash`.
5. `run_record.json` hashes `spec.json`, `problem.json`,
   `solver_artifact.json`, and `verification.json`, and repeats the code-tree,
   dependency, geometry, basis, problem-size, raw-status, runtime, diagnostic,
   verifier, verdict, and reason fields for audit.
6. Resume rebuilds the problem from the addressed spec, checks canonical bytes
   and every file hash, independently re-verifies the saved candidate, and
   compares all duplicated metadata. Corrupt completed directories are
   quarantined and recomputed.

## Why nonacceptance is `unknown`

`certified_infeasible` requires both an eligible raw infeasibility-certificate
status and an independently accepted exact or interval Farkas proof. `feasible`
similarly requires an eligible optimal/feasible raw status and an independently
accepted primal proof. A timeout, `SLOW_PROGRESS`, numerical error, missing
candidate, hash mismatch, nonfinite value, failed RREF inclusion, failed PSD
check, nonnegative separation, excessive runtime, or any unrecognized condition
cannot establish either proposition. It is therefore preserved as `unknown`,
with the raw status and machine-readable reason intact.
