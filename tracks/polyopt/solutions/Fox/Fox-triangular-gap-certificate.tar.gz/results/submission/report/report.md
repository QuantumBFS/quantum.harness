# Triangular J1-J2 bulk-gap certificate report

Result tier: `inconclusive`

The verified evidence does not supply a claim-safe bracket for a scientific tier.

## Unrestricted results

| gamma/J1 | L | d | rung | raw status | verifier | verdict | runtime (s) | problem hash | certificate hash |
|---:|---:|---:|:---:|:---|:---|:---|---:|:---|:---|
| 0.00 | 1 | 1 | A | OPTIMAL | primal_exact | feasible | 4.763812065124512 | [a0d41d771a5d8653366c6645b6ea889d416ba9885f46351de6534f412d516b4b](../g-0.10__gamma-0.00__L-1__d-1__rung-A__scope-unrestricted__82f1de5e5717/problem.json) | [fd84b2fbad2d15fcee526bcab6b752e1a1f29b79b729488396c366cdcc76243f](../g-0.10__gamma-0.00__L-1__d-1__rung-A__scope-unrestricted__82f1de5e5717/verification.json) |
| 0.10 | 1 | 1 | A | OPTIMAL | primal_exact | feasible | 0.7047650814056396 | [79fc26f78af4f0026a661ec1a99f3b5d68ad96014d86fc4318989457c4677670](../g-0.10__gamma-0.10__L-1__d-1__rung-A__scope-unrestricted__3cab08e08fae/problem.json) | [fd84b2fbad2d15fcee526bcab6b752e1a1f29b79b729488396c366cdcc76243f](../g-0.10__gamma-0.10__L-1__d-1__rung-A__scope-unrestricted__3cab08e08fae/verification.json) |
| 0.20 | 1 | 1 | A | OPTIMAL | primal_exact | feasible | 0.7033700942993164 | [3ea2d4837224789e79f1f96847b05ae99760ebf1d9f3b1e59429dc4f835458fb](../g-0.10__gamma-0.20__L-1__d-1__rung-A__scope-unrestricted__d3d388bae442/problem.json) | [fd84b2fbad2d15fcee526bcab6b752e1a1f29b79b729488396c366cdcc76243f](../g-0.10__gamma-0.20__L-1__d-1__rung-A__scope-unrestricted__d3d388bae442/verification.json) |
| 0.30 | 1 | 1 | A | OPTIMAL | primal_exact | feasible | 0.7903041839599609 | [c9ed5c5e4b122ea140e8db1e24bd7a6c84fab348f7354de02534f1320fa68890](../g-0.10__gamma-0.30__L-1__d-1__rung-A__scope-unrestricted__c1570f20e394/problem.json) | [fd84b2fbad2d15fcee526bcab6b752e1a1f29b79b729488396c366cdcc76243f](../g-0.10__gamma-0.30__L-1__d-1__rung-A__scope-unrestricted__c1570f20e394/verification.json) |
| 0.60 | 1 | 1 | A | OPTIMAL | primal_exact | feasible | 0.7181518077850342 | [330a9da0419a43f8f09c8edfd7f9e81ba6b7f98986e3a2749fd300cc18523c00](../g-0.10__gamma-0.60__L-1__d-1__rung-A__scope-unrestricted__b9d4df878ecb/problem.json) | [fd84b2fbad2d15fcee526bcab6b752e1a1f29b79b729488396c366cdcc76243f](../g-0.10__gamma-0.60__L-1__d-1__rung-A__scope-unrestricted__b9d4df878ecb/verification.json) |
| 1.20 | 1 | 1 | A | OPTIMAL | primal_exact | feasible | 0.7004549503326416 | [dc23093ffecee3563f3675e08d1b745ed6f0b8673d6cdbb5a8f66b6407b706b9](../g-0.10__gamma-1.20__L-1__d-1__rung-A__scope-unrestricted__ab9976976cf0/problem.json) | [fd84b2fbad2d15fcee526bcab6b752e1a1f29b79b729488396c366cdcc76243f](../g-0.10__gamma-1.20__L-1__d-1__rung-A__scope-unrestricted__ab9976976cf0/verification.json) |
| 2.40 | 1 | 1 | A | OPTIMAL | primal_exact | feasible | 0.7019901275634766 | [3ad4ab44c7afd4a68cc42471a8537e1cc08a63008ee0a8612f2a6b1c8fda6029](../g-0.10__gamma-2.40__L-1__d-1__rung-A__scope-unrestricted__79e32b699f63/problem.json) | [fd84b2fbad2d15fcee526bcab6b752e1a1f29b79b729488396c366cdcc76243f](../g-0.10__gamma-2.40__L-1__d-1__rung-A__scope-unrestricted__79e32b699f63/verification.json) |
| 4.80 | 1 | 1 | A | OPTIMAL | primal_exact | feasible | 0.7040629386901855 | [079201431dc639f8611c2f01d3e50f0cb0a5ea43a9a63dc802be9e90c5105b41](../g-0.10__gamma-4.80__L-1__d-1__rung-A__scope-unrestricted__3ed46a720e83/problem.json) | [fd84b2fbad2d15fcee526bcab6b752e1a1f29b79b729488396c366cdcc76243f](../g-0.10__gamma-4.80__L-1__d-1__rung-A__scope-unrestricted__3ed46a720e83/verification.json) |

## Claim-safe interpretation

- At relaxation (L=1, d=1, rung=A), gamma=0.00 J1 is independently verified feasible; this relaxation does not exclude gamma=0.00 J1.
- At relaxation (L=1, d=1, rung=A), gamma=0.10 J1 is independently verified feasible; this relaxation does not exclude gamma=0.10 J1.
- At relaxation (L=1, d=1, rung=A), gamma=0.20 J1 is independently verified feasible; this relaxation does not exclude gamma=0.20 J1.
- At relaxation (L=1, d=1, rung=A), gamma=0.30 J1 is independently verified feasible; this relaxation does not exclude gamma=0.30 J1.
- At relaxation (L=1, d=1, rung=A), gamma=0.60 J1 is independently verified feasible; this relaxation does not exclude gamma=0.60 J1.
- At relaxation (L=1, d=1, rung=A), gamma=1.20 J1 is independently verified feasible; this relaxation does not exclude gamma=1.20 J1.
- At relaxation (L=1, d=1, rung=A), gamma=2.40 J1 is independently verified feasible; this relaxation does not exclude gamma=2.40 J1.
- At relaxation (L=1, d=1, rung=A), gamma=4.80 J1 is independently verified feasible; this relaxation does not exclude gamma=4.80 J1.

## Exploratory symmetry-restricted appendix

These rows are restricted scouting evidence and do not support headline claims.

| gamma/J1 | L | d | rung | raw status | verifier | verdict | runtime (s) | problem hash | certificate hash |
|---:|---:|---:|:---:|:---|:---|:---|---:|:---|:---|
