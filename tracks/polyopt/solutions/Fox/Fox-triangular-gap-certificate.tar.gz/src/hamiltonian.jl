"""Auditable identity of an exact Hamiltonian on a validated triangular patch."""
struct HamiltonianManifest
    geometry_hash::String
    g::Rational{BigInt}
    operator_hash::String
end

exact_rational(value::Rational) = BigInt(numerator(value)) // BigInt(denominator(value))

"""Construct the exact spin-1/2 Heisenberg interaction on one undirected edge."""
function heisenberg_bond(i::Int, j::Int, coupling::Rational)
    i != j || throw(ArgumentError("a Heisenberg bond requires two distinct sites"))
    coefficient = exact_rational(coupling) / 4
    terms = Dict{PauliWord,ExactComplex}()
    for axis in (:X, :Y, :Z)
        terms[PauliWord(((i, axis), (j, axis)))] = ExactComplex(coefficient, 0//1)
    end
    ExactOperator(terms)
end

"""Assemble the exact J1-J2 Heisenberg Hamiltonian, retaining `g` as a rational."""
function triangular_hamiltonian(patch::TriangularPatch, g::Rational=1//10)
    hamiltonian = ExactOperator()
    for (i, j) in patch.e1
        hamiltonian += heisenberg_bond(i, j, 1//1)
    end
    for (i, j) in patch.e2
        hamiltonian += heisenberg_bond(i, j, g)
    end
    hamiltonian
end

"""Create a stable identity record for the exact Hamiltonian on `patch`."""
function HamiltonianManifest(patch::TriangularPatch, g::Rational=1//10)
    hamiltonian = triangular_hamiltonian(patch, g)
    HamiltonianManifest(geometry_manifest(patch).hash, exact_rational(g), operator_hash(hamiltonian))
end

const DENSE_PAULI = Dict{Symbol,Matrix{ComplexF64}}(
    :I => ComplexF64[1 0; 0 1],
    :X => ComplexF64[0 1; 1 0],
    :Y => ComplexF64[0 -im; im 0],
    :Z => ComplexF64[1 0; 0 -1],
)

function kron_factors(factors::AbstractVector{<:AbstractMatrix})
    result = ComplexF64[1]
    for factor in factors
        result = kron(result, factor)
    end
    result
end

function dense_pauli_word(word::PauliWord, site_count::Int)
    site_count >= 0 || throw(ArgumentError("site_count must be nonnegative"))
    axes = Dict(factor.site => factor.axis for factor in word.factors)
    all(site <= site_count for site in keys(axes)) ||
        throw(ArgumentError("Pauli word support exceeds site_count"))
    kron_factors([DENSE_PAULI[get(axes, site, :I)] for site in 1:site_count])
end

"""Convert an exact Pauli operator to a complex matrix only at this matrix boundary."""
function dense_matrix(operator::ExactOperator, site_count::Int)
    site_count >= 0 || throw(ArgumentError("site_count must be nonnegative"))
    dimension = 1 << site_count
    matrix = zeros(ComplexF64, dimension, dimension)
    for (word, coefficient) in operator
        matrix .+= ComplexF64(coefficient) .* dense_pauli_word(word, site_count)
    end
    matrix
end

function independent_bond_matrix(i::Int, j::Int, coupling::Rational, site_count::Int)
    i != j || throw(ArgumentError("a Heisenberg bond requires two distinct sites"))
    1 <= i <= site_count && 1 <= j <= site_count ||
        throw(ArgumentError("bond support exceeds site_count"))
    coefficient = Float64(coupling) / 4
    matrix = zeros(ComplexF64, 1 << site_count, 1 << site_count)
    for axis in (:X, :Y, :Z)
        factors = [site == i || site == j ? DENSE_PAULI[axis] : DENSE_PAULI[:I] for site in 1:site_count]
        matrix .+= coefficient .* kron_factors(factors)
    end
    matrix
end

"""Build a J1-J2 matrix by direct edge Kronecker products, independently of `dense_matrix`."""
function independent_ed_matrix(patch::TriangularPatch, g::Rational=1//10)
    site_count = length(patch.sites)
    matrix = zeros(ComplexF64, 1 << site_count, 1 << site_count)
    for (i, j) in patch.e1
        matrix .+= independent_bond_matrix(i, j, 1//1, site_count)
    end
    for (i, j) in patch.e2
        matrix .+= independent_bond_matrix(i, j, g, site_count)
    end
    matrix
end
