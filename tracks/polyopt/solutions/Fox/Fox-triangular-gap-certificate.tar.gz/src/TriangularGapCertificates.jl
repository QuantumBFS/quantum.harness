module TriangularGapCertificates

using SHA
using JSON3

include("types.jl")
include("geometry.jl")
include("pauli.jl")
include("hamiltonian.jl")
include("basis.jl")
include("conic_model.jl")
include("gap_relaxation.jl")
include("solver.jl")
include("certificate.jl")
include("runner.jl")
include("report.jl")

export Verdict,
       feasible,
       certified_infeasible,
       unknown,
       RunSpec,
       RawSolveRecord,
       VerificationRecord,
       RunRecord,
       is_headline,
       public_verdict,
       Axial,
       TriangularPatch,
       hex_distance,
       build_patch,
       eroded_sites,
       geometry_manifest,
       PauliFactor,
       PauliWord,
       ExactOperator,
       multiply,
       adjoint_word,
       support,
       operator_hash,
       heisenberg_bond,
       triangular_hamiltonian,
       dense_matrix,
       independent_ed_matrix,
       HamiltonianManifest,
       StateSymbol,
       StateMonomial,
       NCStateMonomial,
       RelaxationBasis,
       total_degree,
       rung_a,
       rung_b,
       assert_nested,
       AffineEntry,
       PSDBlock,
       ConicFeasibility,
       validate_conic,
       conic_json,
       parse_conic_json,
       canonical_hash,
       scalar_psd_fixture

export AbstractSolverBackend,
       MosekBackend,
       SolverArtifact,
       solve_problem,
       raw_status_record

export FarkasCandidate,
       verify_primal,
       verify_farkas,
       rational_reconstruct,
       exact_psd_ldlt,
       interval_psd_bound,
       verification_matches

export artifact_directory,
       load_run,
       run_one,
       run_phase1_grid,
       PHASE1_GAMMAS,
       PHASE1_ESCALATION_GAMMAS

export MonotonicityError,
       audit_monotonicity,
       verified_bracket,
       result_tier,
       build_report

export StatePolynomial,
       NCStatePolynomial,
       commutator,
       state_polynomial,
       state_symbol,
       moment_entry,
       gap_entry,
       realified_psd_block,
       build_gap_relaxation

end
