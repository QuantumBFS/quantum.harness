const _RUN_FILES = ("spec.json", "problem.json", "solver_artifact.json",
                    "verification.json")

Base.:(==)(left::RawSolveRecord, right::RawSolveRecord) =
    left.termination_status == right.termination_status &&
    left.primal_status == right.primal_status &&
    left.dual_status == right.dual_status &&
    left.runtime_seconds == right.runtime_seconds &&
    left.diagnostics == right.diagnostics && left.message == right.message
Base.:(==)(left::VerificationRecord, right::VerificationRecord) =
    left.accepted == right.accepted && left.method == right.method &&
    left.details == right.details
Base.:(==)(left::RunSpec, right::RunSpec) =
    left.g == right.g && left.gamma == right.gamma && left.L == right.L &&
    left.d == right.d && left.rung == right.rung && left.scope == right.scope &&
    left.timeout_seconds == right.timeout_seconds
Base.:(==)(left::RunRecord, right::RunRecord) =
    left.spec == right.spec && left.raw == right.raw &&
    left.verification == right.verification && left.verdict == right.verdict &&
    left.reason == right.reason

_exact_json(value::Rational) =
    (numerator=string(numerator(value)), denominator=string(denominator(value)))

function _spec_document(spec::RunSpec)
    (g=_exact_json(spec.g), gamma=_exact_json(spec.gamma), L=spec.L, d=spec.d,
     rung=String(spec.rung), scope=String(spec.scope),
     timeout_seconds=spec.timeout_seconds)
end

_spec_json(spec::RunSpec) = JSON3.write(_spec_document(spec))
_spec_hash(spec::RunSpec) = bytes2hex(SHA.sha256(codeunits(_spec_json(spec))))

function _two_decimal(value::Rational)
    scaled = value * 100
    denominator(scaled) == 1 ||
        throw(ArgumentError("content-addressed run ids require two-decimal g/gamma"))
    integer = Int(numerator(scaled))
    sign = integer < 0 ? "-" : ""
    magnitude = abs(integer)
    "$sign$(magnitude ÷ 100).$(lpad(string(magnitude % 100), 2, '0'))"
end

"""Return the immutable content-addressed directory for a run specification."""
function artifact_directory(output_root::AbstractString, spec::RunSpec)
    prefix = "g-$(_two_decimal(spec.g))__gamma-$(_two_decimal(spec.gamma))__" *
             "L-$(spec.L)__d-$(spec.d)__rung-$(spec.rung)__" *
             "scope-$(spec.scope)__"
    joinpath(abspath(output_root), prefix * _spec_hash(spec)[1:12])
end

_sha256_file(path) = bytes2hex(SHA.sha256(read(path)))

function _atomic_write(path::AbstractString, contents::AbstractString)
    directory = dirname(path)
    mkpath(directory)
    temporary = joinpath(directory, ".$(basename(path)).$(time_ns()).tmp")
    io = open(temporary, "w")
    try
        write(io, contents)
        endswith(contents, '\n') || write(io, '\n')
        flush(io)
        ccall(:fsync, Cint, (Cint,), Base.fd(io)) == 0 ||
            throw(SystemError("fsync", Libc.errno()))
        close(io)
        mv(temporary, path; force=true)
    catch
        isopen(io) && close(io)
        isfile(temporary) && rm(temporary; force=true)
        rethrow()
    end
    path
end

_atomic_write_json(path, document) = _atomic_write(path, JSON3.write(document))

function _basis_for(patch::TriangularPatch, spec::RunSpec)
    spec.rung == :A ? rung_a(patch, spec) : rung_b(patch, spec)
end

function _solver_document(artifact::SolverArtifact)
    blocks = artifact.dual_psd_blocks === nothing ? nothing :
        [[collect(block[row, :]) for row in axes(block, 1)]
         for block in artifact.dual_psd_blocks]
    (format="triangular-gap-solver-artifact-v1",
     problem_hash=artifact.problem_hash,
     raw=(termination_status=String(artifact.raw.termination_status),
          primal_status=String(artifact.raw.primal_status),
          dual_status=String(artifact.raw.dual_status),
          runtime_seconds=artifact.raw.runtime_seconds,
          diagnostics=artifact.raw.diagnostics,
          message=artifact.raw.message),
     primal_values=artifact.primal_values,
     dual_equalities=artifact.dual_equalities,
     dual_psd_blocks=blocks,
     solver_name=artifact.solver_name,
     solver_version=artifact.solver_version)
end

function _verification_document(verification::VerificationRecord)
    (format="triangular-gap-verification-v1", accepted=verification.accepted,
     method=String(verification.method), details=verification.details)
end

function _verify_artifact(problem::ConicFeasibility, artifact::SolverArtifact)
    primal = artifact.primal_values === nothing ? nothing : verify_primal(problem, artifact)
    primal !== nothing && primal.accepted && return primal
    if artifact.dual_equalities !== nothing && artifact.dual_psd_blocks !== nothing
        return verify_farkas(problem, artifact)
    end
    primal !== nothing && return primal
    VerificationRecord(false, :not_checked,
        Dict("problem_hash" => canonical_hash(problem),
             "reason" => "no_complete_candidate"))
end

_runtime_limit(spec::RunSpec) = min(spec.timeout_seconds, 300)

function _run_verdict(spec::RunSpec, raw::RawSolveRecord,
                      verification::VerificationRecord)
    raw.runtime_seconds > _runtime_limit(spec) && return unknown
    public_verdict(raw, verification)
end

function _final_reason(spec::RunSpec, raw::RawSolveRecord,
                       verification::VerificationRecord)
    if raw.runtime_seconds > _runtime_limit(spec)
        return "over_runtime_limit:" *
               "runtime=$(raw.runtime_seconds),limit=$(_runtime_limit(spec))"
    end
    if verification.accepted
        _run_verdict(spec, raw, verification) != unknown &&
            return "verified_$(verification.method)"
        return "raw_status_not_eligible:" *
               "termination=$(raw.termination_status)," *
               "primal=$(raw.primal_status),dual=$(raw.dual_status)"
    end
    get(verification.details, "reason", "verification_not_accepted")
end

function _manifest_versions()
    manifest = joinpath(dirname(@__DIR__), "Manifest.toml")
    isfile(manifest) || return Dict{String,String}()
    versions = Dict{String,String}()
    current = nothing
    for line in eachline(manifest)
        package_match = match(r"^\[\[deps\.([^]]+)\]\]$", line)
        if package_match !== nothing
            current = package_match.captures[1]
            continue
        end
        version_match = match(r"^version = \"([^\"]+)\"$", line)
        current === nothing || version_match === nothing ||
            (versions[current] = version_match.captures[1])
    end
    versions
end

function _code_tree_hash()
    root = dirname(@__DIR__)
    paths = String[]
    for relative in ("src", "scripts")
        directory = joinpath(root, relative)
        isdir(directory) || continue
        append!(paths, [joinpath(directory, name) for name in readdir(directory)
                        if endswith(name, ".jl")])
    end
    append!(paths, filter(isfile, [joinpath(root, "Project.toml"),
                                   joinpath(root, "Manifest.toml")]))
    sort!(paths)
    io = IOBuffer()
    for path in paths
        print(io, relpath(path, root), '\0')
        write(io, read(path))
        write(io, UInt8(0))
    end
    bytes2hex(SHA.sha256(take!(io)))
end

function _run_record_document(record::RunRecord, patch::TriangularPatch,
                              basis::RelaxationBasis, problem::ConicFeasibility,
                              artifact::SolverArtifact, file_hashes)
    manifest = geometry_manifest(patch)
    metadata = Dict(problem.metadata)
    margin = get(record.verification.details, "normalized_separation",
                 get(record.verification.details, "separation",
                     get(record.verification.details, "gershgorin_lower", "n/a")))
    (format="triangular-gap-run-record-v1",
     spec=_spec_document(record.spec),
     spec_hash=_spec_hash(record.spec),
     code_tree_hash=_code_tree_hash(),
     julia_version=string(VERSION),
     dependency_versions=_manifest_versions(),
     geometry=(hash=manifest.hash, sites=manifest.site_count,
               e1_edges=length(manifest.e1), e2_edges=length(manifest.e2), L=manifest.L),
     basis=(hash=basis.hash, word_count=length(basis.words),
            rung=String(basis.rung), scope=String(basis.scope)),
     problem_sizes=(variables=length(problem.variable_names),
                    equalities=length(problem.equalities),
                    psd_block_dimensions=[block.dimension for block in problem.psd_blocks],
                    psd_affine_entries=[length(block.variable_entries)
                                        for block in problem.psd_blocks],
                    inner_word_count=parse(Int, get(metadata, "inner_word_count", "0"))),
     raw=(termination_status=String(record.raw.termination_status),
          primal_status=String(record.raw.primal_status),
          dual_status=String(record.raw.dual_status),
          runtime_seconds=record.raw.runtime_seconds,
          diagnostics=record.raw.diagnostics, message=record.raw.message,
          solver_name=artifact.solver_name, solver_version=artifact.solver_version),
     verification=(accepted=record.verification.accepted,
                   method=String(record.verification.method), margin=margin,
                   details=record.verification.details),
     verdict=String(Symbol(record.verdict)), reason=record.reason,
     headline=is_headline(record.spec), files=file_hashes)
end

function _parse_rational_json(value)
    parse(Int, String(value.numerator)) // parse(Int, String(value.denominator))
end

function _parse_spec(value)
    RunSpec(_parse_rational_json(value.g), _parse_rational_json(value.gamma),
            Int(value.L), Int(value.d), Symbol(String(value.rung)),
            Symbol(String(value.scope)), Int(value.timeout_seconds))
end

function _string_dict(value)
    Dict{String,String}(String(key) => String(item) for (key, item) in pairs(value))
end

function _float_dict(value)
    Dict{String,Float64}(String(key) => Float64(item) for (key, item) in pairs(value))
end

function _parse_raw(value)
    RawSolveRecord(Symbol(String(value.termination_status)),
                   Symbol(String(value.primal_status)),
                   Symbol(String(value.dual_status)), Float64(value.runtime_seconds),
                   _float_dict(value.diagnostics), String(value.message))
end

_parse_float_vector(value) = value === nothing ? nothing : Float64.(collect(value))

function _parse_float_blocks(value)
    value === nothing && return nothing
    [Float64[block[row][col] for row in eachindex(block), col in eachindex(block[row])]
     for block in value]
end

function _parse_solver_artifact(document)
    raw = _parse_raw(document.raw)
    SolverArtifact(raw, String(document.problem_hash),
        _parse_float_vector(document.primal_values),
        _parse_float_vector(document.dual_equalities),
        _parse_float_blocks(document.dual_psd_blocks),
        String(document.solver_name), String(document.solver_version))
end

function _parse_verification(document)
    VerificationRecord(Bool(document.accepted), Symbol(String(document.method)),
                       _string_dict(document.details))
end

function _parse_verdict(value)
    text = String(value)
    text == "feasible" && return feasible
    text == "certified_infeasible" && return certified_infeasible
    text == "unknown" && return unknown
    throw(ArgumentError("invalid persisted verdict $text"))
end

function _same_verification(persisted::VerificationRecord,
                            fresh::VerificationRecord,
                            problem_hash::String)
    persisted.accepted == fresh.accepted || return false
    persisted.method == fresh.method || return false
    if fresh.accepted
        candidate_hash = get(fresh.details, "candidate_hash", "")
        isempty(candidate_hash) && return false
        verification_matches(persisted, problem_hash, candidate_hash) || return false
    end
    persisted.details == fresh.details || return false
    true
end

function _plain_json(value)
    if value === nothing || value isa Number || value isa AbstractString || value isa Bool
        return value
    elseif value isa NamedTuple
        return Dict(String(key) => _plain_json(item) for (key, item) in pairs(value))
    elseif value isa AbstractDict || value isa JSON3.Object
        return Dict(String(key) => _plain_json(item) for (key, item) in pairs(value))
    elseif value isa AbstractVector || value isa Tuple || value isa JSON3.Array
        return [_plain_json(item) for item in value]
    end
    throw(ArgumentError("unsupported JSON audit value $(typeof(value))"))
end

"""Load and independently validate a completed run directory."""
function load_run(directory::AbstractString)
    directory = abspath(directory)
    record_path = joinpath(directory, "run_record.json")
    isfile(record_path) || throw(ArgumentError("run_record.json is missing"))
    record_document = JSON3.read(read(record_path, String))
    String(record_document.format) == "triangular-gap-run-record-v1" ||
        throw(ArgumentError("unsupported run record format"))
    file_hashes = Dict(String(key) => String(value)
                       for (key, value) in pairs(record_document.files))
    Set(keys(file_hashes)) == Set(_RUN_FILES) ||
        throw(ArgumentError("run record file hash set is incomplete"))
    for name in _RUN_FILES
        path = joinpath(directory, name)
        isfile(path) || throw(ArgumentError("$name is missing"))
        _sha256_file(path) == file_hashes[name] ||
            throw(ArgumentError("$name hash mismatch"))
    end

    spec_text = read(joinpath(directory, "spec.json"), String)
    spec_document = JSON3.read(spec_text)
    spec = _parse_spec(spec_document)
    spec_text == _spec_json(spec) * "\n" ||
        throw(ArgumentError("spec.json is not the canonical addressed specification"))
    _parse_spec(record_document.spec) == spec ||
        throw(ArgumentError("run record spec contradicts hashed spec.json"))
    basename(directory) == basename(artifact_directory(dirname(directory), spec)) ||
        throw(ArgumentError("run directory is not the canonical spec address"))
    _spec_hash(spec) == String(record_document.spec_hash) ||
        throw(ArgumentError("persisted spec hash mismatch"))

    patch = build_patch(spec.L)
    basis = _basis_for(patch, spec)
    expected_problem = build_gap_relaxation(patch, basis, spec)
    problem_text = read(joinpath(directory, "problem.json"), String)
    problem = parse_conic_json(problem_text)
    canonical_hash(problem) == canonical_hash(expected_problem) ||
        throw(ArgumentError("stored problem does not match the addressed specification"))
    problem_text == conic_json(expected_problem) * "\n" ||
        throw(ArgumentError("problem.json is not the canonical addressed problem"))
    artifact_document = JSON3.read(read(joinpath(directory, "solver_artifact.json"), String))
    artifact = _parse_solver_artifact(artifact_document)
    canonical_hash(problem) == artifact.problem_hash ||
        throw(ArgumentError("solver artifact problem hash mismatch"))
    persisted = _parse_verification(
        JSON3.read(read(joinpath(directory, "verification.json"), String)))
    fresh = _verify_artifact(problem, artifact)
    _same_verification(persisted, fresh, canonical_hash(problem)) ||
        throw(ArgumentError("persisted verification does not match current problem and candidate"))

    raw = _parse_raw(record_document.raw)
    raw == artifact.raw || throw(ArgumentError("run record raw status mismatch"))
    verdict = _parse_verdict(record_document.verdict)
    verdict == _run_verdict(spec, raw, fresh) ||
        throw(ArgumentError("run record public verdict mismatch"))
    reason = String(record_document.reason)
    reason == _final_reason(spec, raw, fresh) ||
        throw(ArgumentError("run record reason mismatch"))
    Bool(record_document.headline) == is_headline(spec) ||
        throw(ArgumentError("run record headline flag mismatch"))
    record = RunRecord(spec, raw, fresh, verdict, reason)
    expected_document = _run_record_document(record, patch, basis, expected_problem,
                                             artifact, file_hashes)
    _plain_json(record_document) ==
        _plain_json(JSON3.read(JSON3.write(expected_document))) ||
        throw(ArgumentError("run record duplicated audit metadata mismatch"))
    record
end

function _quarantine!(directory::AbstractString, output_root::AbstractString)
    isdir(directory) || return nothing
    root = joinpath(abspath(output_root), "corrupt")
    mkpath(root)
    token = bytes2hex(SHA.sha256(codeunits("$(time_ns()):$directory")))[1:12]
    destination = joinpath(root, basename(directory) * "--" * token)
    mv(directory, destination)
    destination
end

"""Build, solve, independently verify, and atomically persist one experiment."""
function run_one(spec::RunSpec; output_root::AbstractString,
                 solver::AbstractSolverBackend=MosekBackend())
    directory = artifact_directory(output_root, spec)
    if isdir(directory) && isfile(joinpath(directory, "run_record.json"))
        try
            return load_run(directory)
        catch
            _quarantine!(directory, output_root)
        end
    end
    mkpath(directory)
    for name in readdir(directory)
        endswith(name, ".tmp") && rm(joinpath(directory, name); force=true)
    end

    patch = build_patch(spec.L)
    basis = _basis_for(patch, spec)
    problem = build_gap_relaxation(patch, basis, spec)
    artifact = solve_problem(problem, solver, spec.timeout_seconds)
    verification = _verify_artifact(problem, artifact)
    verdict = _run_verdict(spec, artifact.raw, verification)
    record = RunRecord(spec, artifact.raw, verification, verdict,
                       _final_reason(spec, artifact.raw, verification))

    _atomic_write(joinpath(directory, "spec.json"), _spec_json(spec))
    _atomic_write(joinpath(directory, "problem.json"), conic_json(problem))
    _atomic_write_json(joinpath(directory, "solver_artifact.json"),
                       _solver_document(artifact))
    _atomic_write_json(joinpath(directory, "verification.json"),
                       _verification_document(verification))
    hashes = Dict(name => _sha256_file(joinpath(directory, name)) for name in _RUN_FILES)
    _atomic_write_json(joinpath(directory, "run_record.json"),
                       _run_record_document(record, patch, basis, problem,
                                            artifact, hashes))
    load_run(directory)
end

const PHASE1_GAMMAS = (0//1, 3//10, 1//5, 1//10)
const PHASE1_ESCALATION_GAMMAS = (3//5, 6//5, 12//5, 24//5)

function _fallback_config(config, fallbacks)
    for fallback in fallbacks
        fallback_rung = Symbol(fallback.rung)
        smaller = fallback_rung == :A || Int(fallback.L) < config.L ||
                  Int(fallback.d) < config.d
        smaller && return (L=Int(fallback.L), d=Int(fallback.d), rung=fallback_rung)
    end
    config.rung == :B ? (L=config.L, d=config.d, rung=:A) : nothing
end

function _needs_fallback(record::RunRecord)
    record.spec.rung == :B || return false
    record.raw.termination_status in (:TIME_LIMIT, :SLOW_PROGRESS) && return true
    threshold = min(record.spec.timeout_seconds, 300)
    record.raw.runtime_seconds >= threshold
end

"""Run the frozen Phase-1 order, with only verified outcomes controlling escalation."""
function run_phase1_grid(; L::Integer, d::Integer, rung::Symbol,
                         output_root::AbstractString,
                         timeout_seconds::Integer=300,
                         scope::Symbol=:unrestricted,
                         solver::AbstractSolverBackend=MosekBackend(),
                         fallback_configs=NamedTuple[])
    config = (L=Int(L), d=Int(d), rung=rung)
    records = RunRecord[]
    function run_gamma(gamma)
        spec = RunSpec(1//10, gamma, config.L, config.d, config.rung,
                       scope, Int(timeout_seconds))
        record = run_one(spec; output_root, solver)
        push!(records, record)
        if _needs_fallback(record)
            fallback = _fallback_config(config, fallback_configs)
            if fallback !== nothing
                fallback_spec = RunSpec(1//10, gamma, fallback.L, fallback.d,
                                        fallback.rung, scope, Int(timeout_seconds))
                push!(records, run_one(fallback_spec; output_root, solver))
            end
        end
        record
    end

    initial = RunRecord[run_gamma(gamma) for gamma in PHASE1_GAMMAS]
    gamma_three = only(filter(record -> record.spec.gamma == 3//10, initial))
    has_upper = any(record -> record.verdict == certified_infeasible, initial)
    if gamma_three.verdict == feasible && !has_upper
        for gamma in PHASE1_ESCALATION_GAMMAS
            run_gamma(gamma).verdict == certified_infeasible && break
        end
    end
    records
end
