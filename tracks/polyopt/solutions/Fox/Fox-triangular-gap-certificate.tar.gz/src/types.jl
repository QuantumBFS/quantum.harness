@enum Verdict feasible certified_infeasible unknown

struct RunSpec
    g::Rational{Int}
    gamma::Rational{Int}
    L::Int
    d::Int
    rung::Symbol
    scope::Symbol
    timeout_seconds::Int
    function RunSpec(g, gamma, L, d, rung, scope, timeout_seconds)
        g == 1//10 || throw(ArgumentError("Phase 1 requires g = 1//10"))
        gamma >= 0 || throw(ArgumentError("gamma must be nonnegative"))
        rung in (:A, :B) || throw(ArgumentError("rung must be :A or :B"))
        scope in (:unrestricted, :exploratory_symmetry_restricted) || throw(ArgumentError("invalid scope"))
        timeout_seconds > 0 || throw(ArgumentError("timeout must be positive"))
        new(g, gamma, L, d, rung, scope, timeout_seconds)
    end
end

struct RawSolveRecord
    termination_status::Symbol
    primal_status::Symbol
    dual_status::Symbol
    runtime_seconds::Float64
    diagnostics::Dict{String,Float64}
    message::String
end

struct VerificationRecord
    accepted::Bool
    method::Symbol
    details::Dict{String,String}
end

struct RunRecord
    spec::RunSpec
    raw::RawSolveRecord
    verification::VerificationRecord
    verdict::Verdict
    reason::String
end

is_headline(spec::RunSpec) = spec.scope == :unrestricted

function public_verdict(raw::RawSolveRecord, verification::VerificationRecord)::Verdict
    raw.runtime_seconds > 300 && return unknown
    verified_farkas = verification.accepted &&
        verification.method in (:farkas_exact, :farkas_interval)
    farkas_status = raw.termination_status == :INFEASIBLE &&
        raw.dual_status in (:INFEASIBILITY_CERTIFICATE,
                            :NEARLY_INFEASIBILITY_CERTIFICATE)
    verified_farkas && farkas_status && return certified_infeasible

    verified_primal = verification.accepted &&
        verification.method in (:primal_exact, :primal_interval)
    primal_status = raw.termination_status == :OPTIMAL &&
        raw.primal_status in (:FEASIBLE_POINT, :NEARLY_FEASIBLE_POINT)
    verified_primal && primal_status && return feasible
    return unknown
end
