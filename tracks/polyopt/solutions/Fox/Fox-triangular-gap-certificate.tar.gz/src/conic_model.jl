const ExactRational = Rational{BigInt}

_exact_rational(value::Rational) = BigInt(numerator(value)) // BigInt(denominator(value))
_exact_rational(value::Integer) = BigInt(value) // BigInt(1)

struct AffineEntry
    row::Int
    col::Int
    variable::Int
    coefficient::ExactRational

    function AffineEntry(row::Int, col::Int, variable::Int, coefficient::ExactRational)
        row >= 1 || throw(ArgumentError("row must be positive"))
        col >= row || throw(ArgumentError("PSD entries must use upper-triangle storage"))
        variable >= 1 || throw(ArgumentError("variable index must be positive"))
        new(row, col, variable, coefficient)
    end
end

AffineEntry(row::Integer, col::Integer, variable::Integer, coefficient::Rational) =
    AffineEntry(Int(row), Int(col), Int(variable), _exact_rational(coefficient))
AffineEntry(row::Integer, col::Integer, variable::Integer, coefficient::Integer) =
    AffineEntry(Int(row), Int(col), Int(variable), _exact_rational(coefficient))

Base.:(==)(left::AffineEntry, right::AffineEntry) =
    left.row == right.row && left.col == right.col && left.variable == right.variable &&
    left.coefficient == right.coefficient
Base.hash(entry::AffineEntry, seed::UInt) =
    hash((entry.row, entry.col, entry.variable, entry.coefficient), seed)

function _constant_key(entry)
    entry isa Tuple && length(entry) == 3 ||
        throw(ArgumentError("constant entries must be (row, col, value)"))
    (Int(entry[1]), Int(entry[2]))
end

_variable_key(entry::AffineEntry) = (entry.row, entry.col, entry.variable)
_variable_key(entry) = throw(ArgumentError("variable entries must be AffineEntry values"))

_canonicalization_entries(entries::Union{AbstractArray,Tuple}) = entries
_canonicalization_entries(entries) = collect(entries)

function _canonical_psd_constants(dimension::Int, entries)
    canonicalization_entries = _canonicalization_entries(entries)
    canonical = Tuple{Int,Int,ExactRational}[]
    previous_key = nothing
    previous_value = BigInt(0) // BigInt(1)
    sorted = true
    for entry in canonicalization_entries
        key = _constant_key(entry)
        row, col, value = entry
        row = Int(row)
        col = Int(col)
        1 <= row <= col <= dimension ||
            throw(ArgumentError("invalid upper-triangle constant entry"))
        if previous_key !== nothing
            if isless(key, previous_key)
                sorted = false
                break
            elseif key != previous_key
                iszero(previous_value) || push!(canonical,
                    (previous_key[1], previous_key[2], previous_value))
                previous_value = BigInt(0) // BigInt(1)
            end
        end
        previous_key = key
        previous_value += _exact_rational(value)
    end
    if sorted
        previous_key === nothing || iszero(previous_value) || push!(canonical,
            (previous_key[1], previous_key[2], previous_value))
        return Tuple(canonical)
    end

    constants = Dict{Tuple{Int,Int},ExactRational}()
    for entry in canonicalization_entries
        entry isa Tuple && length(entry) == 3 ||
            throw(ArgumentError("constant entries must be (row, col, value)"))
        row, col, value = entry
        row = Int(row)
        col = Int(col)
        1 <= row <= col <= dimension ||
            throw(ArgumentError("invalid upper-triangle constant entry"))
        key = (row, col)
        constants[key] = get(constants, key, BigInt(0) // BigInt(1)) +
                         _exact_rational(value)
    end
    Tuple((row, col, value) for ((row, col), value) in
        sort!(collect(constants); by=first) if !iszero(value))
end

function _canonical_psd_variables(dimension::Int, entries)
    canonicalization_entries = _canonicalization_entries(entries)
    canonical = AffineEntry[]
    previous_key = nothing
    previous_value = BigInt(0) // BigInt(1)
    sorted = true
    for entry in canonicalization_entries
        entry isa AffineEntry ||
            throw(ArgumentError("variable entries must be AffineEntry values"))
        1 <= entry.row <= entry.col <= dimension ||
            throw(ArgumentError("invalid upper-triangle affine entry"))
        key = _variable_key(entry)
        if previous_key !== nothing
            if isless(key, previous_key)
                sorted = false
                break
            elseif key != previous_key
                iszero(previous_value) || push!(canonical,
                    AffineEntry(previous_key[1], previous_key[2], previous_key[3], previous_value))
                previous_value = BigInt(0) // BigInt(1)
            end
        end
        previous_key = key
        previous_value += entry.coefficient
    end
    if sorted
        previous_key === nothing || iszero(previous_value) || push!(canonical,
            AffineEntry(previous_key[1], previous_key[2], previous_key[3], previous_value))
        return Tuple(canonical)
    end

    variables = Dict{Tuple{Int,Int,Int},ExactRational}()
    for entry in canonicalization_entries
        entry isa AffineEntry ||
            throw(ArgumentError("variable entries must be AffineEntry values"))
        1 <= entry.row <= entry.col <= dimension ||
            throw(ArgumentError("invalid upper-triangle affine entry"))
        key = (entry.row, entry.col, entry.variable)
        variables[key] = get(variables, key, BigInt(0) // BigInt(1)) + entry.coefficient
    end
    Tuple(AffineEntry(row, col, variable, value) for
        ((row, col, variable), value) in sort!(collect(variables); by=first) if !iszero(value))
end

struct PSDBlock
    dimension::Int
    constant_entries::Tuple
    variable_entries::Tuple

    function PSDBlock(dimension::Integer, constant_entries, variable_entries)
        dim = Int(dimension)
        dim >= 1 || throw(ArgumentError("PSD block dimension must be positive"))

        canonical_constants = _canonical_psd_constants(dim, constant_entries)
        canonical_variables = _canonical_psd_variables(dim, variable_entries)

        new(dim, canonical_constants, canonical_variables)
    end
end

Base.:(==)(left::PSDBlock, right::PSDBlock) =
    left.dimension == right.dimension && left.constant_entries == right.constant_entries &&
    left.variable_entries == right.variable_entries
Base.hash(block::PSDBlock, seed::UInt) =
    hash((block.dimension, block.constant_entries, block.variable_entries), seed)

struct ConicFeasibility
    variable_names::Tuple
    equalities::Tuple
    psd_blocks::Tuple
    metadata::Tuple

    function ConicFeasibility(variable_names, equalities, psd_blocks, metadata)
        names = Tuple(String(name) for name in variable_names)
        length(unique(names)) == length(names) ||
            throw(ArgumentError("variable names must be unique"))
        canonical_equalities = Tuple(_canonical_equality(eq, length(names)) for eq in equalities)
        blocks = Tuple(block for block in psd_blocks)
        all(block -> block isa PSDBlock, blocks) ||
            throw(ArgumentError("psd_blocks must contain PSDBlock values"))

        metadata_values = Dict{String,String}()
        for (key, value) in metadata
            string_key = String(key)
            haskey(metadata_values, string_key) &&
                throw(ArgumentError("metadata keys must be unique"))
            metadata_values[string_key] = String(value)
        end
        canonical_metadata = Tuple(key => metadata_values[key] for key in
                                   sort!(collect(keys(metadata_values))))
        problem = new(names, canonical_equalities, blocks, canonical_metadata)
        validate_conic(problem)
        problem
    end
end

function _canonical_equality(equality, variable_count::Int)
    coefficients, rhs = equality
    combined = Dict{Int,ExactRational}()
    for term in coefficients
        variable = Int(first(term))
        1 <= variable <= variable_count || throw(ArgumentError("equality variable index out of range"))
        combined[variable] = get(combined, variable, BigInt(0) // BigInt(1)) +
                             _exact_rational(last(term))
    end
    terms = Tuple(variable => value for (variable, value) in sort!(collect(combined); by=first)
                  if !iszero(value))
    (terms, _exact_rational(rhs))
end

function _require_strictly_increasing(keys, label::AbstractString)
    previous = nothing
    for key in keys
        if previous !== nothing && !isless(previous, key)
            throw(ArgumentError("$label must be strictly sorted and unique"))
        end
        previous = key
    end
    nothing
end

function validate_conic(problem::ConicFeasibility)
    variable_count = length(problem.variable_names)
    all(name -> name isa String, problem.variable_names) ||
        throw(ArgumentError("variable names must be strings"))
    length(unique(problem.variable_names)) == variable_count ||
        throw(ArgumentError("variable names must be unique"))
    for equality in problem.equalities
        equality isa Tuple && length(equality) == 2 ||
            throw(ArgumentError("equalities must be (coefficients, rhs) tuples"))
        coefficients, rhs = equality
        coefficients isa Tuple || throw(ArgumentError("equality coefficients must be a tuple"))
        rhs isa ExactRational || throw(ArgumentError("equality rhs must be Rational{BigInt}"))
        _require_strictly_increasing((first(term) for term in coefficients),
                                     "equality variable indices")
        for term in coefficients
            term isa Pair{Int,ExactRational} ||
                throw(ArgumentError("equality terms must contain exact indexed rationals"))
            variable, coefficient = first(term), last(term)
            1 <= variable <= variable_count || throw(ArgumentError("equality variable index out of range"))
            iszero(coefficient) && throw(ArgumentError("zero equality coefficient is not canonical"))
        end
    end
    for block in problem.psd_blocks
        block isa PSDBlock || throw(ArgumentError("psd_blocks must contain PSDBlock values"))
        block.dimension >= 1 || throw(ArgumentError("PSD block dimension must be positive"))
        _require_strictly_increasing(((entry[1], entry[2]) for entry in block.constant_entries),
                                     "PSD constant entry keys")
        for entry in block.constant_entries
            entry isa Tuple{Int,Int,ExactRational} ||
                throw(ArgumentError("PSD constant entries must contain exact indexed rationals"))
            row, col, coefficient = entry
            1 <= row <= col <= block.dimension || throw(ArgumentError("invalid PSD constant entry"))
            iszero(coefficient) && throw(ArgumentError("zero PSD constant entry is not canonical"))
        end
        _require_strictly_increasing(((entry.row, entry.col, entry.variable)
                                      for entry in block.variable_entries),
                                     "PSD affine entry keys")
        for entry in block.variable_entries
            entry isa AffineEntry || throw(ArgumentError("PSD affine entries must be AffineEntry values"))
            1 <= entry.row <= entry.col <= block.dimension || throw(ArgumentError("invalid PSD affine entry"))
            1 <= entry.variable <= variable_count || throw(ArgumentError("PSD variable index out of range"))
            entry.coefficient isa ExactRational ||
                throw(ArgumentError("PSD affine coefficients must be Rational{BigInt}"))
            iszero(entry.coefficient) && throw(ArgumentError("zero PSD affine entry is not canonical"))
        end
    end
    _require_strictly_increasing((first(entry) for entry in problem.metadata), "metadata keys")
    for entry in problem.metadata
        entry isa Pair{String,String} || throw(ArgumentError("metadata must contain string pairs"))
    end
    true
end

_rational_json(value::ExactRational) =
    (numerator=string(numerator(value)), denominator=string(denominator(value)))

function conic_json(problem::ConicFeasibility)
    validate_conic(problem)
    document = (
        format="triangular-gap-conic-v1",
        variable_names=collect(problem.variable_names),
        equalities=[(coefficients=[(variable=variable, coefficient=_rational_json(value))
                                  for (variable, value) in coefficients],
                     rhs=_rational_json(rhs)) for (coefficients, rhs) in problem.equalities],
        psd_blocks=[(dimension=block.dimension,
                     constant_entries=[(row=row, col=col, coefficient=_rational_json(value))
                                       for (row, col, value) in block.constant_entries],
                     variable_entries=[(row=entry.row, col=entry.col, variable=entry.variable,
                                        coefficient=_rational_json(entry.coefficient))
                                       for entry in block.variable_entries])
                    for block in problem.psd_blocks],
        metadata=[(key=first(pair), value=last(pair)) for pair in problem.metadata],
    )
    JSON3.write(document)
end

function _parse_rational(value)
    numerator = parse(BigInt, String(value.numerator))
    denominator = parse(BigInt, String(value.denominator))
    denominator > 0 || throw(ArgumentError("rational denominator must be positive"))
    numerator // denominator
end

function parse_conic_json(encoded::AbstractString)
    document = JSON3.read(encoded)
    String(document.format) == "triangular-gap-conic-v1" || throw(ArgumentError("unsupported conic format"))
    equalities = [([Int(term.variable) => _parse_rational(term.coefficient)
                    for term in equality.coefficients], _parse_rational(equality.rhs))
                  for equality in document.equalities]
    blocks = [PSDBlock(Int(block.dimension),
                       [(Int(entry.row), Int(entry.col), _parse_rational(entry.coefficient))
                        for entry in block.constant_entries],
                       [AffineEntry(Int(entry.row), Int(entry.col), Int(entry.variable),
                                    _parse_rational(entry.coefficient))
                        for entry in block.variable_entries])
              for block in document.psd_blocks]
    metadata = Dict(String(entry.key) => String(entry.value) for entry in document.metadata)
    ConicFeasibility(String.(document.variable_names), equalities, blocks, metadata)
end

const _canonical_hash_cache_lock = ReentrantLock()
const _canonical_hash_cache_problem = Ref{Any}(nothing)
const _canonical_hash_cache_digest = Ref{Any}(nothing)
const _NATIVE_SHA256_MIN_BYTES = 1_048_576
const _OPENSSL_SHA256_COMMAND = Cmd(["openssl", "dgst", "-sha256"])
const _SHA256_HEX_PATTERN = r"^[0-9a-f]{64}$"

_stdlib_sha256_hex(data::AbstractString) = bytes2hex(SHA.sha256(codeunits(data)))

function _parse_native_sha256_output(output::AbstractString)
    matches = collect(eachmatch(
        r"(?i)(?<![[:alnum:]_])[0-9a-f]{64}(?![[:alnum:]_])",
        output,
    ))
    length(matches) == 1 || return nothing
    trailing = match(
        r"(?i)(?<![[:alnum:]_])([0-9a-f]{64})(?![[:alnum:]_])\s*$",
        output,
    )
    trailing === nothing && return nothing
    lowercase(only(trailing.captures))
end

_open_native_sha_process(command::Cmd) = open(command, "r+")

function _close_and_reap_native_sha_process(process)
    for endpoint in (process.in, process.out)
        try
            isopen(endpoint) && close(endpoint)
        catch
        end
    end
    try
        process_running(process) && kill(process)
    catch
    end
    try
        wait(process)
    catch
    end
    nothing
end

function _native_sha256_hex(
    data::AbstractString,
    command::Cmd=_OPENSSL_SHA256_COMMAND,
    process_opener=_open_native_sha_process,
)
    process = nothing
    try
        process = process_opener(command)
        write(process, codeunits(data))
        close(process.in)
        output = read(process, String)
        success(process) || return nothing
        _parse_native_sha256_output(output)
    catch
        nothing
    finally
        process === nothing || _close_and_reap_native_sha_process(process)
    end
end

function _canonical_sha256_hex(
    data::AbstractString;
    native_command::Cmd=_OPENSSL_SHA256_COMMAND,
    native_helper=_native_sha256_hex,
)
    if ncodeunits(data) >= _NATIVE_SHA256_MIN_BYTES
        digest = try
            native_helper(data, native_command)
        catch
            nothing
        end
        digest isa String && occursin(_SHA256_HEX_PATTERN, digest) && return digest
    end
    _stdlib_sha256_hex(data)
end

function canonical_hash(problem::ConicFeasibility)
    lock(_canonical_hash_cache_lock) do
        if _canonical_hash_cache_problem[] === problem
            return _canonical_hash_cache_digest[]::String
        end
        digest = _canonical_sha256_hex(conic_json(problem))
        _canonical_hash_cache_problem[] = problem
        _canonical_hash_cache_digest[] = digest
        digest
    end
end

function scalar_psd_fixture(constant::Rational)
    ConicFeasibility(String[], Tuple[], [PSDBlock(1, [(1, 1, constant)], AffineEntry[])],
                     Dict("fixture" => "scalar_psd"))
end

scalar_psd_fixture(constant::Integer) = scalar_psd_fixture(constant // 1)

Base.:(==)(left::ConicFeasibility, right::ConicFeasibility) =
    left.variable_names == right.variable_names && left.equalities == right.equalities &&
    left.psd_blocks == right.psd_blocks && left.metadata == right.metadata
Base.hash(problem::ConicFeasibility, seed::UInt) = hash(canonical_hash(problem), seed)
