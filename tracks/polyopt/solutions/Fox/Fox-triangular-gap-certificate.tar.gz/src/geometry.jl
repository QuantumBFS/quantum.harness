struct Axial
    q::Int
    r::Int
end

Base.:+(a::Axial, b::Axial) = Axial(a.q + b.q, a.r + b.r)
Base.isless(a::Axial, b::Axial) = (a.q, a.r) < (b.q, b.r)

const D1 = (Axial(1, 0), Axial(0, 1), Axial(1, -1))
const D2 = (Axial(1, 1), Axial(2, -1), Axial(1, -2))
const ALL_D1 = (D1..., map(d -> Axial(-d.q, -d.r), D1)...)
const ALL_D2 = (D2..., map(d -> Axial(-d.q, -d.r), D2)...)

hex_distance(a::Axial) = max(abs(a.q), abs(a.r), abs(a.q + a.r))

struct TriangularPatch
    L::Int
    sites::Vector{Axial}
    index::Dict{Axial,Int}
    e1::Vector{Tuple{Int,Int}}
    e2::Vector{Tuple{Int,Int}}
end

struct GeometryManifest
    L::Int
    site_count::Int
    e1::Vector{Tuple{Int,Int}}
    e2::Vector{Tuple{Int,Int}}
    hash::String
end

function shell_edges(sites, index, displacements)
    edges = Tuple{Int,Int}[]
    for a in sites, d in displacements
        b = a + d
        haskey(index, b) || continue
        i, j = index[a], index[b]
        push!(edges, i < j ? (i, j) : (j, i))
    end
    sort!(unique!(edges))
end

function build_patch(L::Int)
    L >= 1 || throw(ArgumentError("L must be at least 1"))
    sites = sort([Axial(q, r) for q in -L:L for r in -L:L if hex_distance(Axial(q, r)) <= L])
    index = Dict(site => i for (i, site) in enumerate(sites))
    TriangularPatch(L, sites, index, shell_edges(sites, index, D1), shell_edges(sites, index, D2))
end

function eroded_sites(patch::TriangularPatch, required_offsets)
    Set(a for a in patch.sites if all(haskey(patch.index, a + d) for d in required_offsets))
end

"""Enumerate undirected edges by the axial squared-distance form independently of D1/D2."""
function squared_distance_edges(sites, squared_distance::Int)
    edges = Tuple{Int,Int}[]
    for i in eachindex(sites), j in (i + 1):length(sites)
        a, b = sites[i], sites[j]
        dq, dr = a.q - b.q, a.r - b.r
        dq^2 + dq * dr + dr^2 == squared_distance && push!(edges, (i, j))
    end
    edges
end

function manifest_hash(patch::TriangularPatch)
    canonical = join((
        "L=$(patch.L)",
        "sites=" * join(("$(site.q),$(site.r)" for site in patch.sites), ";"),
        "e1=" * join(("$(i),$(j)" for (i, j) in patch.e1), ";"),
        "e2=" * join(("$(i),$(j)" for (i, j) in patch.e2), ";"),
    ), "\n")
    bytes2hex(sha256(canonical))
end

function geometry_manifest(patch::TriangularPatch)
    e1_by_distance = squared_distance_edges(patch.sites, 1)
    e2_by_distance = squared_distance_edges(patch.sites, 3)
    patch.e1 == e1_by_distance || throw(ArgumentError("e1 does not match the squared-distance-1 edge set"))
    patch.e2 == e2_by_distance || throw(ArgumentError("e2 does not match the squared-distance-3 edge set"))
    GeometryManifest(patch.L, length(patch.sites), copy(patch.e1), copy(patch.e2), manifest_hash(patch))
end
