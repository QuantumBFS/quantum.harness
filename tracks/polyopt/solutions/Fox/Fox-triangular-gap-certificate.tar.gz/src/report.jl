struct MonotonicityError <: Exception
    message::String
end

Base.showerror(io::IO, error::MonotonicityError) = print(io, error.message)

const _VERIFIED_REPORT_METHODS =
    (:primal_exact, :primal_interval, :farkas_exact, :farkas_interval)
const _NESTING_AUDIT_CACHE = Set{Tuple{Int,Int,Symbol}}()

_relaxation_key(record::RunRecord) =
    (record.spec.g, record.spec.L, record.spec.d, record.spec.rung,
     record.spec.scope)

_geometry_key(record::RunRecord) =
    (record.spec.g, record.spec.L, record.spec.d, record.spec.scope)

function _valid_hash(value::AbstractString)
    length(value) == 64 || return false
    all(character -> character in '0':'9' || character in 'a':'f', value)
end

function _validate_report_record(record::RunRecord)
    expected = _run_verdict(record.spec, record.raw, record.verification)
    record.verdict == expected ||
        throw(ArgumentError("run verdict is not consistent with independently verified status"))

    if record.verification.accepted
        record.verification.method in _VERIFIED_REPORT_METHODS ||
            throw(ArgumentError("accepted record does not name an independent verifier method"))
        problem_hash = get(record.verification.details, "problem_hash", "")
        candidate_hash = get(record.verification.details, "candidate_hash", "")
        _valid_hash(problem_hash) && _valid_hash(candidate_hash) ||
            throw(ArgumentError("accepted verification lacks canonical problem/candidate hash binding"))
        verification_matches(record.verification, problem_hash, candidate_hash) ||
            throw(ArgumentError("accepted verification does not match its persisted hash binding"))
    elseif record.verdict != unknown
        throw(ArgumentError("an unaccepted verification cannot support a public verdict"))
    end
    record.reason == _final_reason(record.spec, record.raw, record.verification) ||
        throw(ArgumentError("run reason is not consistent with current verification semantics"))
    record
end

function _group_records(records)
    groups = Dict{Tuple,Vector{RunRecord}}()
    for record in records
        _validate_report_record(record)
        push!(get!(groups, _relaxation_key(record), RunRecord[]), record)
    end
    groups
end

function _verified_points(group::Vector{RunRecord})
    by_gamma = Dict{Rational{Int},Set{Verdict}}()
    for record in group
        record.verdict == unknown && continue
        push!(get!(by_gamma, record.spec.gamma, Set{Verdict}()), record.verdict)
    end
    for (gamma, verdicts) in by_gamma
        length(verdicts) <= 1 || throw(MonotonicityError(
            "conflicting verified outcomes at gamma=$gamma for one relaxation"))
    end
    Dict(gamma => only(verdicts) for (gamma, verdicts) in by_gamma)
end

function _audit_group(group::Vector{RunRecord})
    points = _verified_points(group)
    feasible_gammas = sort!([gamma for (gamma, verdict) in points
                             if verdict == feasible])
    excluded_gammas = sort!([gamma for (gamma, verdict) in points
                             if verdict == certified_infeasible])
    if !isempty(feasible_gammas) && !isempty(excluded_gammas) &&
       first(excluded_gammas) < last(feasible_gammas)
        key = _relaxation_key(first(group))
        throw(MonotonicityError(
            "certified infeasible gamma $(first(excluded_gammas)) lies below " *
            "later feasible gamma $(last(feasible_gammas)) at relaxation $key"))
    end
    (points=points, feasible=feasible_gammas, excluded=excluded_gammas)
end

function _nested_audit(groups, summaries)
    by_geometry = Dict{Tuple,Dict{Symbol,Tuple}}()
    for (key, group) in groups
        geometry_key = _geometry_key(first(group))
        get!(by_geometry, geometry_key, Dict{Symbol,Tuple}())[key[4]] = key
    end

    nested_pairs = 0
    for (geometry_key, rung_keys) in by_geometry
        haskey(rung_keys, :A) && haskey(rung_keys, :B) || continue
        _, L, d, scope = geometry_key
        cache_key = (L, d, scope)
        if !(cache_key in _NESTING_AUDIT_CACHE)
            patch = build_patch(L)
            inner = rung_a(patch, d; scope)
            outer = try
                rung_b(patch, d; scope)
            catch error
                throw(MonotonicityError(
                    "could not rebuild declared Rung A/B pair: $(sprint(showerror, error))"))
            end
            try
                assert_nested(inner, outer)
            catch error
                throw(MonotonicityError(
                    "declared Rung A/B bases are not nested: $(sprint(showerror, error))"))
            end
            push!(_NESTING_AUDIT_CACHE, cache_key)
        end
        nested_pairs += 1

        a_excluded = summaries[rung_keys[:A]].excluded
        b_excluded = summaries[rung_keys[:B]].excluded
        b_feasible = summaries[rung_keys[:B]].feasible
        if !isempty(a_excluded) && !isempty(b_feasible) &&
           last(b_feasible) >= first(a_excluded)
            throw(MonotonicityError(
                "Rung B feasible gamma $(last(b_feasible)) contradicts " *
                "nested Rung A exclusion at gamma $(first(a_excluded)) " *
                "for geometry $geometry_key"))
        end
        if !isempty(a_excluded) && !isempty(b_excluded) &&
           first(b_excluded) > first(a_excluded)
            throw(MonotonicityError(
                "Rung B upper exclusion $(first(b_excluded)) is looser than " *
                "Rung A upper exclusion $(first(a_excluded)) at geometry $geometry_key"))
        end
    end
    nested_pairs
end

"""Audit exact-gamma monotonicity and exact Rung-A/Rung-B nesting."""
function audit_monotonicity(records::AbstractVector{<:RunRecord})
    groups = _group_records(records)
    summaries = Dict(key => _audit_group(group) for (key, group) in groups)
    nested_pairs = _nested_audit(groups, summaries)
    unknown_records = sort!([record for record in records
                             if record.verdict == unknown]; by=_report_order_key)
    (groups=summaries, unknown_records=unknown_records,
     nested_pairs=nested_pairs)
end

function _complete_brackets(records; scope::Symbol=:unrestricted)
    audit = audit_monotonicity(records)
    brackets = NamedTuple[]
    for (key, summary) in audit.groups
        key[5] == scope || continue
        isempty(summary.feasible) && continue
        isempty(summary.excluded) && continue
        lower = last(summary.feasible)
        upper = first(summary.excluded)
        lower <= upper || throw(MonotonicityError("verified bracket is reversed"))
        push!(brackets, (key=key, lower=lower, upper=upper,
                         points=summary.points))
    end
    sort!(brackets; by=item ->
        (item.upper, -item.lower, item.key[1], item.key[2], item.key[3],
         String(item.key[4]), String(item.key[5])))
end

function _best_verified_bracket(records; scope::Symbol=:unrestricted)
    brackets = _complete_brackets(records; scope)
    isempty(brackets) ? nothing : first(brackets)
end

"""Return the tightest unrestricted verified bracket, or `nothing`."""
function verified_bracket(records::AbstractVector{<:RunRecord})
    best = _best_verified_bracket(records)
    best === nothing && return nothing
    (best.lower, best.upper)
end

"""Classify only exact unrestricted, independently verified evidence."""
function result_tier(records::AbstractVector{<:RunRecord})
    audit = audit_monotonicity(records)
    unrestricted = [summary for (key, summary) in audit.groups
                    if key[5] == :unrestricted]
    for summary in unrestricted
        get(summary.points, 1//5, unknown) == certified_infeasible && return :gold
    end
    for summary in unrestricted
        get(summary.points, 1//5, unknown) == feasible &&
            get(summary.points, 3//10, unknown) == certified_infeasible &&
            return :silver
    end
    for summary in unrestricted
        get(summary.points, 3//10, unknown) == feasible &&
            any(gamma > 3//10 && verdict == certified_infeasible
                for (gamma, verdict) in summary.points) && return :baseline
    end
    :inconclusive
end

function _canonical_report_dictionary(dictionary)
    ordered_keys = sort!(String.(collect(keys(dictionary))))
    join((repr(key) * "=>" * repr(dictionary[key]) for key in ordered_keys), '\0')
end

function _report_order_key(record::RunRecord)
    scope_order = record.spec.scope == :unrestricted ? 0 : 1
    rung_order = record.spec.rung == :A ? 0 : 1
    details = record.verification.details
    (scope_order, record.spec.L, record.spec.d, rung_order,
     record.spec.gamma, Int(record.verdict), record.spec.timeout_seconds,
     String(record.raw.termination_status), String(record.raw.primal_status),
     String(record.raw.dual_status), bitstring(record.raw.runtime_seconds),
     _canonical_report_dictionary(record.raw.diagnostics), record.raw.message,
     record.verification.accepted ? 1 : 0,
     String(record.verification.method),
     _canonical_report_dictionary(details), record.reason,
     get(details, "problem_hash", ""), get(details, "candidate_hash", ""),
     get(details, "certificate_hash", ""), _spec_hash(record.spec))
end

function _gamma_text(value::Rational)
    scaled = value * 100
    if denominator(scaled) == 1
        integer = Int(numerator(scaled))
        sign = integer < 0 ? "-" : ""
        magnitude = abs(integer)
        return "$sign$(magnitude ÷ 100).$(lpad(string(magnitude % 100), 2, '0'))"
    end
    "$(numerator(value))/$(denominator(value))"
end

_verdict_text(verdict::Verdict) = String(Symbol(verdict))

function _relative_artifact_links(record, report_directory, artifact_root)
    details = record.verification.details
    problem_hash = get(details, "problem_hash", "")
    certificate_hash = get(details, "certificate_hash",
                           get(details, "candidate_hash", ""))
    run_directory = artifact_directory(artifact_root, record.spec)
    problem_target = replace(relpath(joinpath(run_directory, "problem.json"),
                                     report_directory), '\\' => '/')
    verification_target = replace(relpath(joinpath(run_directory,
                                                    "verification.json"),
                                          report_directory), '\\' => '/')
    problem_link = isempty(problem_hash) ? "n/a" :
        "[$problem_hash]($problem_target)"
    certificate_link = isempty(certificate_hash) ? "n/a" :
        "[$certificate_hash]($verification_target)"
    (problem_hash=problem_hash, certificate_hash=certificate_hash,
     problem_link=problem_link, certificate_link=certificate_link,
     problem_target=problem_target, certificate_target=verification_target)
end

function _markdown_table(records, report_directory, artifact_root)
    lines = String[
        "| gamma/J1 | L | d | rung | raw status | verifier | verdict | runtime (s) | problem hash | certificate hash |",
        "|---:|---:|---:|:---:|:---|:---|:---|---:|:---|:---|",
    ]
    for record in records
        links = _relative_artifact_links(record, report_directory, artifact_root)
        push!(lines,
            "| $(_gamma_text(record.spec.gamma)) | $(record.spec.L) | " *
            "$(record.spec.d) | $(record.spec.rung) | " *
            "$(record.raw.termination_status) | $(record.verification.method) | " *
            "$(_verdict_text(record.verdict)) | $(record.raw.runtime_seconds) | " *
            "$(links.problem_link) | $(links.certificate_link) |")
    end
    join(lines, '\n')
end

function _claim_sentence(record::RunRecord)
    gamma = _gamma_text(record.spec.gamma)
    relaxation = "(L=$(record.spec.L), d=$(record.spec.d), rung=$(record.spec.rung))"
    if record.verdict == certified_infeasible
        return "At relaxation $relaxation, gamma=$gamma J1 is independently " *
               "certified infeasible; therefore Delta_bulk < $gamma J1."
    elseif record.verdict == feasible
        return "At relaxation $relaxation, gamma=$gamma J1 is independently " *
               "verified feasible; this relaxation does not exclude gamma=$gamma J1."
    end
    "At relaxation $relaxation, gamma=$gamma J1 remains unknown and does not " *
    "move the verified bracket."
end

function _tier_sentence(tier::Symbol)
    tier == :gold && return "The unrestricted gamma=0.20 J1 exclusion rules out a robust 0.3 J1-scale full bulk gap at the certified relaxation."
    tier == :silver && return "The unrestricted gamma=0.30 J1 exclusion constrains the large-gap interpretation, while gamma=0.20 J1 remains feasible at the same relaxation."
    tier == :baseline && return "The unrestricted hierarchy supplies a certified upper endpoint above gamma=0.30 J1; it does not settle the 0.3 J1 question."
    "The verified evidence does not supply a claim-safe bracket for a scientific tier."
end

_json_rational(value::Rational) =
    (numerator=string(numerator(value)), denominator=string(denominator(value)))

function _json_row(record, report_directory, artifact_root)
    links = _relative_artifact_links(record, report_directory, artifact_root)
    (gamma=_json_rational(record.spec.gamma), L=record.spec.L, d=record.spec.d,
     rung=String(record.spec.rung), scope=String(record.spec.scope),
     raw_status=String(record.raw.termination_status),
     primal_status=String(record.raw.primal_status),
     dual_status=String(record.raw.dual_status),
     verifier=String(record.verification.method),
     verdict=_verdict_text(record.verdict), runtime_seconds=record.raw.runtime_seconds,
     reason=record.reason, problem_hash=links.problem_hash,
     certificate_hash=links.certificate_hash,
     problem_path=links.problem_target,
     certificate_path=links.certificate_target)
end

"""Write deterministic Markdown and JSON reports and return their paths/content."""
function build_report(records::AbstractVector{<:RunRecord},
                      report_directory::AbstractString;
                      artifact_root::AbstractString=report_directory)
    report_directory = abspath(report_directory)
    artifact_root = abspath(artifact_root)
    mkpath(report_directory)
    audit_monotonicity(records)
    ordered = sort!(collect(records); by=_report_order_key)
    unrestricted = filter(record -> is_headline(record.spec), ordered)
    restricted = filter(record -> !is_headline(record.spec), ordered)
    tier = result_tier(records)
    best_bracket = _best_verified_bracket(records)

    markdown_lines = String[
        "# Triangular J1-J2 bulk-gap certificate report",
        "",
        "Result tier: `$(tier)`",
        "",
        _tier_sentence(tier),
        "",
        "## Unrestricted results",
        "",
        _markdown_table(unrestricted, report_directory, artifact_root),
        "",
        "## Claim-safe interpretation",
        "",
    ]
    append!(markdown_lines, ["- $(_claim_sentence(record))"
                             for record in unrestricted])
    append!(markdown_lines, [
        "",
        "## Exploratory symmetry-restricted appendix",
        "",
        "These rows are restricted scouting evidence and do not support headline claims.",
        "",
        _markdown_table(restricted, report_directory, artifact_root),
        "",
    ])
    markdown = join(markdown_lines, '\n')

    bracket_document = if best_bracket === nothing
        nothing
    else
        key = best_bracket.key
        (lower=_json_rational(best_bracket.lower),
         upper=_json_rational(best_bracket.upper),
         relaxation=(g=_json_rational(key[1]), L=key[2], d=key[3],
                     rung=String(key[4]), scope=String(key[5])))
    end
    machine_document = (
        format="triangular-gap-report-v1",
        tier=String(tier),
        bracket=bracket_document,
        unrestricted=[_json_row(record, report_directory, artifact_root)
                      for record in unrestricted],
        exploratory_symmetry_restricted=[
            _json_row(record, report_directory, artifact_root)
            for record in restricted],
    )
    machine = JSON3.write(machine_document)
    markdown_path = joinpath(report_directory, "report.md")
    json_path = joinpath(report_directory, "report.json")
    _atomic_write(markdown_path, markdown)
    _atomic_write(json_path, machine)
    (markdown_path=markdown_path, json_path=json_path,
     markdown=markdown * (endswith(markdown, '\n') ? "" : "\n"),
     json=machine * (endswith(machine, '\n') ? "" : "\n"))
end
