"""A commuting state-expectation symbol for a Pauli word."""
struct StateSymbol
    word::PauliWord
end

Base.isless(left::StateSymbol, right::StateSymbol) = isless(left.word, right.word)
Base.adjoint(symbol::StateSymbol) = StateSymbol(adjoint_word(symbol.word))

"""A canonically ordered commuting product of non-identity state symbols."""
struct StateMonomial
    symbols::Tuple{Vararg{StateSymbol}}
    function StateMonomial(symbols)
        canonical = sort!(StateSymbol[symbol for symbol in symbols if !isempty(symbol.word.factors)])
        new(Tuple(canonical))
    end
end

StateMonomial() = StateMonomial(())
Base.adjoint(monomial::StateMonomial) = StateMonomial(adjoint.(monomial.symbols))

"""A state polynomial times one noncommutative Pauli-word factor."""
struct NCStateMonomial
    symbols::Tuple{Vararg{StateSymbol}}
    operator_word::PauliWord
    function NCStateMonomial(symbols, operator_word::PauliWord)
        state_part = StateMonomial(symbols)
        new(state_part.symbols, operator_word)
    end
end

NCStateMonomial(symbols::StateMonomial, operator_word::PauliWord) =
    NCStateMonomial(symbols.symbols, operator_word)
Base.adjoint(monomial::NCStateMonomial) =
    NCStateMonomial(adjoint.(monomial.symbols), adjoint_word(monomial.operator_word))

total_degree(monomial::NCStateMonomial) =
    sum((length(symbol.word.factors) for symbol in monomial.symbols); init=0) +
    length(monomial.operator_word.factors)

function state_symbol_serialization(symbol::StateSymbol)
    join(("$(factor.site):$(factor.axis)" for factor in symbol.word.factors), ',')
end

function monomial_serialization(monomial::NCStateMonomial)
    symbols = join((state_symbol_serialization(symbol) for symbol in monomial.symbols), '*')
    operator = join(("$(factor.site):$(factor.axis)" for factor in monomial.operator_word.factors), ',')
    "state=$(symbols)|operator=$(operator)"
end

function basis_hash(words)
    bytes2hex(sha256(join((monomial_serialization(word) for word in words), '\n')))
end

"""An ordered relaxation basis and the scope under which it was generated."""
struct RelaxationBasis
    rung::Symbol
    scope::Symbol
    words::Tuple
    hash::String
    function RelaxationBasis(rung::Symbol, scope::Symbol, words)
        rung in (:A, :B) || throw(ArgumentError("basis rung must be :A or :B"))
        scope in (:unrestricted, :exploratory_symmetry_restricted) ||
            throw(ArgumentError("invalid basis scope"))
        all(word -> word isa NCStateMonomial, words) ||
            throw(ArgumentError("basis words must be NCStateMonomial values"))
        canonical_words = Tuple(words)
        length(unique(canonical_words)) == length(canonical_words) ||
            throw(ArgumentError("basis words must be unique"))
        new(rung, scope, canonical_words, basis_hash(canonical_words))
    end
end

function one_site_words(patch::TriangularPatch)
    [PauliWord(((site, axis),)) for site in eachindex(patch.sites) for axis in (:X, :Y, :Z)]
end

function two_site_words(patch::TriangularPatch; pair_radius::Int)
    pair_radius == 2 || throw(ArgumentError("the frozen Rung B policy requires pair_radius = 2"))
    words = PauliWord[]
    for (i, j) in squared_distance_edges(patch.sites, 1)
        for left_axis in (:X, :Y, :Z), right_axis in (:X, :Y, :Z)
            push!(words, PauliWord(((i, left_axis), (j, right_axis))))
        end
    end
    for (i, j) in squared_distance_edges(patch.sites, 3)
        for left_axis in (:X, :Y, :Z), right_axis in (:X, :Y, :Z)
            push!(words, PauliWord(((i, left_axis), (j, right_axis))))
        end
    end
    sort!(words)
end

function candidate_words_a(patch::TriangularPatch)
    sort!(vcat(PauliWord(), one_site_words(patch)))
end

function candidate_words_b(patch::TriangularPatch; pair_radius::Int)
    sort!(vcat(candidate_words_a(patch), two_site_words(patch; pair_radius)))
end

function enumerate_state_products(candidates::Vector{PauliWord}, remaining_degree::Int)
    state_words = filter(word -> !isempty(word.factors), candidates)
    products = Tuple{Vararg{StateSymbol}}[()]

    function extend(prefix::Vector{StateSymbol}, first_index::Int, remaining::Int)
        for index in first_index:length(state_words)
            word = state_words[index]
            word_degree = length(word.factors)
            word_degree <= remaining || continue
            push!(prefix, StateSymbol(word))
            push!(products, Tuple(prefix))
            extend(prefix, index, remaining - word_degree)
            pop!(prefix)
        end
    end

    extend(StateSymbol[], 1, remaining_degree)
    products
end

function monomial_order_key(monomial::NCStateMonomial)
    (
        total_degree(monomial),
        length(monomial.symbols),
        support(monomial.operator_word),
        Tuple(symbol.word.factors for symbol in monomial.symbols),
        Tuple(factor.axis for factor in monomial.operator_word.factors),
    )
end

function enumerate_rung_words(candidates::Vector{PauliWord}, d::Int)
    d >= 0 || throw(ArgumentError("relaxation degree must be nonnegative"))
    words = NCStateMonomial[]
    for operator_word in candidates
        operator_degree = length(operator_word.factors)
        operator_degree <= d || continue
        for symbols in enumerate_state_products(candidates, d - operator_degree)
            push!(words, NCStateMonomial(symbols, operator_word))
        end
    end
    sort!(words; by=monomial_order_key)
    words
end

"""Generate unrestricted Rung A without applying any symmetry quotient."""
function rung_a(patch::TriangularPatch, d::Int; scope::Symbol=:unrestricted)
    RelaxationBasis(:A, scope, enumerate_rung_words(candidate_words_a(patch), d))
end

"""Generate Rung B by preserving the Rung-A prefix and appending two-body words."""
function rung_b(patch::TriangularPatch, d::Int; pair_radius::Int=2, scope::Symbol=:unrestricted)
    d >= 2 || throw(ArgumentError("Rung B requires relaxation degree at least 2"))
    rung_a_basis = rung_a(patch, d; scope)
    all_words = enumerate_rung_words(candidate_words_b(patch; pair_radius), d)
    existing = Set(rung_a_basis.words)
    additions = filter(word -> !(word in existing), all_words)
    RelaxationBasis(:B, scope, vcat(collect(rung_a_basis.words), additions))
end

function rung_a(patch::TriangularPatch, spec::RunSpec)
    spec.rung == :A || throw(ArgumentError("RunSpec rung must be :A for rung_a"))
    rung_a(patch, spec.d; scope=spec.scope)
end

function rung_b(patch::TriangularPatch, spec::RunSpec; pair_radius::Int=2)
    spec.rung == :B || throw(ArgumentError("RunSpec rung must be :B for rung_b"))
    rung_b(patch, spec.d; pair_radius, scope=spec.scope)
end

"""Verify that `inner.words` is the exact prefix of `outer.words`."""
function assert_nested(inner::RelaxationBasis, outer::RelaxationBasis)
    length(inner.words) <= length(outer.words) ||
        throw(ArgumentError("outer basis is shorter than inner basis at index $(length(outer.words) + 1)"))
    for index in eachindex(inner.words)
        inner.words[index] == outer.words[index] ||
            throw(ArgumentError("basis prefix differs at index $index"))
    end
    true
end
