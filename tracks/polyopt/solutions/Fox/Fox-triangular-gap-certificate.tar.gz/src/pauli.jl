const ExactComplex = Complex{Rational{BigInt}}
const EXACT_ZERO = ExactComplex(0//1, 0//1)
const EXACT_ONE = ExactComplex(1//1, 0//1)

"""One non-identity Pauli factor at a positive, one-based site index."""
struct PauliFactor
    site::Int
    axis::Symbol
    function PauliFactor(site::Int, axis::Symbol)
        site > 0 || throw(ArgumentError("Pauli sites must be positive"))
        axis in (:X, :Y, :Z) || throw(ArgumentError("Pauli axis must be :X, :Y, or :Z"))
        new(site, axis)
    end
end

Base.isless(left::PauliFactor, right::PauliFactor) = (left.site, left.axis) < (right.site, right.axis)

"""An immutable Pauli word in ascending site order, with at most one factor per site."""
struct PauliWord
    factors::Tuple{Vararg{PauliFactor}}
    function PauliWord(factors)
        canonical = sort!(PauliFactor[
            factor isa PauliFactor ? factor : PauliFactor(Int(factor[1]), Symbol(factor[2]))
            for factor in factors
        ])
        all(pair -> pair[1].site != pair[2].site, zip(canonical, canonical[2:end])) ||
            throw(ArgumentError("a Pauli word cannot contain duplicate sites"))
        new(Tuple(canonical))
    end
end

PauliWord() = PauliWord(())

Base.isless(left::PauliWord, right::PauliWord) = left.factors < right.factors
support(word::PauliWord) = Tuple(factor.site for factor in word.factors)
adjoint_word(word::PauliWord) = word

const PAULI_PRODUCT = Dict(
    (:X, :X) => (1, :I), (:Y, :Y) => (1, :I), (:Z, :Z) => (1, :I),
    (:X, :Y) => (im, :Z), (:Y, :Z) => (im, :X), (:Z, :X) => (im, :Y),
    (:Y, :X) => (-im, :Z), (:Z, :Y) => (-im, :X), (:X, :Z) => (-im, :Y),
)

exact_complex(value::Integer) = ExactComplex(BigInt(value) // BigInt(1), 0//1)
exact_complex(value::Complex{<:Integer}) = ExactComplex(BigInt(real(value)) // BigInt(1), BigInt(imag(value)) // BigInt(1))

"""Multiply two Pauli words and return their exact phase and canonical product word."""
function multiply(left::PauliWord, right::PauliWord)
    phase = EXACT_ONE
    factors = PauliFactor[]
    left_index = right_index = 1
    while left_index <= length(left.factors) || right_index <= length(right.factors)
        if right_index > length(right.factors) ||
           (left_index <= length(left.factors) && left.factors[left_index].site < right.factors[right_index].site)
            push!(factors, left.factors[left_index])
            left_index += 1
        elseif left_index > length(left.factors) || right.factors[right_index].site < left.factors[left_index].site
            push!(factors, right.factors[right_index])
            right_index += 1
        else
            left_factor, right_factor = left.factors[left_index], right.factors[right_index]
            raw_phase, axis = PAULI_PRODUCT[(left_factor.axis, right_factor.axis)]
            phase *= exact_complex(raw_phase)
            axis == :I || push!(factors, PauliFactor(left_factor.site, axis))
            left_index += 1
            right_index += 1
        end
    end
    phase, PauliWord(Tuple(factors))
end

"""Sparse exact linear combination of Pauli words."""
struct ExactOperator
    terms::Dict{PauliWord, ExactComplex}
    function ExactOperator(terms::Dict{PauliWord, ExactComplex})
        canonical = copy(terms)
        filter!(pair -> pair.second != EXACT_ZERO, canonical)
        new(canonical)
    end
end

function ExactOperator(terms::AbstractDict{PauliWord,<:Number})
    canonical = Dict{PauliWord, ExactComplex}()
    for (word, coefficient) in terms
        exact = convert(ExactComplex, coefficient)
        exact == EXACT_ZERO || (canonical[word] = get(canonical, word, EXACT_ZERO) + exact)
    end
    filter!(pair -> pair.second != EXACT_ZERO, canonical)
    ExactOperator(canonical)
end

ExactOperator() = ExactOperator(Dict{PauliWord, ExactComplex}())
Base.isempty(operator::ExactOperator) = isempty(operator.terms)
Base.length(operator::ExactOperator) = length(operator.terms)
Base.iterate(operator::ExactOperator, state...) = iterate(operator.terms, state...)
Base.getindex(operator::ExactOperator, word::PauliWord) = get(operator.terms, word, EXACT_ZERO)

function Base.:+(left::ExactOperator, right::ExactOperator)
    terms = copy(left.terms)
    for (word, coefficient) in right.terms
        terms[word] = get(terms, word, EXACT_ZERO) + coefficient
    end
    ExactOperator(terms)
end

function canonical_operator_serialization(operator::ExactOperator)
    terms = sort!(collect(operator.terms); by=first)
    join((let factors = join(("$(factor.site):$(factor.axis)" for factor in word.factors), ',')
              "$(factors)|$(numerator(real(coefficient)))/$(denominator(real(coefficient)))|$(numerator(imag(coefficient)))/$(denominator(imag(coefficient)))"
          end for (word, coefficient) in terms), "\n")
end

operator_hash(operator::ExactOperator) = bytes2hex(sha256(canonical_operator_serialization(operator)))
