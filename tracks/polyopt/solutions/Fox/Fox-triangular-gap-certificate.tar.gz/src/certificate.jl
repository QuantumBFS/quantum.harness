using IntervalArithmetic

"""
Floating-point dual ray in the package's canonical convention.

The primal is stored as `A(x) = b` and `F_k(x) ⩰ 0`.  A valid ray has
`A' y + Σ F_{k,i} • Z_k = 0`, `Z_k ⩰ 0`, and
`Σ F_{k,0} • Z_k - b' y < 0`.
"""
struct FarkasCandidate
    dual_equalities::Vector{Float64}
    dual_psd_blocks::Vector{Matrix{Float64}}
    separation::Float64
    problem_hash::String

    function FarkasCandidate(dual_equalities, dual_psd_blocks, separation,
                             problem_hash)
        equalities = Float64.(collect(dual_equalities))
        blocks = Matrix{Float64}[Matrix{Float64}(block)
                                  for block in dual_psd_blocks]
        new(equalities, blocks, Float64(separation), String(problem_hash))
    end
end

_failed(method::Symbol, reason::AbstractString;
        details::Dict{String,String}=Dict{String,String}()) = begin
    result = copy(details)
    result["reason"] = String(reason)
    VerificationRecord(false, method, result)
end

_accepted(method::Symbol, details::Dict{String,String}) =
    VerificationRecord(true, method, details)

function rational_reconstruct(value::Real; tolerance::Real=1e-12)
    float_value = Float64(value)
    isfinite(float_value) || throw(ArgumentError("only finite certificate values can be reconstructed"))
    tolerance >= 0 || throw(ArgumentError("tolerance must be nonnegative"))
    rationalize(BigInt, float_value; tol=Float64(tolerance))
end

function _reconstruct_vector(values)
    Rational{BigInt}[rational_reconstruct(value) for value in values]
end

function _symmetrized_reconstruction(matrix::AbstractMatrix)
    rows, cols = size(matrix)
    rows == cols || throw(ArgumentError("PSD candidate blocks must be square"))
    all(isfinite, matrix) || throw(ArgumentError("PSD candidate blocks must be finite"))
    result = Matrix{Rational{BigInt}}(undef, rows, rows)
    for row in 1:rows, col in 1:rows
        result[row, col] = rational_reconstruct((matrix[row, col] + matrix[col, row]) / 2)
    end
    result
end

function _rational_string(value::Rational)
    denominator(value) == 1 && return string(numerator(value))
    string(numerator(value), "/", denominator(value))
end

"""Exact symmetric LDLᵀ check, including the zero-pivot PSD condition."""
function exact_psd_ldlt(input::AbstractMatrix{<:Rational}; block_index::Int=1)
    rows, cols = size(input)
    rows == cols || return _failed(:psd_exact, "nonsquare";
        details=Dict("block" => string(block_index)))
    matrix = Rational{BigInt}.(input)
    matrix == transpose(matrix) || return _failed(:psd_exact, "nonsymmetric";
        details=Dict("block" => string(block_index)))

    schur = copy(matrix)
    for pivot_index in 1:rows
        pivot = schur[pivot_index, pivot_index]
        details = Dict("block" => string(block_index),
                       "pivot" => string(pivot_index),
                       "pivot_value" => _rational_string(pivot))
        pivot < 0 && return _failed(:psd_exact, "negative_pivot"; details=details)
        if iszero(pivot)
            any(!iszero(schur[pivot_index, col])
                for col in (pivot_index + 1):rows) &&
                return _failed(:psd_exact, "nonzero_zero_pivot_row"; details=details)
            continue
        end
        for row in (pivot_index + 1):rows
            for col in row:rows
                updated = schur[row, col] -
                          schur[pivot_index, row] * schur[pivot_index, col] / pivot
                schur[row, col] = updated
                schur[col, row] = updated
            end
        end
    end
    _accepted(:psd_exact, Dict("block" => string(block_index),
                               "minimum_pivot" => "nonnegative"))
end

function _candidate_hash(kind::AbstractString, parts...)
    io = IOBuffer()
    print(io, kind, '\n')
    for part in parts
        if part isa AbstractVector{<:AbstractMatrix}
            print(io, "matrix-vector:", length(part), '[')
            for matrix in part
                print(io, size(matrix, 1), 'x', size(matrix, 2), ':')
                for value in matrix
                    print(io, repr(value), ';')
                end
                print(io, '|')
            end
            print(io, ']')
        elseif part isa AbstractVector && !(part isa AbstractMatrix)
            print(io, length(part), ':')
            for value in part
                print(io, repr(value), ';')
            end
        elseif part isa AbstractMatrix
            print(io, size(part, 1), 'x', size(part, 2), ':')
            for value in part
                print(io, repr(value), ';')
            end
        else
            print(io, repr(part))
        end
        print(io, '\n')
    end
    bytes2hex(SHA.sha256(take!(io)))
end

function verification_matches(record::VerificationRecord,
                              problem_hash::AbstractString,
                              candidate_hash::AbstractString)
    record.accepted || return false
    get(record.details, "problem_hash", "") == problem_hash || return false
    get(record.details, "candidate_hash", "") == candidate_hash || return false
    if record.method in (:farkas_exact, :farkas_interval)
        get(record.details, "certificate_hash", "") == candidate_hash || return false
    end
    true
end

function _evaluate_block(block::PSDBlock, values::Vector{Rational{BigInt}})
    matrix = fill(BigInt(0) // BigInt(1), block.dimension, block.dimension)
    for (row, col, coefficient) in block.constant_entries
        matrix[row, col] += coefficient
        row == col || (matrix[col, row] += coefficient)
    end
    for entry in block.variable_entries
        contribution = entry.coefficient * values[entry.variable]
        matrix[entry.row, entry.col] += contribution
        entry.row == entry.col || (matrix[entry.col, entry.row] += contribution)
    end
    matrix
end

_primal_ids(problem) = ["x:$index:$(problem.variable_names[index])"
                        for index in eachindex(problem.variable_names)]

function _primal_affine_system(problem::ConicFeasibility)
    matrix = fill(BigInt(0) // BigInt(1), length(problem.equalities),
                  length(problem.variable_names))
    rhs = fill(BigInt(0) // BigInt(1), length(problem.equalities))
    for (row, (coefficients, value)) in enumerate(problem.equalities)
        rhs[row] = value
        for (variable, coefficient) in coefficients
            matrix[row, variable] = coefficient
        end
    end
    matrix, rhs
end

function _exact_rref_affine(matrix::Matrix{Rational{BigInt}},
                            rhs::Vector{Rational{BigInt}})
    row_count, column_count = size(matrix)
    length(rhs) == row_count || throw(ArgumentError("affine rhs length mismatch"))
    augmented = hcat(matrix, rhs)
    pivots = Int[]
    pivot_row = 1
    for column in 1:column_count
        pivot_row > row_count && break
        selected = findfirst(row -> !iszero(augmented[row, column]),
                             pivot_row:row_count)
        selected === nothing && continue
        selected_row = pivot_row - 1 + selected
        if selected_row != pivot_row
            augmented[pivot_row, :], augmented[selected_row, :] =
                copy(augmented[selected_row, :]), copy(augmented[pivot_row, :])
        end
        pivot = augmented[pivot_row, column]
        augmented[pivot_row, :] ./= pivot
        for row in 1:row_count
            row == pivot_row && continue
            factor = augmented[row, column]
            iszero(factor) ||
                (augmented[row, :] .-= factor .* augmented[pivot_row, :])
        end
        push!(pivots, column)
        pivot_row += 1
    end
    reduced = augmented[:, 1:column_count]
    reduced_rhs = augmented[:, end]
    for row in 1:row_count
        all(iszero, reduced[row, :]) && !iszero(reduced_rhs[row]) &&
            throw(ArgumentError("inconsistent affine equality system"))
    end
    reduced, reduced_rhs, pivots
end

function _correct_primal(problem, values)
    matrix, rhs = _primal_affine_system(problem)
    reduced, reduced_rhs, pivots = _exact_rref_affine(matrix, rhs)
    free = setdiff(collect(eachindex(values)), pivots)
    corrected = copy(values)
    for (row, pivot) in enumerate(pivots)
        corrected[pivot] = reduced_rhs[row] -
            sum((reduced[row, column] * corrected[column] for column in free);
                init=BigInt(0) // BigInt(1))
    end
    matrix * corrected == rhs ||
        throw(ArgumentError("exact primal correction did not satisfy A*x=b"))
    corrected, pivots, free, reduced, reduced_rhs
end

function _exact_primal(problem, candidate, details)
    values = try
        _reconstruct_vector(candidate)
    catch error
        details["error"] = sprint(showerror, error)
        return _failed(:primal_exact, "nonfinite_or_unreconstructable"; details=details)
    end
    corrected, pivots, free, _, _ = try
        _correct_primal(problem, values)
    catch error
        details["error"] = sprint(showerror, error)
        return _failed(:primal_exact, "primal_correction_failed"; details=details)
    end
    ids = _primal_ids(problem)
    details["pivot_coordinates"] = join((ids[index] for index in pivots), ',')
    details["free_coordinates"] = join((ids[index] for index in free), ',')
    details["corrected_coordinates"] = join((ids[index] for index in eachindex(values)
                                               if values[index] != corrected[index]), ',')
    for (index, block) in enumerate(problem.psd_blocks)
        psd = exact_psd_ldlt(_evaluate_block(block, corrected); block_index=index)
        if !psd.accepted
            merge!(details, psd.details)
            return _failed(:primal_exact, "non_psd_primal_block"; details=details)
        end
    end
    _accepted(:primal_exact, details)
end

function _interval_primal(problem, candidate, details)
    all(isfinite, candidate) ||
        return _failed(:inconclusive_interval, "nonfinite"; details=details)
    centers = try
        Rational{BigInt}[_decimal_rational_exact(string(value)) for value in candidate]
    catch error
        details["error"] = sprint(showerror, error)
        return _failed(:inconclusive_interval, "unparseable_decimal"; details=details)
    end
    matrix, rhs = _primal_affine_system(problem)
    reduced, reduced_rhs, pivots = try
        _exact_rref_affine(matrix, rhs)
    catch error
        details["error"] = sprint(showerror, error)
        return _failed(:inconclusive_interval, "inconsistent_equalities"; details=details)
    end
    free = setdiff(collect(eachindex(centers)), pivots)
    declared_boxes = [_candidate_box(center) for center in centers]
    coordinate_boxes = copy(declared_boxes)
    ids = _primal_ids(problem)
    for (row, pivot) in enumerate(pivots)
        solution = _big_interval(reduced_rhs[row])
        for column in free
            solution -= _big_interval(reduced[row, column]) * coordinate_boxes[column]
        end
        declared = declared_boxes[pivot]
        (IntervalArithmetic.inf(solution) > IntervalArithmetic.inf(declared) &&
         IntervalArithmetic.sup(solution) < IntervalArithmetic.sup(declared)) || begin
            details["failed_pivot"] = ids[pivot]
            return _failed(:inconclusive_interval, "krawczyk_inclusion_failed";
                           details=details)
        end
        coordinate_boxes[pivot] = solution
    end
    details["inclusion"] = "proved"
    details["inclusion_method"] = "exact-RREF-preconditioned-Rump"
    details["precision_bits"] = "256"
    details["pivot_coordinates"] = join((ids[index] for index in pivots), ',')
    details["free_coordinates"] = join((ids[index] for index in free), ',')

    for (block_index, block) in enumerate(problem.psd_blocks)
        interval_matrix = [_big_interval(BigInt(0) // BigInt(1))
                           for _ in 1:block.dimension, _ in 1:block.dimension]
        for (row, col, coefficient) in block.constant_entries
            value = _big_interval(coefficient)
            interval_matrix[row, col] += value
            row == col || (interval_matrix[col, row] += value)
        end
        for entry in block.variable_entries
            value = _big_interval(entry.coefficient) * coordinate_boxes[entry.variable]
            interval_matrix[entry.row, entry.col] += value
            entry.row == entry.col || (interval_matrix[entry.col, entry.row] += value)
        end
        for row in 1:block.dimension
            radius = _big_interval(BigInt(0) // BigInt(1))
            for col in 1:block.dimension
                row == col && continue
                radius += abs(interval_matrix[row, col])
            end
            lower = IntervalArithmetic.inf(interval_matrix[row, row] - radius)
            lower >= 0 || begin
                details["block"] = string(block_index)
                details["row"] = string(row)
                details["gershgorin_lower"] = string(lower)
                return _failed(:inconclusive_interval, "uniform_psd_not_proved";
                               details=details)
            end
        end
    end
    _accepted(:primal_interval, details)
end

function verify_primal(problem::ConicFeasibility, candidate::AbstractVector{<:Real})
    problem_hash = canonical_hash(problem)
    candidate_hash = _candidate_hash("primal-v1", collect(candidate))
    details = Dict("problem_hash" => problem_hash,
                   "candidate_hash" => candidate_hash)
    length(candidate) == length(problem.variable_names) ||
        return _failed(:primal_exact, "wrong_variable_count"; details=details)
    exact = _exact_primal(problem, candidate, copy(details))
    exact.accepted && return exact
    interval_details = copy(details)
    interval_details["exact_failure"] = get(exact.details, "reason", "unknown")
    setprecision(BigFloat, 256) do
        _interval_primal(problem, candidate, interval_details)
    end
end

function verify_primal(problem::ConicFeasibility, artifact::SolverArtifact)
    details = Dict("problem_hash" => canonical_hash(problem),
                   "artifact_problem_hash" => artifact.problem_hash)
    artifact.problem_hash == canonical_hash(problem) ||
        return _failed(:primal_exact, "problem_hash_mismatch"; details=details)
    artifact.primal_values === nothing &&
        return _failed(:primal_exact, "missing_primal_candidate"; details=details)
    verify_primal(problem, artifact.primal_values)
end

function _symmetric_inner(matrix::AbstractMatrix{<:Rational}, entries,
                          variable::Union{Nothing,Int}=nothing)
    result = BigInt(0) // BigInt(1)
    if variable === nothing
        for (row, col, coefficient) in entries
            result += (row == col ? 1 : 2) * matrix[row, col] * coefficient
        end
    else
        for entry in entries
            entry.variable == variable || continue
            result += (entry.row == entry.col ? 1 : 2) *
                      matrix[entry.row, entry.col] * entry.coefficient
        end
    end
    result
end

function _computed_separation(problem::ConicFeasibility,
                              dual_equalities::Vector{Rational{BigInt}},
                              dual_blocks::Vector{Matrix{Rational{BigInt}}})
    separation = -sum((dual_equalities[index] * rhs
                       for (index, (_, rhs)) in enumerate(problem.equalities));
                      init=BigInt(0) // BigInt(1))
    for (block, dual) in zip(problem.psd_blocks, dual_blocks)
        separation += _symmetric_inner(dual, block.constant_entries)
    end
    separation
end

function _farkas_float_separation(problem::ConicFeasibility,
                                  equalities::Vector{Float64},
                                  blocks::Vector{Matrix{Float64}})
    rational_equalities = Rational{BigInt}[
        _decimal_rational_exact(string(value)) for value in equalities]
    rational_blocks = Matrix{Rational{BigInt}}[]
    for block in blocks
        dimension = size(block, 1)
        size(block, 2) == dimension || throw(ArgumentError("dual PSD block must be square"))
        all(isfinite, block) || throw(ArgumentError("dual PSD block must be finite"))
        reconstructed = Matrix{Rational{BigInt}}(undef, dimension, dimension)
        for row in 1:dimension, col in 1:dimension
            left = _decimal_rational_exact(string(block[row, col]))
            right = _decimal_rational_exact(string(block[col, row]))
            reconstructed[row, col] = (left + right) / 2
        end
        push!(rational_blocks, reconstructed)
    end
    Float64(_computed_separation(problem, rational_equalities, rational_blocks))
end

function _dual_layout(problem::ConicFeasibility)
    layout = NamedTuple[]
    for equality in eachindex(problem.equalities)
        push!(layout, (id="eq:$equality", kind=:equality, equality=equality,
                       block=0, row=0, col=0))
    end
    for (block_index, block) in enumerate(problem.psd_blocks)
        for row in 1:block.dimension, col in row:block.dimension
            push!(layout, (id="psd:$block_index:$row:$col", kind=:psd,
                           equality=0, block=block_index, row=row, col=col))
        end
    end
    layout
end

function _identity_matrix(problem::ConicFeasibility, layout)
    matrix = fill(BigInt(0) // BigInt(1), length(problem.variable_names),
                  length(layout))
    equality_coefficients = [Dict(coefficients) for (coefficients, _) in problem.equalities]
    for (coordinate, entry) in enumerate(layout)
        if entry.kind == :equality
            coefficients = equality_coefficients[entry.equality]
            for variable in eachindex(problem.variable_names)
                matrix[variable, coordinate] =
                    get(coefficients, variable, BigInt(0) // BigInt(1))
            end
        else
            block = problem.psd_blocks[entry.block]
            factor = entry.row == entry.col ? 1 : 2
            for affine in block.variable_entries
                (affine.row == entry.row && affine.col == entry.col) || continue
                matrix[affine.variable, coordinate] += factor * affine.coefficient
            end
        end
    end
    matrix
end

function _exact_rref(input::Matrix{Rational{BigInt}})
    result = copy(input)
    row_count, column_count = size(result)
    pivot_columns = Int[]
    pivot_row = 1
    for column in 1:column_count
        pivot_row > row_count && break
        selected = findfirst(row -> !iszero(result[row, column]),
                             pivot_row:row_count)
        selected === nothing && continue
        selected_row = pivot_row - 1 + selected
        if selected_row != pivot_row
            result[pivot_row, :], result[selected_row, :] =
                copy(result[selected_row, :]), copy(result[pivot_row, :])
        end
        pivot = result[pivot_row, column]
        result[pivot_row, :] ./= pivot
        for row in 1:row_count
            row == pivot_row && continue
            factor = result[row, column]
            iszero(factor) || (result[row, :] .-= factor .* result[pivot_row, :])
        end
        push!(pivot_columns, column)
        pivot_row += 1
    end
    result, pivot_columns
end

function _flatten_candidate(candidate::FarkasCandidate, layout; decimal::Bool=false)
    values = Rational{BigInt}[]
    for entry in layout
        raw = if entry.kind == :equality
            candidate.dual_equalities[entry.equality]
        else
            matrix = candidate.dual_psd_blocks[entry.block]
            (matrix[entry.row, entry.col] + matrix[entry.col, entry.row]) / 2
        end
        push!(values, decimal ? _decimal_rational_exact(string(raw)) :
                               rational_reconstruct(raw))
    end
    values
end

function _correct_identity(matrix::Matrix{Rational{BigInt}}, values, layout)
    rref, pivots = _exact_rref(matrix)
    free = setdiff(collect(eachindex(values)), pivots)
    corrected = copy(values)
    for (row, pivot) in enumerate(pivots)
        corrected[pivot] = -sum((rref[row, column] * corrected[column]
                                 for column in free);
                                init=BigInt(0) // BigInt(1))
    end
    matrix * corrected == zeros(Rational{BigInt}, size(matrix, 1)) ||
        throw(ArgumentError("exact RREF correction did not satisfy the affine identity"))
    changed = [layout[index].id for index in eachindex(values)
               if values[index] != corrected[index]]
    corrected, pivots, free, changed, rref
end

function _reassemble_dual(problem::ConicFeasibility, coordinates, layout)
    equalities = fill(BigInt(0) // BigInt(1), length(problem.equalities))
    blocks = [fill(BigInt(0) // BigInt(1), block.dimension, block.dimension)
              for block in problem.psd_blocks]
    for (value, entry) in zip(coordinates, layout)
        if entry.kind == :equality
            equalities[entry.equality] = value
        else
            blocks[entry.block][entry.row, entry.col] = value
            blocks[entry.block][entry.col, entry.row] = value
        end
    end
    equalities, blocks
end

function _exact_farkas(problem, candidate, layout, identity, details)
    coordinates = try
        _flatten_candidate(candidate, layout)
    catch error
        details["error"] = sprint(showerror, error)
        return _failed(:farkas_exact, "nonfinite_or_unreconstructable"; details=details)
    end
    corrected, pivots, free, changed, _ = try
        _correct_identity(identity, coordinates, layout)
    catch error
        details["error"] = sprint(showerror, error)
        return _failed(:farkas_exact, "identity_correction_failed"; details=details)
    end
    details["pivot_coordinates"] = join((layout[index].id for index in pivots), ',')
    details["free_coordinates"] = join((layout[index].id for index in free), ',')
    details["corrected_coordinates"] = join(changed, ',')
    dual_equalities, dual_blocks = _reassemble_dual(problem, corrected, layout)
    for (index, block) in enumerate(dual_blocks)
        psd = exact_psd_ldlt(block; block_index=index)
        if !psd.accepted
            merge!(details, psd.details)
            return _failed(:farkas_exact, "non_psd_dual_block"; details=details)
        end
    end
    separation = _computed_separation(problem, dual_equalities, dual_blocks)
    details["separation"] = _rational_string(separation)
    isfinite(candidate.separation) && candidate.separation < 0 ||
        return _failed(:farkas_exact, "declared_separation_not_negative"; details=details)
    details["declared_separation"] = string(candidate.separation)
    separation < 0 ||
        return _failed(:farkas_exact, "separation_not_strictly_negative"; details=details)
    norm_one = sum(abs, dual_equalities; init=BigInt(0) // BigInt(1))
    for block in dual_blocks
        norm_one += sum(abs, block; init=BigInt(0) // BigInt(1))
    end
    norm_one > 0 || return _failed(:farkas_exact, "zero_ray"; details=details)
    details["normalized_separation"] = _rational_string(separation / norm_one)
    _accepted(:farkas_exact, details)
end

function _decimal_rational_exact(text::AbstractString)
    value = strip(lowercase(text))
    occursin('/', value) && begin
        pieces = split(value, '/'; limit=2)
        return parse(BigInt, pieces[1]) // parse(BigInt, pieces[2])
    end
    sign = startswith(value, "-") ? -1 : 1
    unsigned = lstrip(value, ['-', '+'])
    pieces = split(unsigned, 'e'; limit=2)
    mantissa = pieces[1]
    exponent = length(pieces) == 2 ? parse(Int, pieces[2]) : 0
    decimals = occursin('.', mantissa) ? length(split(mantissa, '.'; limit=2)[2]) : 0
    digits = replace(mantissa, "." => "")
    numerator_value = sign * parse(BigInt, digits)
    scale = decimals - exponent
    scale >= 0 ? numerator_value // (BigInt(10)^scale) :
                 numerator_value * BigInt(10)^(-scale) // BigInt(1)
end

_big_interval(value::Rational) = IntervalArithmetic.bareinterval(BigFloat, value)
_box_radius(center::Rational) = max(abs(center) / BigInt(10)^14,
                                    BigInt(1) // BigInt(10)^30)

function _candidate_box(center::Rational)
    radius = _box_radius(center)
    IntervalArithmetic.bareinterval(BigFloat, center - radius, center + radius)
end

function _interval_farkas(problem, candidate, layout, identity, details)
    centers = try
        _flatten_candidate(candidate, layout; decimal=true)
    catch error
        details["error"] = sprint(showerror, error)
        return _failed(:inconclusive_interval, "nonfinite_or_unparseable"; details=details)
    end
    all(isfinite, candidate.dual_equalities) &&
        all(block -> all(isfinite, block), candidate.dual_psd_blocks) &&
        isfinite(candidate.separation) && candidate.separation < 0 ||
        return _failed(:inconclusive_interval, "nonfinite_or_wrong_separation_sign";
                       details=details)

    rref, pivots = _exact_rref(identity)
    free = setdiff(collect(eachindex(centers)), pivots)
    declared_boxes = [_candidate_box(center) for center in centers]
    coordinate_boxes = copy(declared_boxes)
    for (row, pivot) in enumerate(pivots)
        solution = _big_interval(BigInt(0) // BigInt(1))
        for column in free
            solution -= _big_interval(rref[row, column]) * coordinate_boxes[column]
        end
        declared = declared_boxes[pivot]
        (IntervalArithmetic.inf(solution) > IntervalArithmetic.inf(declared) &&
         IntervalArithmetic.sup(solution) < IntervalArithmetic.sup(declared)) || begin
            details["failed_pivot"] = layout[pivot].id
            return _failed(:inconclusive_interval, "krawczyk_inclusion_failed";
                           details=details)
        end
        coordinate_boxes[pivot] = solution
    end
    details["inclusion"] = "proved"
    details["inclusion_method"] = "exact-RREF-preconditioned-Rump"
    details["precision_bits"] = "256"
    details["pivot_coordinates"] = join((layout[index].id for index in pivots), ',')
    details["free_coordinates"] = join((layout[index].id for index in free), ',')

    # Uniform cone proof over the very same coordinate enclosure.
    for (block_index, problem_block) in enumerate(problem.psd_blocks)
        matrix = [_big_interval(BigInt(0) // BigInt(1))
                  for _ in 1:problem_block.dimension, _ in 1:problem_block.dimension]
        for (coordinate, entry) in enumerate(layout)
            entry.kind == :psd && entry.block == block_index || continue
            matrix[entry.row, entry.col] = coordinate_boxes[coordinate]
            matrix[entry.col, entry.row] = coordinate_boxes[coordinate]
        end
        for row in 1:problem_block.dimension
            radius = _big_interval(BigInt(0) // BigInt(1))
            for col in 1:problem_block.dimension
                row == col && continue
                radius += abs(matrix[row, col])
            end
            lower = IntervalArithmetic.inf(matrix[row, row] - radius)
            lower >= 0 || begin
                details["block"] = string(block_index)
                details["row"] = string(row)
                return _failed(:inconclusive_interval, "uniform_psd_not_proved";
                               details=details)
            end
        end
    end

    separation = _big_interval(BigInt(0) // BigInt(1))
    for (coordinate, entry) in enumerate(layout)
        coefficient = if entry.kind == :equality
            -problem.equalities[entry.equality][2]
        else
            block = problem.psd_blocks[entry.block]
            factor = entry.row == entry.col ? 1 : 2
            constant = findfirst(item -> item[1] == entry.row && item[2] == entry.col,
                                 block.constant_entries)
            constant === nothing ? BigInt(0) // BigInt(1) :
                factor * block.constant_entries[constant][3]
        end
        separation += _big_interval(coefficient) * coordinate_boxes[coordinate]
    end
    declared_center = _decimal_rational_exact(string(candidate.separation))
    declared_box = _candidate_box(declared_center)
    (IntervalArithmetic.inf(separation) <= IntervalArithmetic.sup(declared_box) &&
     IntervalArithmetic.inf(declared_box) <= IntervalArithmetic.sup(separation)) ||
        return _failed(:inconclusive_interval, "separation_enclosures_disjoint";
                       details=details)
    separation_upper = IntervalArithmetic.sup(separation)
    details["separation_lower"] = string(IntervalArithmetic.inf(separation))
    details["separation_upper"] = string(separation_upper)
    separation_upper < 0 ||
        return _failed(:inconclusive_interval, "strict_separation_not_proved";
                       details=details)
    _accepted(:farkas_interval, details)
end

function verify_farkas(problem::ConicFeasibility, candidate::FarkasCandidate)
    problem_hash = canonical_hash(problem)
    candidate_hash = _candidate_hash("farkas-v1", candidate.dual_equalities,
                                     candidate.dual_psd_blocks,
                                     candidate.separation,
                                     candidate.problem_hash)
    details = Dict("problem_hash" => problem_hash,
                   "candidate_hash" => candidate_hash,
                   "certificate_hash" => candidate_hash)
    candidate.problem_hash == problem_hash ||
        return _failed(:farkas_exact, "problem_hash_mismatch"; details=details)
    length(candidate.dual_equalities) == length(problem.equalities) ||
        return _failed(:farkas_exact, "wrong_dual_equality_count"; details=details)
    length(candidate.dual_psd_blocks) == length(problem.psd_blocks) ||
        return _failed(:farkas_exact, "wrong_dual_psd_block_count"; details=details)

    for (index, (problem_block, candidate_block)) in
            enumerate(zip(problem.psd_blocks, candidate.dual_psd_blocks))
        size(candidate_block) == (problem_block.dimension, problem_block.dimension) || begin
            details["block"] = string(index)
            return _failed(:farkas_exact, "wrong_dual_psd_block_size"; details=details)
        end
    end
    layout = _dual_layout(problem)
    identity = _identity_matrix(problem, layout)
    exact = _exact_farkas(problem, candidate, layout, identity, copy(details))
    exact.accepted && return exact
    interval_details = copy(details)
    interval_details["exact_failure"] = get(exact.details, "reason", "unknown")
    setprecision(BigFloat, 256) do
        _interval_farkas(problem, candidate, layout, identity, interval_details)
    end
end

function verify_farkas(problem::ConicFeasibility, artifact::SolverArtifact)
    expected_hash = canonical_hash(problem)
    details = Dict("problem_hash" => expected_hash,
                   "artifact_problem_hash" => artifact.problem_hash)
    artifact.problem_hash == expected_hash ||
        return _failed(:farkas_exact, "problem_hash_mismatch"; details=details)
    (artifact.dual_equalities === nothing || artifact.dual_psd_blocks === nothing) &&
        return _failed(:farkas_exact, "missing_farkas_candidate"; details=details)
    separation = try
        _farkas_float_separation(problem, artifact.dual_equalities,
                                 artifact.dual_psd_blocks)
    catch error
        details["error"] = sprint(showerror, error)
        return _failed(:farkas_exact, "nonfinite_or_unreconstructable"; details=details)
    end
    verify_farkas(problem,
                  FarkasCandidate(artifact.dual_equalities,
                                  artifact.dual_psd_blocks,
                                  separation, artifact.problem_hash))
end

"""
Conservative 256-bit outward interval PSD bound for a fixed matrix.

This uses Gershgorin lower bounds.  Failure to obtain a nonnegative bound is
reported as inconclusive; it is never converted into a cone certificate.
"""
function interval_psd_bound(matrix::AbstractMatrix{<:Real}; block_index::Int=1)
    rows, cols = size(matrix)
    rows == cols || return _failed(:inconclusive_interval, "nonsquare";
        details=Dict("block" => string(block_index)))
    all(isfinite, matrix) || return _failed(:inconclusive_interval, "nonfinite";
        details=Dict("block" => string(block_index)))
    matrix == transpose(matrix) || return _failed(:inconclusive_interval, "nonsymmetric";
        details=Dict("block" => string(block_index)))
    return setprecision(BigFloat, 256) do
        intervals = [IntervalArithmetic.bareinterval(
                         BigFloat, rationalize(BigInt, matrix[row, col]; tol=0))
                     for row in 1:rows, col in 1:cols]
        lower_bounds = Any[]
        for row in 1:rows
            radius = IntervalArithmetic.bareinterval(BigFloat, 0)
            for col in 1:cols
                row == col && continue
                radius += abs(intervals[row, col])
            end
            push!(lower_bounds, intervals[row, row] - radius)
        end
        minimum_lower = minimum(IntervalArithmetic.inf(bound) for bound in lower_bounds)
        details = Dict("block" => string(block_index),
                       "precision_bits" => "256",
                       "gershgorin_lower" => string(minimum_lower))
        minimum_lower >= 0 ||
            return _failed(:inconclusive_interval, "psd_boundary_not_proved";
                           details=details)
        _accepted(:psd_interval, details)
    end
end
