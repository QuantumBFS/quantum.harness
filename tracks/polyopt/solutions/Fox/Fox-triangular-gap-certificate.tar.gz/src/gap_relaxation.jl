_word_tuple_key(word::PauliWord) =
    Tuple((factor.site, String(factor.axis)) for factor in word.factors)
_state_monomial_tuple_key(monomial::StateMonomial) =
    Tuple(_word_tuple_key(symbol.word) for symbol in monomial.symbols)
_nc_monomial_tuple_key(monomial::NCStateMonomial) =
    (_state_monomial_tuple_key(StateMonomial(monomial.symbols)),
     _word_tuple_key(monomial.operator_word))

"""A canonical exact polynomial in commuting state-expectation symbols."""
struct StatePolynomial
    terms::Tuple

    function StatePolynomial(terms::AbstractDict{StateMonomial,<:Number})
        canonical = Dict{StateMonomial,ExactComplex}()
        for (monomial, coefficient) in terms
            exact = convert(ExactComplex, coefficient)
            canonical[monomial] = get(canonical, monomial, EXACT_ZERO) + exact
        end
        filter!(pair -> !iszero(pair.second), canonical)
        ordered = sort!(collect(canonical); by=pair -> _state_monomial_tuple_key(first(pair)))
        new(Tuple(ordered))
    end
end

StatePolynomial() = StatePolynomial(Dict{StateMonomial,ExactComplex}())
StatePolynomial(monomial::StateMonomial, coefficient::Number=EXACT_ONE) =
    StatePolynomial(Dict{StateMonomial,ExactComplex}(monomial => convert(ExactComplex, coefficient)))

Base.:(==)(left::StatePolynomial, right::StatePolynomial) = left.terms == right.terms
Base.isempty(polynomial::StatePolynomial) = isempty(polynomial.terms)

function Base.:+(left::StatePolynomial, right::StatePolynomial)
    terms = Dict{StateMonomial,ExactComplex}(left.terms)
    for (monomial, coefficient) in right.terms
        terms[monomial] = get(terms, monomial, EXACT_ZERO) + coefficient
    end
    StatePolynomial(terms)
end

Base.:-(polynomial::StatePolynomial) = (-1) * polynomial
Base.:-(left::StatePolynomial, right::StatePolynomial) = left + (-right)

function Base.:*(left::StatePolynomial, right::StatePolynomial)
    terms = Dict{StateMonomial,ExactComplex}()
    for (left_monomial, left_coefficient) in left.terms
        for (right_monomial, right_coefficient) in right.terms
            monomial = StateMonomial((left_monomial.symbols..., right_monomial.symbols...))
            terms[monomial] = get(terms, monomial, EXACT_ZERO) +
                              left_coefficient * right_coefficient
        end
    end
    StatePolynomial(terms)
end

function Base.:*(scalar::Number, polynomial::StatePolynomial)
    exact = convert(ExactComplex, scalar)
    StatePolynomial(Dict{StateMonomial,ExactComplex}(
        monomial => exact * coefficient for (monomial, coefficient) in polynomial.terms))
end

Base.:*(polynomial::StatePolynomial, scalar::Number) = scalar * polynomial
function Base.:/(polynomial::StatePolynomial, scalar::Integer)
    iszero(scalar) && throw(DivideError())
    (BigInt(1) // BigInt(scalar)) * polynomial
end
Base.adjoint(polynomial::StatePolynomial) =
    StatePolynomial(Dict{StateMonomial,ExactComplex}(
        adjoint(monomial) => conj(coefficient)
        for (monomial, coefficient) in polynomial.terms))

"""An exact polynomial whose final Pauli factor retains noncommutative order."""
struct NCStatePolynomial
    terms::Tuple

    function NCStatePolynomial(terms::AbstractDict{NCStateMonomial,<:Number})
        canonical = Dict{NCStateMonomial,ExactComplex}()
        for (monomial, coefficient) in terms
            exact = convert(ExactComplex, coefficient)
            canonical[monomial] = get(canonical, monomial, EXACT_ZERO) + exact
        end
        filter!(pair -> !iszero(pair.second), canonical)
        ordered = sort!(collect(canonical); by=pair -> _nc_monomial_tuple_key(first(pair)))
        new(Tuple(ordered))
    end
end

NCStatePolynomial() = NCStatePolynomial(Dict{NCStateMonomial,ExactComplex}())
NCStatePolynomial(monomial::NCStateMonomial, coefficient::Number=EXACT_ONE) =
    NCStatePolynomial(Dict{NCStateMonomial,ExactComplex}(
        monomial => convert(ExactComplex, coefficient)))

Base.:(==)(left::NCStatePolynomial, right::NCStatePolynomial) = left.terms == right.terms

function Base.:+(left::NCStatePolynomial, right::NCStatePolynomial)
    terms = Dict{NCStateMonomial,ExactComplex}(left.terms)
    for (monomial, coefficient) in right.terms
        terms[monomial] = get(terms, monomial, EXACT_ZERO) + coefficient
    end
    NCStatePolynomial(terms)
end

Base.:-(polynomial::NCStatePolynomial) = (-1) * polynomial
Base.:-(left::NCStatePolynomial, right::NCStatePolynomial) = left + (-right)

function Base.:*(scalar::Number, polynomial::NCStatePolynomial)
    exact = convert(ExactComplex, scalar)
    NCStatePolynomial(Dict{NCStateMonomial,ExactComplex}(
        monomial => exact * coefficient for (monomial, coefficient) in polynomial.terms))
end

Base.:*(polynomial::NCStatePolynomial, scalar::Number) = scalar * polynomial

function multiply_nc(left::NCStateMonomial, right::NCStateMonomial)
    phase, operator_word = multiply(left.operator_word, right.operator_word)
    NCStateMonomial((left.symbols..., right.symbols...), operator_word), phase
end

function Base.:*(left::NCStatePolynomial, right::NCStatePolynomial)
    terms = Dict{NCStateMonomial,ExactComplex}()
    for (left_monomial, left_coefficient) in left.terms
        for (right_monomial, right_coefficient) in right.terms
            monomial, phase = multiply_nc(left_monomial, right_monomial)
            terms[monomial] = get(terms, monomial, EXACT_ZERO) +
                              left_coefficient * right_coefficient * phase
        end
    end
    NCStatePolynomial(terms)
end

Base.:*(left::NCStateMonomial, right::NCStateMonomial) =
    NCStatePolynomial(left) * NCStatePolynomial(right)
Base.:*(left::NCStateMonomial, right::NCStatePolynomial) = NCStatePolynomial(left) * right
Base.:*(left::NCStatePolynomial, right::NCStateMonomial) = left * NCStatePolynomial(right)

function nc_state_polynomial(operator::ExactOperator)
    NCStatePolynomial(Dict{NCStateMonomial,ExactComplex}(
        NCStateMonomial((), word) => coefficient for (word, coefficient) in operator.terms))
end

Base.:*(operator::ExactOperator, monomial::NCStateMonomial) =
    nc_state_polynomial(operator) * monomial
Base.:*(monomial::NCStateMonomial, operator::ExactOperator) =
    monomial * nc_state_polynomial(operator)

function Base.:*(left::ExactOperator, right::ExactOperator)
    terms = Dict{PauliWord,ExactComplex}()
    for (left_word, left_coefficient) in left.terms
        for (right_word, right_coefficient) in right.terms
            phase, word = multiply(left_word, right_word)
            terms[word] = get(terms, word, EXACT_ZERO) +
                          left_coefficient * right_coefficient * phase
        end
    end
    ExactOperator(terms)
end

Base.:-(operator::ExactOperator) =
    ExactOperator(Dict(word => -coefficient for (word, coefficient) in operator.terms))
Base.:-(left::ExactOperator, right::ExactOperator) = left + (-right)
Base.:(==)(left::ExactOperator, right::ExactOperator) = left.terms == right.terms

"""Exact commutator with a basis monomial; state symbols remain commuting scalars."""
function commutator(operator::ExactOperator, monomial::NCStateMonomial)
    isempty(monomial.operator_word.factors) && return NCStatePolynomial()
    monomial_support = Set(support(monomial.operator_word))
    active_terms = Dict{PauliWord,ExactComplex}(
        word => coefficient for (word, coefficient) in operator.terms
        if any(site -> site in monomial_support, support(word)))
    active_operator = ExactOperator(active_terms)
    active_operator * monomial - monomial * active_operator
end
commutator(left::ExactOperator, right::ExactOperator) = left * right - right * left

"""Apply the formal state map, turning the final Pauli factor into a state symbol."""
function state_polynomial(polynomial::NCStatePolynomial)
    terms = Dict{StateMonomial,ExactComplex}()
    for (monomial, coefficient) in polynomial.terms
        symbols = isempty(monomial.operator_word.factors) ? monomial.symbols :
                  (monomial.symbols..., StateSymbol(monomial.operator_word))
        state_monomial = StateMonomial(symbols)
        terms[state_monomial] = get(terms, state_monomial, EXACT_ZERO) + coefficient
    end
    StatePolynomial(terms)
end

state_polynomial(monomial::NCStateMonomial) = state_polynomial(NCStatePolynomial(monomial))
state_polynomial(operator::ExactOperator) = state_polynomial(nc_state_polynomial(operator))
state_polynomial(polynomial::StatePolynomial) = polynomial
state_symbol(value) = state_polynomial(value)

function _direct_moment_entry(left::NCStateMonomial, right::NCStateMonomial)
    monomial, phase = multiply_nc(adjoint(left), right)
    symbols = isempty(monomial.operator_word.factors) ? monomial.symbols :
              (monomial.symbols..., StateSymbol(monomial.operator_word))
    StatePolynomial(StateMonomial(symbols), phase)
end

moment_entry(left::NCStateMonomial, right::NCStateMonomial) =
    _direct_moment_entry(left, right)

function gap_entry(left::NCStateMonomial, right::NCStateMonomial,
                   hamiltonian::ExactOperator, gamma::Rational)
    kinetic = (state_polynomial(adjoint(left) * commutator(hamiltonian, right)) -
               state_polynomial(commutator(hamiltonian, adjoint(left)) * right)) / 2
    variance = moment_entry(left, right) -
               state_polynomial(adjoint(left)) * state_polynomial(right)
    kinetic - gamma * variance
end

function state_monomial_serialization(monomial::StateMonomial)
    isempty(monomial.symbols) && return "1"
    join((state_symbol_serialization(symbol) for symbol in monomial.symbols), '*')
end

state_variable_name(monomial::StateMonomial) = "L(" * state_monomial_serialization(monomial) * ")"

function polynomial_component(polynomial::StatePolynomial, component::Symbol, sign::Int=1)
    component in (:real, :imag) || throw(ArgumentError("component must be :real or :imag"))
    Dict(monomial => sign * (component == :real ? real(coefficient) : imag(coefficient))
         for (monomial, coefficient) in polynomial.terms
         if !iszero(component == :real ? real(coefficient) : imag(coefficient)))
end

function assert_hermitian(matrix::AbstractMatrix{StatePolynomial})
    size(matrix, 1) == size(matrix, 2) || throw(ArgumentError("state matrix must be square"))
    for row in axes(matrix, 1), col in axes(matrix, 2)
        matrix[row, col] == adjoint(matrix[col, row]) ||
            throw(ArgumentError("state matrix is not Hermitian at ($row,$col)"))
    end
    true
end

"""Convert a complex Hermitian state matrix into [Re(M) -Im(M); Im(M) Re(M)]."""
function realified_psd_block(matrix::AbstractMatrix{StatePolynomial}, variable_names)
    assert_hermitian(matrix)
    dimension = size(matrix, 1)
    name_to_index = Dict(String(name) => index for (index, name) in enumerate(variable_names))
    entries = AffineEntry[]
    for row in 1:(2 * dimension), col in row:(2 * dimension)
        polynomial, component, sign = if row <= dimension && col <= dimension
            (matrix[row, col], :real, 1)
        elseif row <= dimension < col
            (matrix[row, col - dimension], :imag, -1)
        else
            (matrix[row - dimension, col - dimension], :real, 1)
        end
        for (monomial, coefficient) in polynomial_component(polynomial, component, sign)
            name = state_variable_name(monomial)
            haskey(name_to_index, name) || throw(ArgumentError("missing state variable $name"))
            push!(entries, AffineEntry(row, col, name_to_index[name], coefficient))
        end
    end
    PSDBlock(2 * dimension, Tuple{Int,Int,Rational{BigInt}}[], entries)
end

function _discover_hermitian_monomials!(monomials, dimension, entry)
    for row in 1:dimension, col in row:dimension
        upper = entry(row, col)
        lower = entry(col, row)
        upper == adjoint(lower) ||
            throw(ArgumentError("state matrix is not Hermitian at ($row,$col)"))
        for (monomial, _) in upper.terms
            push!(monomials, monomial)
        end
        for (monomial, _) in lower.terms
            push!(monomials, monomial)
        end
    end
    monomials
end

function _assert_hermitian_entries(dimension, entry)
    for row in 1:dimension, col in row:dimension
        entry(row, col) == adjoint(entry(col, row)) ||
            throw(ArgumentError("state matrix is not Hermitian at ($row,$col)"))
    end
    true
end

function _register_provisional_monomials!(
    monomials,
    provisional_indices,
    provisional_monomials,
    polynomial,
)
    for (monomial, _) in polynomial.terms
        push!(monomials, monomial)
        if !haskey(provisional_indices, monomial)
            push!(provisional_monomials, monomial)
            provisional_indices[monomial] = length(provisional_monomials)
        end
    end
    nothing
end

function _append_provisional_component!(
    entries,
    row,
    col,
    polynomial,
    component,
    sign,
    provisional_indices,
)
    for (monomial, coefficient) in polynomial.terms
        component_coefficient = sign *
            (component == :real ? real(coefficient) : imag(coefficient))
        iszero(component_coefficient) && continue
        push!(entries, AffineEntry(
            row, col, provisional_indices[monomial], component_coefficient))
    end
    nothing
end

function _discover_realified_psd_entries!(
    monomials,
    provisional_indices,
    provisional_monomials,
    dimension,
    entry,
)
    entries = AffineEntry[]
    for row in 1:dimension, col in row:dimension
        upper = entry(row, col)
        lower = entry(col, row)
        upper == adjoint(lower) ||
            throw(ArgumentError("state matrix is not Hermitian at ($row,$col)"))
        _register_provisional_monomials!(
            monomials, provisional_indices, provisional_monomials, upper)
        _register_provisional_monomials!(
            monomials, provisional_indices, provisional_monomials, lower)

        _append_provisional_component!(
            entries, row, col, upper, :real, 1, provisional_indices)
        _append_provisional_component!(
            entries, dimension + row, dimension + col,
            upper, :real, 1, provisional_indices)
        _append_provisional_component!(
            entries, row, dimension + col, upper, :imag, -1, provisional_indices)
        row == col || _append_provisional_component!(
            entries, col, dimension + row, lower, :imag, -1, provisional_indices)
    end
    entries
end

function _streamed_realified_psd_block(
    dimension,
    entries::Vector{AffineEntry},
    provisional_monomials,
    variable_names,
)
    name_to_index = Dict(String(name) => index for (index, name) in enumerate(variable_names))
    provisional_to_final = Int[]
    sizehint!(provisional_to_final, length(provisional_monomials))
    for monomial in provisional_monomials
        name = state_variable_name(monomial)
        haskey(name_to_index, name) || throw(ArgumentError("missing state variable $name"))
        push!(provisional_to_final, name_to_index[name])
    end
    for index in eachindex(entries)
        old = entries[index]
        entries[index] = AffineEntry(
            old.row, old.col, provisional_to_final[old.variable], old.coefficient)
    end
    sort!(entries; by=_variable_key)
    PSDBlock(2 * dimension, Tuple{Int,Int,Rational{BigInt}}[], entries)
end

function _streamed_realified_psd_block(dimension, entry, variable_names)
    name_to_index = Dict(String(name) => index for (index, name) in enumerate(variable_names))
    entries = AffineEntry[]
    for row in 1:(2 * dimension), col in row:(2 * dimension)
        polynomial, component, sign = if row <= dimension && col <= dimension
            (entry(row, col), :real, 1)
        elseif row <= dimension < col
            (entry(row, col - dimension), :imag, -1)
        else
            (entry(row - dimension, col - dimension), :real, 1)
        end
        cell_entries = AffineEntry[]
        for (monomial, coefficient) in polynomial.terms
            component_coefficient = sign *
                (component == :real ? real(coefficient) : imag(coefficient))
            iszero(component_coefficient) && continue
            name = state_variable_name(monomial)
            haskey(name_to_index, name) || throw(ArgumentError("missing state variable $name"))
            push!(cell_entries,
                  AffineEntry(row, col, name_to_index[name], component_coefficient))
        end
        sort!(cell_entries; by=entry -> entry.variable)
        append!(entries, cell_entries)
    end
    PSDBlock(2 * dimension, Tuple{Int,Int,Rational{BigInt}}[], entries)
end

function remap_pauli_word(word::PauliWord, source::TriangularPatch,
                          target::TriangularPatch)
    factors = PauliFactor[]
    for factor in word.factors
        coordinate = source.sites[factor.site]
        haskey(target.index, coordinate) ||
            throw(ArgumentError("cannot remap Pauli support outside target patch"))
        push!(factors, PauliFactor(target.index[coordinate], factor.axis))
    end
    PauliWord(Tuple(factors))
end

function generated_operator_serialization(word::PauliWord, patch::TriangularPatch)
    isempty(word.factors) && return "identity"
    join((let coordinate = patch.sites[factor.site]
              "$(factor.axis)@$(coordinate.q),$(coordinate.r)"
          end for factor in word.factors), ';')
end

function exact_closure_check(outer::TriangularPatch, halo::TriangularPatch,
                             outer_hamiltonian::ExactOperator,
                             halo_hamiltonian::ExactOperator,
                             monomial::NCStateMonomial)
    halo_monomial = NCStateMonomial(
        monomial.symbols, remap_pauli_word(monomial.operator_word, outer, halo))
    halo_commutator = commutator(halo_hamiltonian, halo_monomial)
    failures = String[]
    for (generated, coefficient) in halo_commutator.terms
        outside = sort!(unique!(Axial[
            halo.sites[factor.site] for factor in generated.operator_word.factors
            if !haskey(outer.index, halo.sites[factor.site])
        ]))
        isempty(outside) && continue
        outside_text = join(("$(coordinate.q),$(coordinate.r)" for coordinate in outside), ';')
        coefficient_text =
            "$(numerator(real(coefficient)))/$(denominator(real(coefficient)))" *
            "+$(numerator(imag(coefficient)))/$(denominator(imag(coefficient)))im"
        push!(failures,
              "generated_operator=$(generated_operator_serialization(generated.operator_word, halo))" *
              ",outside_coordinates=$outside_text,coefficient=$coefficient_text")
    end
    sort!(unique!(failures))
    isempty(failures) || return nothing, Tuple(failures)

    remapped_terms = Dict{NCStateMonomial,ExactComplex}()
    for (generated, coefficient) in halo_commutator.terms
        outer_generated = NCStateMonomial(
            generated.symbols, remap_pauli_word(generated.operator_word, halo, outer))
        remapped_terms[outer_generated] =
            get(remapped_terms, outer_generated, EXACT_ZERO) + coefficient
    end
    remapped = NCStatePolynomial(remapped_terms)
    open_commutator = commutator(outer_hamiltonian, monomial)
    remapped == open_commutator ||
        throw(ArgumentError("support-closed halo commutator disagrees with open-patch commutator"))
    open_commutator, ()
end

function buffered_inner_words(patch::TriangularPatch, basis::RelaxationBasis,
                              outer_hamiltonian::ExactOperator;
                              requested_inner_words=nothing)
    declared = requested_inner_words === nothing ? basis.words : Tuple(requested_inner_words)
    all(word -> word isa NCStateMonomial, declared) ||
        throw(ArgumentError("inner words must be NCStateMonomial values"))
    all(word -> word in basis.words, declared) ||
        throw(ArgumentError("requested inner words must belong to the relaxation basis"))

    halo = build_patch(patch.L + 2)
    halo_hamiltonian = triangular_hamiltonian(halo, 1//10)
    accepted = NCStateMonomial[]
    accepted_commutators = NCStatePolynomial[]
    skipped = Pair{NCStateMonomial,String}[]
    for word in declared
        open_commutator, failures = exact_closure_check(
            patch, halo, outer_hamiltonian, halo_hamiltonian, word)
        if isempty(failures)
            push!(accepted, word)
            push!(accepted_commutators, open_commutator)
        elseif requested_inner_words === nothing
            push!(skipped, word => join(failures, " || "))
        else
            throw(ArgumentError(
                "requested inner word is partially supported by its exact halo commutator: " *
                join(failures, " || ")))
        end
    end
    Tuple(accepted), Tuple(accepted_commutators), Tuple(skipped), halo
end

function polynomial_monomials(polynomials)
    monomials = Set{StateMonomial}()
    for polynomial in polynomials, (monomial, _) in polynomial.terms
        push!(monomials, monomial)
    end
    monomials
end

function state_monomial_order_key(monomial::StateMonomial)
    (sum(length(symbol.word.factors) for symbol in monomial.symbols; init=0),
     state_monomial_serialization(monomial))
end

function equality_from_component(polynomial::StatePolynomial, component::Symbol, name_to_index)
    terms = Pair{Int,Rational{BigInt}}[]
    for (monomial, coefficient) in polynomial_component(polynomial, component)
        push!(terms, name_to_index[state_variable_name(monomial)] => coefficient)
    end
    terms, BigInt(0) // BigInt(1)
end

function rational_string(value::Rational)
    "$(numerator(value))/$(denominator(value))"
end

function skipped_word_serialization(skipped)
    join((monomial_serialization(word) * "=>" * reason for (word, reason) in skipped), "\n")
end

function _build_gap_relaxation_dense_reference(
    patch::TriangularPatch,
    basis::RelaxationBasis,
    spec::RunSpec;
    requested_inner_words=nothing,
)
    spec.L == patch.L || throw(ArgumentError("RunSpec L does not match the outer patch"))
    spec.d >= 0 || throw(ArgumentError("RunSpec degree must be nonnegative"))
    spec.rung == basis.rung || throw(ArgumentError("RunSpec rung does not match the basis"))
    spec.scope == basis.scope || throw(ArgumentError("RunSpec scope does not match the basis"))
    spec.g == 1//10 || throw(ArgumentError("Phase 1 requires g = 1//10"))

    hamiltonian = triangular_hamiltonian(patch, spec.g)
    basis_adjoints = adjoint.(basis.words)
    moment_matrix = [state_polynomial(basis_adjoints[row] * basis.words[col])
                     for row in eachindex(basis.words), col in eachindex(basis.words)]
    inner_words, inner_commutators, skipped, halo = buffered_inner_words(
        patch, basis, hamiltonian; requested_inner_words=requested_inner_words)
    inner_adjoints = adjoint.(inner_words)
    inner_adjoint_commutators = [commutator(hamiltonian, word) for word in inner_adjoints]
    inner_state_values = state_polynomial.(inner_words)
    inner_adjoint_state_values = state_polynomial.(inner_adjoints)
    inner_moment_matrix = [state_polynomial(inner_adjoints[row] * inner_words[col])
                           for row in eachindex(inner_words), col in eachindex(inner_words)]
    kinetic_matrix = [
        (state_polynomial(inner_adjoints[row] * inner_commutators[col]) -
         state_polynomial(inner_adjoint_commutators[row] * inner_words[col])) / 2
        for row in eachindex(inner_words), col in eachindex(inner_words)
    ]
    gap_matrix = [
        kinetic_matrix[row, col] - spec.gamma *
            (inner_moment_matrix[row, col] -
             inner_adjoint_state_values[row] * inner_state_values[col])
        for row in eachindex(inner_words), col in eachindex(inner_words)
    ]
    assert_hermitian(moment_matrix)
    assert_hermitian(kinetic_matrix)
    assert_hermitian(gap_matrix)

    stationarity = state_polynomial.(inner_commutators)

    monomials = Set([StateMonomial()])
    union!(monomials, polynomial_monomials(moment_matrix))
    union!(monomials, polynomial_monomials(gap_matrix))
    union!(monomials, polynomial_monomials(stationarity))
    ordered_monomials = sort!(collect(monomials); by=state_monomial_order_key)
    variable_names = Tuple(state_variable_name(monomial) for monomial in ordered_monomials)
    name_to_index = Dict(name => index for (index, name) in enumerate(variable_names))

    equalities = Any[
        ([name_to_index[state_variable_name(StateMonomial())] => 1//1], 1//1),
    ]
    append!(equalities,
            [equality_from_component(polynomial, :real, name_to_index)
             for polynomial in stationarity])
    append!(equalities,
            [equality_from_component(polynomial, :imag, name_to_index)
             for polynomial in stationarity])

    psd_blocks = [realified_psd_block(moment_matrix, variable_names),
                  realified_psd_block(gap_matrix, variable_names)]
    metadata = Dict(
        "basis_hash" => basis.hash,
        "boundary_condition" => "open_outer_patch",
        "closure_method" => "exact_halo_commutator",
        "constraint_order" =>
            "normalization,moment_psd,stationarity_real,stationarity_imag,gap_psd",
        "diagnostic_scope" => "finite_open_patch_checks_do_not_imply_thermodynamic_claims",
        "gamma" => rational_string(spec.gamma),
        "geometry_hash" => geometry_manifest(patch).hash,
        "hamiltonian_hash" => operator_hash(hamiltonian),
        "halo_L" => string(halo.L),
        "inner_word_count" => string(length(inner_words)),
        "inner_words" => join((monomial_serialization(word) for word in inner_words), '\n'),
        "open_hamiltonian_match" => "true",
        "scope" => String(spec.scope),
        "skipped_word_count" => string(length(skipped)),
        "skipped_words" => skipped_word_serialization(skipped),
    )
    ConicFeasibility(variable_names, equalities, psd_blocks, metadata)
end

"""Assemble the unrestricted open-patch bulk-gap conic relaxation in auditable order."""
function build_gap_relaxation(patch::TriangularPatch, basis::RelaxationBasis, spec::RunSpec;
                              requested_inner_words=nothing)
    spec.L == patch.L || throw(ArgumentError("RunSpec L does not match the outer patch"))
    spec.d >= 0 || throw(ArgumentError("RunSpec degree must be nonnegative"))
    spec.rung == basis.rung || throw(ArgumentError("RunSpec rung does not match the basis"))
    spec.scope == basis.scope || throw(ArgumentError("RunSpec scope does not match the basis"))
    spec.g == 1//10 || throw(ArgumentError("Phase 1 requires g = 1//10"))

    hamiltonian = triangular_hamiltonian(patch, spec.g)
    basis_adjoints = adjoint.(basis.words)
    inner_words, inner_commutators, skipped, halo = buffered_inner_words(
        patch, basis, hamiltonian; requested_inner_words=requested_inner_words)
    inner_adjoints = adjoint.(inner_words)
    inner_adjoint_commutators = [commutator(hamiltonian, word) for word in inner_adjoints]
    inner_state_values = state_polynomial.(inner_words)
    inner_adjoint_state_values = state_polynomial.(inner_adjoints)

    moment_oracle(row, col) = _direct_moment_entry(basis.words[row], basis.words[col])
    kinetic_oracle(row, col) =
        (state_polynomial(inner_adjoints[row] * inner_commutators[col]) -
         state_polynomial(inner_adjoint_commutators[row] * inner_words[col])) / 2
    function gap_oracle(row, col)
        variance = _direct_moment_entry(inner_words[row], inner_words[col]) -
                   inner_adjoint_state_values[row] * inner_state_values[col]
        kinetic_oracle(row, col) - spec.gamma * variance
    end

    stationarity = state_polynomial.(inner_commutators)

    monomials = Set([StateMonomial()])
    provisional_indices = Dict{StateMonomial,Int}()
    provisional_monomials = StateMonomial[]
    moment_entries = _discover_realified_psd_entries!(
        monomials, provisional_indices, provisional_monomials,
        length(basis_adjoints), moment_oracle)
    _assert_hermitian_entries(length(inner_words), kinetic_oracle)
    gap_entries = _discover_realified_psd_entries!(
        monomials, provisional_indices, provisional_monomials,
        length(inner_words), gap_oracle)
    union!(monomials, polynomial_monomials(stationarity))
    ordered_monomials = sort!(collect(monomials); by=state_monomial_order_key)
    variable_names = Tuple(state_variable_name(monomial) for monomial in ordered_monomials)
    name_to_index = Dict(name => index for (index, name) in enumerate(variable_names))

    equalities = Any[
        ([name_to_index[state_variable_name(StateMonomial())] => 1//1], 1//1),
    ]
    append!(equalities,
            [equality_from_component(polynomial, :real, name_to_index)
             for polynomial in stationarity])
    append!(equalities,
            [equality_from_component(polynomial, :imag, name_to_index)
             for polynomial in stationarity])

    psd_blocks = [
        _streamed_realified_psd_block(
            length(basis.words), moment_entries, provisional_monomials, variable_names),
        _streamed_realified_psd_block(
            length(inner_words), gap_entries, provisional_monomials, variable_names),
    ]
    metadata = Dict(
        "basis_hash" => basis.hash,
        "boundary_condition" => "open_outer_patch",
        "closure_method" => "exact_halo_commutator",
        "constraint_order" =>
            "normalization,moment_psd,stationarity_real,stationarity_imag,gap_psd",
        "diagnostic_scope" => "finite_open_patch_checks_do_not_imply_thermodynamic_claims",
        "gamma" => rational_string(spec.gamma),
        "geometry_hash" => geometry_manifest(patch).hash,
        "hamiltonian_hash" => operator_hash(hamiltonian),
        "halo_L" => string(halo.L),
        "inner_word_count" => string(length(inner_words)),
        "inner_words" => join((monomial_serialization(word) for word in inner_words), '\n'),
        "open_hamiltonian_match" => "true",
        "scope" => String(spec.scope),
        "skipped_word_count" => string(length(skipped)),
        "skipped_words" => skipped_word_serialization(skipped),
    )
    ConicFeasibility(variable_names, equalities, psd_blocks, metadata)
end
