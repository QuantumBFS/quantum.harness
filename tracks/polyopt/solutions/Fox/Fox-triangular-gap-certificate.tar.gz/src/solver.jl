import JuMP
import MathOptInterface
import MosekTools

const MOI = MathOptInterface

abstract type AbstractSolverBackend end

"""Production solver backend. No fallback optimizer is permitted."""
struct MosekBackend <: AbstractSolverBackend end

"""Raw solver output and any candidate point or ray returned by the optimizer."""
struct SolverArtifact
    raw::RawSolveRecord
    problem_hash::String
    primal_values::Union{Nothing,Vector{Float64}}
    dual_equalities::Union{Nothing,Vector{Float64}}
    dual_psd_blocks::Union{Nothing,Vector{Matrix{Float64}}}
    solver_name::String
    solver_version::String
end

_status_symbol(status::Symbol) = status
_status_symbol(status) = Symbol(string(status))

function raw_status_record(termination_status, primal_status, dual_status,
                           runtime_seconds::Real,
                           diagnostics::AbstractDict{<:AbstractString,<:Real},
                           message::AbstractString)
    runtime = Float64(runtime_seconds)
    isfinite(runtime) && runtime >= 0 ||
        throw(ArgumentError("runtime_seconds must be finite and nonnegative"))
    RawSolveRecord(_status_symbol(termination_status),
                   _status_symbol(primal_status),
                   _status_symbol(dual_status), runtime,
                   Dict{String,Float64}(String(key) => Float64(value)
                                        for (key, value) in diagnostics),
                   String(message))
end

_as_float(value::ExactRational) = Float64(value)

function _add_canonical_conic!(model::JuMP.Model, problem::ConicFeasibility)
    validate_conic(problem)
    variable_count = length(problem.variable_names)
    variables = JuMP.@variable(model, [1:variable_count], base_name="x")
    for (index, name) in enumerate(problem.variable_names)
        JuMP.set_name(variables[index], name)
    end

    equality_constraints = JuMP.ConstraintRef[]
    for (coefficients, rhs) in problem.equalities
        expression = JuMP.AffExpr(0.0)
        for (variable, coefficient) in coefficients
            JuMP.add_to_expression!(expression, _as_float(coefficient),
                                    variables[variable])
        end
        push!(equality_constraints,
              JuMP.@constraint(model, expression == _as_float(rhs)))
    end

    psd_constraints = JuMP.ConstraintRef[]
    for block in problem.psd_blocks
        dimension = block.dimension
        matrix = [JuMP.AffExpr(0.0) for _ in 1:dimension, _ in 1:dimension]
        for (row, col, coefficient) in block.constant_entries
            JuMP.add_to_expression!(matrix[row, col], _as_float(coefficient))
        end
        for entry in block.variable_entries
            JuMP.add_to_expression!(matrix[entry.row, entry.col],
                                    _as_float(entry.coefficient),
                                    variables[entry.variable])
        end
        for row in 1:dimension, col in (row + 1):dimension
            matrix[col, row] = copy(matrix[row, col])
        end
        push!(psd_constraints,
              JuMP.@constraint(model, matrix in JuMP.PSDCone()))
    end
    return variables, equality_constraints, psd_constraints
end

_has_primal_point(status::MOI.ResultStatusCode) =
    status == MOI.FEASIBLE_POINT || status == MOI.NEARLY_FEASIBLE_POINT

_has_farkas_dual_ray(status::MOI.ResultStatusCode) =
    status == MOI.INFEASIBILITY_CERTIFICATE ||
    status == MOI.NEARLY_INFEASIBILITY_CERTIFICATE

function _solver_identity(model::JuMP.Model)
    name = try
        JuMP.solver_name(model)
    catch
        "Mosek"
    end
    version = try
        String(MOI.get(JuMP.backend(model), MOI.SolverVersion()))
    catch
        "unknown"
    end
    return name, version
end

function _raw_message(model::JuMP.Model)
    try
        String(JuMP.raw_status(model))
    catch
        ""
    end
end

function _dual_psd_matrix(constraint::JuMP.ConstraintRef)
    candidate = JuMP.dual(constraint)
    matrix = Matrix{Float64}(candidate)
    size(matrix, 1) == size(matrix, 2) ||
        throw(ArgumentError("solver returned a non-square PSD dual candidate"))
    matrix
end

function _solve_mosek(problem::ConicFeasibility, timeout_seconds::Float64)
    problem_hash = canonical_hash(problem)
    model = nothing
    solver_name = "Mosek"
    solver_version = "unknown"
    started = time()
    try
        model = JuMP.Model(MosekTools.Optimizer)
        JuMP.set_time_limit_sec(model, timeout_seconds)
        JuMP.set_silent(model)
        variables, equality_constraints, psd_constraints =
            _add_canonical_conic!(model, problem)
        solver_name, solver_version = _solver_identity(model)

        JuMP.optimize!(model)
        runtime = time() - started
        termination = JuMP.termination_status(model)
        primal_status = JuMP.primal_status(model)
        dual_status = JuMP.dual_status(model)
        result_count = JuMP.result_count(model)
        diagnostics = Dict{String,Float64}("result_count" => Float64(result_count))
        raw = raw_status_record(termination, primal_status, dual_status, runtime,
                                diagnostics, _raw_message(model))

        primal_values = if result_count >= 1 && _has_primal_point(primal_status)
            Float64[JuMP.value(variable) for variable in variables]
        else
            nothing
        end
        if result_count >= 1 && _has_farkas_dual_ray(dual_status)
            dual_equalities = Float64[JuMP.dual(constraint)
                                       for constraint in equality_constraints]
            dual_psd_blocks = Matrix{Float64}[_dual_psd_matrix(constraint)
                                               for constraint in psd_constraints]
        else
            dual_equalities = nothing
            dual_psd_blocks = nothing
        end
        return SolverArtifact(raw, problem_hash, primal_values,
                              dual_equalities, dual_psd_blocks,
                              solver_name, solver_version)
    catch error
        runtime = time() - started
        if model !== nothing
            solver_name, solver_version = _solver_identity(model)
        end
        message = sprint(showerror, error)
        raw = raw_status_record(:OTHER_ERROR, :NO_SOLUTION, :NO_SOLUTION,
                                runtime, Dict{String,Float64}(), message)
        return SolverArtifact(raw, problem_hash, nothing, nothing, nothing,
                              solver_name, solver_version)
    end
end

function solve_problem(problem::ConicFeasibility, ::MosekBackend,
                       timeout_seconds::Real)
    timeout = Float64(timeout_seconds)
    isfinite(timeout) && timeout > 0 ||
        throw(ArgumentError("timeout_seconds must be finite and positive"))
    _solve_mosek(problem, timeout)
end
