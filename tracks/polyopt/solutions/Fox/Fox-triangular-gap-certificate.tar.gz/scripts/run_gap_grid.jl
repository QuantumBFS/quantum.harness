#!/usr/bin/env julia

using TriangularGapCertificates

const GRID_ARGUMENTS = Set(("L", "d", "rung", "output", "timeout"))
const GRID_REQUIRED_ARGUMENTS = Set(("L", "d", "rung", "output"))

function _parse_grid_arguments(arguments)
    iseven(length(arguments)) ||
        throw(ArgumentError("every grid option requires a value"))
    values = Dict{String,String}()
    for index in 1:2:length(arguments)
        option = arguments[index]
        startswith(option, "--") ||
            throw(ArgumentError("grid options must start with --"))
        key = option[3:end]
        key in GRID_ARGUMENTS || throw(ArgumentError("unknown grid option --$key"))
        haskey(values, key) && throw(ArgumentError("duplicate grid option --$key"))
        values[key] = arguments[index + 1]
    end
    issubset(GRID_REQUIRED_ARGUMENTS, Set(keys(values))) ||
        throw(ArgumentError("--L, --d, --rung, and --output are required"))
    L = parse(Int, values["L"])
    d = parse(Int, values["d"])
    rung = Symbol(values["rung"])
    timeout = parse(Int, get(values, "timeout", "300"))
    L >= 1 || throw(ArgumentError("--L must be at least 1"))
    d >= 0 || throw(ArgumentError("--d must be nonnegative"))
    rung in (:A, :B) || throw(ArgumentError("--rung must be A or B"))
    rung == :A || d >= 2 || throw(ArgumentError("Rung B requires --d at least 2"))
    timeout > 0 || throw(ArgumentError("--timeout must be positive"))
    (L=L, d=d, rung=rung, output=values["output"], timeout=timeout)
end

function _grid_rational(value::Rational)
    denominator(value) == 1 && return string(numerator(value))
    "$(numerator(value))/$(denominator(value))"
end

function main_grid(arguments=ARGS)
    options = _parse_grid_arguments(arguments)
    records = run_phase1_grid(; L=options.L, d=options.d, rung=options.rung,
                              output_root=options.output,
                              timeout_seconds=options.timeout,
                              scope=:unrestricted, solver=MosekBackend())
    for record in records
        directory = artifact_directory(options.output, record.spec)
        println("gamma=$(_grid_rational(record.spec.gamma)) " *
                "raw=$(record.raw.termination_status) " *
                "verifier=$(record.verification.method) " *
                "verdict=$(Symbol(record.verdict)) " *
                "runtime=$(record.raw.runtime_seconds)s artifact=$directory")
    end
    0
end

if abspath(PROGRAM_FILE) == @__FILE__
    exit(main_grid())
end
