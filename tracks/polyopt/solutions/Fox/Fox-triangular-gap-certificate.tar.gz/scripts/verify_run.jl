#!/usr/bin/env julia

using TriangularGapCertificates
using JSON3
using SHA

const SELECTOR_KEYS = ("root", "g", "gamma", "L", "d", "rung", "scope")

function _usage_error(message)
    throw(ArgumentError("$message. Supply one run directory, or all of " *
                        join(("--" * key for key in SELECTOR_KEYS), ", ")))
end

function _parse_arguments(arguments)
    if length(arguments) == 1 && !startswith(arguments[1], "--")
        return abspath(arguments[1])
    end
    any(!startswith(argument, "--") for argument in arguments[1:2:end]) &&
        _usage_error("selector names must start with --")
    iseven(length(arguments)) || _usage_error("every selector requires a value")
    selectors = Dict{String,String}()
    for index in 1:2:length(arguments)
        key = arguments[index][3:end]
        key in SELECTOR_KEYS || _usage_error("unknown selector --$key")
        haskey(selectors, key) && _usage_error("duplicate selector --$key")
        selectors[key] = arguments[index + 1]
    end
    Set(keys(selectors)) == Set(SELECTOR_KEYS) ||
        _usage_error("selector mode requires the complete selector set")
    _resolve_selector(selectors)
end

function _json_property(object, key::String)
    symbol = Symbol(key)
    hasproperty(object, symbol) ? getproperty(object, symbol) : nothing
end

function _decimal_rational(text::AbstractString)
    value = strip(text)
    occursin('/', value) && begin
        pieces = split(value, '/'; limit=2)
        return parse(BigInt, pieces[1]) // parse(BigInt, pieces[2])
    end
    sign = startswith(value, "-") ? -1 : 1
    unsigned = lstrip(value, ['-', '+'])
    pieces = split(lowercase(unsigned), 'e'; limit=2)
    mantissa = pieces[1]
    exponent = length(pieces) == 2 ? parse(Int, pieces[2]) : 0
    decimals = occursin('.', mantissa) ? length(split(mantissa, '.'; limit=2)[2]) : 0
    digits = replace(mantissa, "." => "")
    numerator_value = sign * parse(BigInt, digits)
    scale = decimals - exponent
    scale >= 0 ? numerator_value // (BigInt(10)^scale) :
                 numerator_value * BigInt(10)^(-scale) // BigInt(1)
end

function _spec_rational(value)
    if hasproperty(value, :numerator) && hasproperty(value, :denominator)
        return parse(BigInt, string(value.numerator)) //
               parse(BigInt, string(value.denominator))
    end
    _decimal_rational(string(value))
end

function _canonical_spec(document)
    g = _spec_rational(document.g)
    gamma = _spec_rational(document.gamma)
    (g=(numerator=string(numerator(g)), denominator=string(denominator(g))),
     gamma=(numerator=string(numerator(gamma)),
            denominator=string(denominator(gamma))),
     L=Int(document.L), d=Int(document.d), rung=String(document.rung),
     scope=String(document.scope), timeout_seconds=Int(document.timeout_seconds))
end

function _two_decimal(value::Rational)
    scaled = value * 100
    denominator(scaled) == 1 || throw(ArgumentError("run id requires two-decimal g/gamma"))
    integer = Int(numerator(scaled))
    string(integer ÷ 100, ".", lpad(string(abs(integer) % 100), 2, '0'))
end

function _expected_run_id(document)
    spec = _canonical_spec(document)
    encoded = JSON3.write(spec)
    suffix = bytes2hex(SHA.sha256(codeunits(encoded)))[1:12]
    g = _spec_rational(spec.g)
    gamma = _spec_rational(spec.gamma)
    "g-$(_two_decimal(g))__gamma-$(_two_decimal(gamma))__L-$(spec.L)__" *
    "d-$(spec.d)__rung-$(spec.rung)__scope-$(spec.scope)__$suffix"
end

_valid_content_address(directory, document) =
    basename(normpath(directory)) == _expected_run_id(document)

function _selector_value(spec, key)
    key == "g" && return _spec_rational(spec.g)
    key == "gamma" && return _spec_rational(spec.gamma)
    string(_json_property(spec, key))
end

function _selector_equal(key, stored, requested)
    stored === nothing && return false
    if key in ("g", "gamma")
        try
            stored_rational = stored isa Rational ? stored : _decimal_rational(stored)
            return stored_rational == _decimal_rational(requested)
        catch
            return false
        end
    end
    string(stored) == string(requested)
end

function _resolve_selector(selectors)
    root = abspath(selectors["root"])
    isdir(root) || _usage_error("selector root is not a directory")
    matches = String[]
    for (directory, _, files) in walkdir(root)
        ("spec.json" in files && "problem.json" in files &&
         "solver_artifact.json" in files) || continue
        spec = try
            JSON3.read(read(joinpath(directory, "spec.json"), String))
        catch
            continue
        end
        _valid_content_address(directory, spec) || continue
        all(key -> _selector_equal(key, _selector_value(spec, key),
                                   selectors[key]),
            ("g", "gamma", "L", "d", "rung", "scope")) && push!(matches, directory)
    end
    length(matches) == 1 ||
        _usage_error("selector resolved $(length(matches)) runs; exactly one is required")
    only(matches)
end

function _float_vector(value)
    value === nothing && return nothing
    Float64[Float64(item) for item in value]
end

function _float_blocks(value)
    value === nothing && return nothing
    blocks = Matrix{Float64}[]
    for block in value
        dimension = length(block)
        all(row -> length(row) == dimension, block) ||
            throw(ArgumentError("dual PSD blocks must be square arrays"))
        push!(blocks, [Float64(block[row][col]) for row in 1:dimension,
                                                col in 1:dimension])
    end
    blocks
end

function _verify_document(problem, document)
    problem_hash = String(document.problem_hash)
    problem_hash == canonical_hash(problem) ||
        return VerificationRecord(false, :not_checked,
            Dict("reason" => "problem_hash_mismatch",
                 "problem_hash" => canonical_hash(problem),
                 "artifact_problem_hash" => problem_hash))

    primal = hasproperty(document, :primal_values) ?
             _float_vector(document.primal_values) : nothing
    if primal !== nothing
        verification = verify_primal(problem, primal)
        verification.accepted && return verification
    end

    dual_equalities = hasproperty(document, :dual_equalities) ?
                      _float_vector(document.dual_equalities) : nothing
    dual_blocks = hasproperty(document, :dual_psd_blocks) ?
                  _float_blocks(document.dual_psd_blocks) : nothing
    (dual_equalities === nothing || dual_blocks === nothing) &&
        return VerificationRecord(false, :not_checked,
            Dict("reason" => "no_complete_candidate",
                 "problem_hash" => canonical_hash(problem)))
    separation = try
        TriangularGapCertificates._farkas_float_separation(
            problem, dual_equalities, dual_blocks)
    catch error
        return VerificationRecord(false, :not_checked,
            Dict("reason" => "candidate_separation_reconstruction_failed",
                 "problem_hash" => canonical_hash(problem),
                 "error" => sprint(showerror, error)))
    end
    candidate = FarkasCandidate(dual_equalities, dual_blocks, separation, problem_hash)
    verify_farkas(problem, candidate)
end

function _atomic_write_verification(directory, verification)
    destination = joinpath(directory, "verification.json")
    document = (format="triangular-gap-verification-v1",
                accepted=verification.accepted,
                method=String(verification.method),
                details=verification.details)
    temporary_path, io = mktemp(directory)
    try
        write(io, JSON3.write(document))
        write(io, '\n')
        flush(io)
        close(io)
        mv(temporary_path, destination; force=true)
    catch
        isopen(io) && close(io)
        isfile(temporary_path) && rm(temporary_path)
        rethrow()
    end
    destination
end

function main(arguments=ARGS)
    directory = _parse_arguments(arguments)
    isdir(directory) || _usage_error("run directory does not exist")
    verification = try
        problem_path = joinpath(directory, "problem.json")
        artifact_path = joinpath(directory, "solver_artifact.json")
        isfile(problem_path) || throw(ArgumentError("problem.json is missing"))
        isfile(artifact_path) || throw(ArgumentError("solver_artifact.json is missing"))
        problem = parse_conic_json(read(problem_path, String))
        artifact = JSON3.read(read(artifact_path, String))
        _verify_document(problem, artifact)
    catch error
        details = Dict("reason" => "verification_error",
                       "error" => sprint(showerror, error))
        problem_path = joinpath(directory, "problem.json")
        if isfile(problem_path)
            try
                problem = parse_conic_json(read(problem_path, String))
                details["problem_hash"] = canonical_hash(problem)
            catch
            end
        end
        artifact_path = joinpath(directory, "solver_artifact.json")
        if isfile(artifact_path)
            try
                artifact = JSON3.read(read(artifact_path, String))
                hasproperty(artifact, :problem_hash) &&
                    (details["artifact_problem_hash"] = String(artifact.problem_hash))
            catch
            end
        end
        VerificationRecord(false, :not_checked, details)
    end
    _atomic_write_verification(directory, verification)
    margin = get(verification.details, "normalized_separation",
                 get(verification.details, "separation", "n/a"))
    println("method=$(verification.method) margin=$margin")
    verification.accepted ? 0 : 2
end

if abspath(PROGRAM_FILE) == @__FILE__
    exit(main())
end
