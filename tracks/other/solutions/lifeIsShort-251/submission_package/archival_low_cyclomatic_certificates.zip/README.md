# Archival low-cyclomatic certificate companion — not part of the proposed submission

This directory preserves exact computational artifacts generated during an earlier exploration of weighted forest negative correlation on graphs of cyclomatic number at most four.

The certificate files verify integer polynomial identities for the four small 3-connected cores

- `K4`,
- the four-wheel `W4`,
- `K3,3`, and
- the triangular prism.

The verifier checks 16 edge-pair orbits and 4,982 nonzero Rayleigh-difference monomials using exact integer arithmetic.

## Why this material was removed from the journal manuscript

The graph-class conclusion is not the strongest new contribution: prior work that all regular matroids on at most nine elements are independent-set Rayleigh, together with known 2-sum closure, substantially covers the low-cyclomatic conclusion. The final submission therefore focuses on the apparently new general star-marginal stability theorem and the differential-unrooting mechanism.

These files are retained solely for provenance and auditability. **Do not upload this directory as part of the proposed E-JC submission unless an editor or referee specifically requests it.**

## Verification

From this directory run:

```bash
python3 supplement/verify_certificates.py supplement/certificates.json
```

Expected summary:

```text
VERIFIED 16 edge-pair orbits exactly;
4982 Rayleigh-difference monomials checked.
```

The certificate SHA-256 recorded in the earlier exploration is:

```text
9d5fa9de66676e8876d625ebb7ad425a534467a48d28750724a37880761748eb
```
