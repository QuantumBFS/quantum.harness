#!/usr/bin/env python3
"""Independent exact verifier for the weighted-forest SOS certificates.

The program uses only the Python standard library.  It enumerates forests,
constructs the Rayleigh difference over Z[y_1,...,y_m], reconstructs the
Wagner-form sum of squares from certificates.json, and compares coefficient
dictionaries exactly.  It also verifies that the listed pairs represent every
automorphism orbit of unordered edge pairs in each core graph.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

Exponent = Tuple[int, ...]
Polynomial = Dict[Exponent, int]
Edge = Tuple[int, int]


def is_forest(n: int, edges: Sequence[Edge], mask: int) -> bool:
    parent = list(range(n))
    rank = [0] * n

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for i, (u, v) in enumerate(edges):
        if not (mask >> i) & 1:
            continue
        a, b = find(u), find(v)
        if a == b:
            return False
        if rank[a] < rank[b]:
            a, b = b, a
        parent[b] = a
        if rank[a] == rank[b]:
            rank[a] += 1
    return True


def component_count(n: int, edges: Sequence[Edge], mask: int) -> int:
    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for i, (u, v) in enumerate(edges):
        if (mask >> i) & 1:
            a, b = find(u), find(v)
            if a != b:
                parent[b] = a
    return len({find(v) for v in range(n)})


def unique_cycle_mask(n: int, edges: Sequence[Edge], mask: int) -> int | None:
    """Return the edge mask of the unique cycle, or None if cycle rank != 1."""
    selected = [i for i in range(len(edges)) if (mask >> i) & 1]
    if len(selected) - n + component_count(n, edges, mask) != 1:
        return None

    degree = [0] * n
    adjacency: List[List[Tuple[int, int]]] = [[] for _ in range(n)]
    for i in selected:
        u, v = edges[i]
        degree[u] += 1
        degree[v] += 1
        adjacency[u].append((v, i))
        adjacency[v].append((u, i))

    removed_edge = [False] * len(edges)
    removed_vertex = [False] * n
    queue = deque(v for v in range(n) if degree[v] <= 1)
    while queue:
        v = queue.popleft()
        if removed_vertex[v]:
            continue
        removed_vertex[v] = True
        for w, i in adjacency[v]:
            if not removed_edge[i]:
                removed_edge[i] = True
                degree[w] -= 1
                if degree[w] == 1:
                    queue.append(w)

    cycle_edges = [i for i in selected if not removed_edge[i]]
    if not cycle_edges:
        return None
    cycle_vertices = set()
    cycle_degree = Counter()
    for i in cycle_edges:
        u, v = edges[i]
        cycle_vertices.update((u, v))
        cycle_degree[u] += 1
        cycle_degree[v] += 1
    if any(cycle_degree[v] != 2 for v in cycle_vertices):
        return None

    # Connectivity of the surviving 2-core, with parallel edges counted by IDs.
    start = next(iter(cycle_vertices))
    seen = {start}
    stack = [start]
    cycle_edge_set = set(cycle_edges)
    while stack:
        v = stack.pop()
        for w, i in adjacency[v]:
            if i in cycle_edge_set and w not in seen:
                seen.add(w)
                stack.append(w)
    if seen != cycle_vertices:
        return None

    answer = 0
    for i in cycle_edges:
        answer |= 1 << i
    return answer


def clean(poly: Mapping[Exponent, int]) -> Polynomial:
    return {e: c for e, c in poly.items() if c}


def add(p: Mapping[Exponent, int], q: Mapping[Exponent, int]) -> Polynomial:
    out: defaultdict[Exponent, int] = defaultdict(int)
    out.update(p)
    for exponent, coeff in q.items():
        out[exponent] += coeff
    return clean(out)


def subtract(p: Mapping[Exponent, int], q: Mapping[Exponent, int]) -> Polynomial:
    out: defaultdict[Exponent, int] = defaultdict(int)
    out.update(p)
    for exponent, coeff in q.items():
        out[exponent] -= coeff
    return clean(out)


def multiply(p: Mapping[Exponent, int], q: Mapping[Exponent, int]) -> Polynomial:
    out: defaultdict[Exponent, int] = defaultdict(int)
    for a, ca in p.items():
        for b, cb in q.items():
            out[tuple(x + y for x, y in zip(a, b))] += ca * cb
    return clean(out)


def derivative(p: Mapping[Exponent, int], variable: int) -> Polynomial:
    out: defaultdict[Exponent, int] = defaultdict(int)
    for exponent, coeff in p.items():
        power = exponent[variable]
        if power:
            reduced = list(exponent)
            reduced[variable] -= 1
            out[tuple(reduced)] += power * coeff
    return clean(out)


def forest_polynomial(n: int, edges: Sequence[Edge]) -> Polynomial:
    m = len(edges)
    out: defaultdict[Exponent, int] = defaultdict(int)
    for mask in range(1 << m):
        if is_forest(n, edges, mask):
            exponent = tuple(int((mask >> i) & 1) for i in range(m))
            out[exponent] += 1
    return dict(out)


def rayleigh_difference(poly: Mapping[Exponent, int], e: int, f: int) -> Polynomial:
    pe = derivative(poly, e)
    pf = derivative(poly, f)
    pef = derivative(pe, f)
    return subtract(multiply(pe, pf), multiply(poly, pef))


def enumerate_sos_data(
    n: int, edges: Sequence[Edge], e: int, f: int
) -> Dict[int, List[Tuple[int, int]]]:
    """Map each S-mask to its ordered list of (A-mask, unique-cycle-mask)."""
    m = len(edges)
    ef = (1 << e) | (1 << f)
    terms: defaultdict[int, List[Tuple[int, int]]] = defaultdict(list)
    for a_mask in range(1 << m):
        if a_mask & ef or not is_forest(n, edges, a_mask):
            continue
        cycle = unique_cycle_mask(n, edges, a_mask | ef)
        if cycle is None or not (cycle & (1 << e)) or not (cycle & (1 << f)):
            continue
        cycle_without_ef = cycle & ~ef
        s_mask = cycle_without_ef
        subset = s_mask
        while True:
            terms[subset].append((a_mask, cycle))
            if subset == 0:
                break
            subset = (subset - 1) & s_mask
    return dict(terms)


def mask_exponent(mask: int, m: int) -> Exponent:
    return tuple(int((mask >> i) & 1) for i in range(m))


def sos_polynomial_from_certificate(
    n: int,
    edges: Sequence[Edge],
    e: int,
    f: int,
    sign_records: Sequence[Mapping[str, object]],
) -> Tuple[Polynomial, int]:
    m = len(edges)
    terms = enumerate_sos_data(n, edges, e, f)
    supplied: Dict[int, Dict[int, int]] = {}
    for record in sign_records:
        s_mask = int(record["S"])
        if s_mask in supplied:
            raise ValueError(f"duplicate S={s_mask}")
        cycle_signs: Dict[int, int] = {}
        for item in record["cycle_signs"]:  # type: ignore[index]
            cycle = int(item["cycle"])
            sign = int(item["sign"])
            if sign not in (-1, 1):
                raise ValueError(f"invalid sign {sign} for S={s_mask}, cycle={cycle}")
            if cycle in cycle_signs:
                raise ValueError(f"duplicate cycle sign for S={s_mask}, cycle={cycle}")
            cycle_signs[cycle] = sign
        supplied[s_mask] = cycle_signs

    if set(supplied) != set(terms):
        missing = sorted(set(terms) - set(supplied))
        extra = sorted(set(supplied) - set(terms))
        raise ValueError(f"S-set mismatch; missing={missing}, extra={extra}")

    total: Polynomial = {}
    for s_mask, a_terms in terms.items():
        expected_cycles = {cycle for _, cycle in a_terms}
        if set(supplied[s_mask]) != expected_cycles:
            missing = sorted(expected_cycles - set(supplied[s_mask]))
            extra = sorted(set(supplied[s_mask]) - expected_cycles)
            raise ValueError(
                f"cycle-sign mismatch for S={s_mask}; missing={missing}, extra={extra}"
            )

        inner: defaultdict[Exponent, int] = defaultdict(int)
        for a_mask, cycle in a_terms:
            exponent = mask_exponent(a_mask & ~s_mask, m)
            inner[exponent] += supplied[s_mask][cycle]
        square = multiply(clean(inner), clean(inner))
        shifted: defaultdict[Exponent, int] = defaultdict(int)
        s_exp = mask_exponent(s_mask, m)
        for exponent, coeff in square.items():
            shifted[tuple(x + y for x, y in zip(exponent, s_exp))] += coeff
        total = add(total, shifted)
    return total, len(terms)


def graph_automorphisms(n: int, edges: Sequence[Edge]) -> List[Tuple[int, ...]]:
    """Return edge permutations induced by vertex automorphisms (simple cores only)."""
    normalized = [tuple(sorted(edge)) for edge in edges]
    if len(set(normalized)) != len(normalized):
        raise ValueError("orbit checker expects a simple graph")
    edge_index = {edge: i for i, edge in enumerate(normalized)}
    edge_set = set(normalized)
    automorphisms = []
    for permutation in itertools.permutations(range(n)):
        image = {
            tuple(sorted((permutation[u], permutation[v]))) for u, v in normalized
        }
        if image != edge_set:
            continue
        induced = tuple(
            edge_index[tuple(sorted((permutation[u], permutation[v])))]
            for u, v in normalized
        )
        automorphisms.append(induced)
    return automorphisms


def edge_pair_orbits(n: int, edges: Sequence[Edge]) -> List[set[Tuple[int, int]]]:
    automorphisms = graph_automorphisms(n, edges)
    unseen = set(itertools.combinations(range(len(edges)), 2))
    orbits: List[set[Tuple[int, int]]] = []
    while unseen:
        pair = min(unseen)
        orbit = {
            tuple(sorted((permutation[pair[0]], permutation[pair[1]])))
            for permutation in automorphisms
        }
        unseen -= orbit
        orbits.append(orbit)
    return orbits


def format_monomial(exponent: Exponent) -> str:
    factors = []
    for i, power in enumerate(exponent):
        if power == 1:
            factors.append(f"y{i}")
        elif power:
            factors.append(f"y{i}^{power}")
    return "1" if not factors else "*".join(factors)


def verify_file(path: Path) -> None:
    raw = path.read_bytes()
    payload = json.loads(raw)
    if payload.get("format_version") != 1:
        raise ValueError("unsupported certificate format")

    total_orbits = 0
    total_delta_monomials = 0
    for graph in payload["graphs"]:
        name = str(graph["name"])
        n = int(graph["n"])
        edges = [tuple(map(int, edge)) for edge in graph["edges"]]
        m = len(edges)
        if any(u == v or not (0 <= u < n and 0 <= v < n) for u, v in edges):
            raise ValueError(f"malformed edge in {name}")

        actual_orbits = edge_pair_orbits(n, edges)
        records = graph["orbit_representatives"]
        reps = [tuple(sorted((int(r["e"]), int(r["f"])))) for r in records]
        if len(reps) != len(actual_orbits) or len(set(reps)) != len(reps):
            raise ValueError(f"wrong number of distinct orbit representatives for {name}")
        for orbit in actual_orbits:
            hits = [rep for rep in reps if rep in orbit]
            if len(hits) != 1:
                raise ValueError(f"orbit coverage failure in {name}: {sorted(orbit)}; hits={hits}")

        forest_poly = forest_polynomial(n, edges)
        for record, rep in zip(records, reps):
            e, f = rep
            if not (0 <= e < f < m):
                raise ValueError(f"invalid pair {rep} in {name}")
            orbit = next(orbit for orbit in actual_orbits if rep in orbit)
            if int(record["orbit_size"]) != len(orbit):
                raise ValueError(f"wrong orbit size for {name} pair {rep}")

            delta = rayleigh_difference(forest_poly, e, f)
            sos, s_count = sos_polynomial_from_certificate(
                n, edges, e, f, record["signs"]
            )
            if int(record["delta_monomials"]) != len(delta):
                raise ValueError(f"wrong monomial metadata for {name} pair {rep}")
            if int(record["S_count"]) != s_count:
                raise ValueError(f"wrong S-count metadata for {name} pair {rep}")
            if delta != sos:
                discrepancy = subtract(delta, sos)
                sample = sorted(discrepancy.items())[:8]
                rendered = ", ".join(
                    f"{coeff:+d} {format_monomial(exp)}" for exp, coeff in sample
                )
                raise AssertionError(
                    f"SOS identity failed for {name} pair {rep}; "
                    f"{len(discrepancy)} discrepant monomials; sample: {rendered}"
                )
            print(
                f"PASS {name:5s} pair=({e},{f}) orbit={len(orbit):2d} "
                f"Delta_terms={len(delta):4d} S_sets={s_count:2d}"
            )
            total_orbits += 1
            total_delta_monomials += len(delta)

    digest = hashlib.sha256(raw).hexdigest()
    print(
        f"VERIFIED {total_orbits} edge-pair orbits exactly; "
        f"{total_delta_monomials} Rayleigh-difference monomials checked."
    )
    print(f"certificate_sha256={digest}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "certificates",
        nargs="?",
        type=Path,
        default=Path(__file__).with_name("certificates.json"),
    )
    args = parser.parse_args()
    verify_file(args.certificates)


if __name__ == "__main__":
    main()
