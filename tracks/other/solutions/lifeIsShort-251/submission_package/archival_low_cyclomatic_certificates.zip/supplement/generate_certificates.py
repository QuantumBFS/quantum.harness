#!/usr/bin/env python3
"""Re-discover the exact SOS certificates by exhaustive sign search.

This script is not needed to *verify* the result.  It is supplied to make the
small finite search reproducible.  It imports the independent exact polynomial
routines from verify_certificates.py and searches at most 4096 local sign
combinations for any one edge-pair orbit in the present data set.
"""
from __future__ import annotations

import argparse
import itertools
import json
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Mapping, Sequence, Tuple

from verify_certificates import (
    Edge,
    Exponent,
    Polynomial,
    add,
    clean,
    edge_pair_orbits,
    enumerate_sos_data,
    forest_polynomial,
    mask_exponent,
    multiply,
    rayleigh_difference,
)

GRAPHS = {
    "K4": {
        "n": 4,
        "edges": [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)],
        "reps": [(0, 1), (0, 5)],
    },
    "W4": {
        "n": 5,
        "edges": [(0, 1), (1, 2), (2, 3), (3, 0), (4, 0), (4, 1), (4, 2), (4, 3)],
        "reps": [(0, 4), (4, 6), (0, 2), (0, 6), (4, 5), (0, 1)],
    },
    "K33": {
        "n": 6,
        "edges": [(i, j) for i in range(3) for j in range(3, 6)],
        "reps": [(0, 1), (0, 4)],
    },
    "prism": {
        "n": 6,
        "edges": [(0, 1), (1, 2), (2, 0), (3, 4), (4, 5), (5, 3), (0, 3), (1, 4), (2, 5)],
        "reps": [(0, 1), (0, 6), (0, 8), (0, 4), (0, 3), (6, 7)],
    },
}


def local_square(
    s_mask: int,
    a_terms: Sequence[Tuple[int, int]],
    signs: Mapping[int, int],
    m: int,
) -> Polynomial:
    inner: defaultdict[Exponent, int] = defaultdict(int)
    for a_mask, cycle in a_terms:
        inner[mask_exponent(a_mask & ~s_mask, m)] += signs[cycle]
    square = multiply(clean(inner), clean(inner))
    shift = mask_exponent(s_mask, m)
    return {
        tuple(a + b for a, b in zip(exponent, shift)): coefficient
        for exponent, coefficient in square.items()
    }


def find_signs(n: int, edges: Sequence[Edge], e: int, f: int):
    m = len(edges)
    forest_poly = forest_polynomial(n, edges)
    target = rayleigh_difference(forest_poly, e, f)
    terms = enumerate_sos_data(n, edges, e, f)

    fixed_polynomial: Polynomial = {}
    fixed_signs: Dict[int, Dict[int, int]] = {}
    variables = []
    for s_mask in sorted(terms):
        a_terms = terms[s_mask]
        cycles = sorted({cycle for _, cycle in a_terms})
        options = []
        for tail in itertools.product((-1, 1), repeat=max(0, len(cycles) - 1)):
            signs = {cycles[0]: 1}
            signs.update({cycle: sign for cycle, sign in zip(cycles[1:], tail)})
            polynomial = local_square(s_mask, a_terms, signs, m)
            options.append((polynomial, signs))
        # Different sign assignments can yield the same local square.
        deduplicated = []
        seen = set()
        for polynomial, signs in options:
            key = tuple(sorted(polynomial.items()))
            if key not in seen:
                seen.add(key)
                deduplicated.append((polynomial, signs))
        if len(deduplicated) == 1:
            fixed_polynomial = add(fixed_polynomial, deduplicated[0][0])
            fixed_signs[s_mask] = deduplicated[0][1]
        else:
            variables.append((s_mask, deduplicated))

    combinations = 1
    for _, options in variables:
        combinations *= len(options)
    for choice in itertools.product(*[range(len(options)) for _, options in variables]):
        polynomial = dict(fixed_polynomial)
        signs_by_s = dict(fixed_signs)
        for (s_mask, options), option_index in zip(variables, choice):
            local_polynomial, signs = options[option_index]
            polynomial = add(polynomial, local_polynomial)
            signs_by_s[s_mask] = signs
        if polynomial == target:
            return signs_by_s, target, terms, combinations
    raise RuntimeError(f"no signs found for pair {(e, f)}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).with_name("certificates.regenerated.json"),
    )
    args = parser.parse_args()

    payload = {
        "format_version": 1,
        "description": (
            "Exact Wagner-form sum-of-squares certificates for all edge-pair "
            "automorphism orbits of K4, W4, K3,3, and the triangular prism. "
            "Edge subsets are encoded as integer bit masks."
        ),
        "graphs": [],
    }

    for name, graph in GRAPHS.items():
        n = graph["n"]
        edges = graph["edges"]
        orbits = edge_pair_orbits(n, edges)
        graph_record = {
            "name": name,
            "n": n,
            "edges": [list(edge) for edge in edges],
            "orbit_representatives": [],
        }
        for e, f in graph["reps"]:
            orbit = next(orbit for orbit in orbits if (e, f) in orbit)
            signs, target, terms, combinations = find_signs(n, edges, e, f)
            sign_records = []
            for s_mask in sorted(signs):
                sign_records.append(
                    {
                        "S": s_mask,
                        "cycle_signs": [
                            {"cycle": cycle, "sign": int(signs[s_mask][cycle])}
                            for cycle in sorted(signs[s_mask])
                        ],
                    }
                )
            graph_record["orbit_representatives"].append(
                {
                    "e": e,
                    "f": f,
                    "orbit_size": len(orbit),
                    "delta_monomials": len(target),
                    "S_count": len(terms),
                    "signs": sign_records,
                }
            )
            print(
                f"FOUND {name:5s} pair=({e},{f}) "
                f"search_space<={combinations}"
            )
        payload["graphs"].append(graph_record)

    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True))
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
