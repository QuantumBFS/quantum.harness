# Exact certificate supplement

This directory contains the finite, independently checkable part of the paper
**Stable Star Marginals and Low-Cyclomatic Certificates for Weighted Random Forests**.

## Files

- `certificates.json` - Wagner-form sum-of-squares signs for one representative
  of every automorphism orbit of unordered edge pairs in `K4`, `W4`, `K3,3`,
  and the triangular prism.
- `verify_certificates.py` - a standard-library-only exact verifier. It
  enumerates all forests, builds each Rayleigh difference over the integer
  polynomial ring, reconstructs the sum of squares, and checks coefficientwise
  equality. It also checks automorphism-orbit coverage.
- `generate_certificates.py` - an exhaustive sign search that reproduces
  `certificates.json`. It is a discovery/reproducibility utility, not part of
  the trusted proof implication. The largest local search space in this data
  set has only 4096 combinations.

Edge sets and cycles are encoded as bit masks over the listed edge order.
Polynomial coefficients are Python integers; no floating-point arithmetic is
used.

## Verify

```bash
python3 verify_certificates.py
```

The final lines should be

```text
VERIFIED 16 edge-pair orbits exactly; 4982 Rayleigh-difference monomials checked.
certificate_sha256=9d5fa9de66676e8876d625ebb7ad425a534467a48d28750724a37880761748eb
```

## Regenerate and re-verify

```bash
python3 generate_certificates.py --output certificates.regenerated.json
python3 verify_certificates.py certificates.regenerated.json
sha256sum certificates.json certificates.regenerated.json
```

The two SHA-256 digests should agree.

## Trust boundary

The verifier does not assume the claimed inequalities. It reconstructs both
sides of every polynomial identity directly from the graph definitions. The
manuscript separately proves direct-sum and proper 2-sum closure by explicit
polynomial calculation. The remaining external structural input for the
low-cyclomatic theorem is Tutte decomposition into 3-connected pieces, circuits,
and cocircuits.
