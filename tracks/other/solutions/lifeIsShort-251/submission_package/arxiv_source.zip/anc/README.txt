The ancillary Python script performs an exact finite regression test of the
differential-unrooting identity for every simple graph on at most five labelled
vertices and four labelled parallel-edge examples. It uses only integer
arithmetic and the Python standard library. The analytic proof is contained in
the paper; no theorem depends on this computation.
