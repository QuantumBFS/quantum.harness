#!/usr/bin/env python3
"""Exact finite regression test for the differential-unrooting identity.

This script uses only the Python standard library and integer arithmetic.  It
represents a monomial by

    (vertex_marker_mask, edge_exponent_tuple, q_exponent)

and compares, coefficient by coefficient, the two formal polynomials

    prod_{ij in E}(1 - q y_ij d_i d_j)
        sum_{F forest} y^F prod_C (q|C| + x(C))

and

    sum_{F forest} y^F prod_C (q + x(C)).

The test covers every simple graph on at most five labelled vertices and four
labelled multigraphs with parallel edges.  It is a regression test only; the
paper contains a complete analytic coefficient proof.
"""

from __future__ import annotations

import itertools
from collections import defaultdict
from collections.abc import Iterable
from typing import DefaultDict, Optional, TypeAlias

Edge: TypeAlias = tuple[int, int]
EdgeExponents: TypeAlias = tuple[int, ...]
Monomial: TypeAlias = tuple[int, EdgeExponents, int]
Polynomial: TypeAlias = DefaultDict[Monomial, int]


def forest_components(n: int, edges: list[Edge], edge_mask: int) -> Optional[list[list[int]]]:
    """Return vertex sets of components, or None if the selected edges cycle."""
    parent = list(range(n))

    def find(a: int) -> int:
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    def union(a: int, b: int) -> bool:
        ra, rb = find(a), find(b)
        if ra == rb:
            return False
        parent[ra] = rb
        return True

    for k, (u, v) in enumerate(edges):
        if (edge_mask >> k) & 1 and not union(u, v):
            return None

    components: DefaultDict[int, list[int]] = defaultdict(list)
    for u in range(n):
        components[find(u)].append(u)
    return list(components.values())


def add(poly: Polynomial, key: Monomial, coefficient: int) -> None:
    if coefficient == 0:
        return
    poly[key] += coefficient
    if poly[key] == 0:
        del poly[key]


def multiply_by_component_factor(
    poly: Polynomial,
    component: Iterable[int],
    q_coefficient: int,
) -> Polynomial:
    """Multiply by q_coefficient*q + sum_{u in component} x_u."""
    out: Polynomial = defaultdict(int)
    component_list = list(component)
    for (x_mask, y_exp, q_exp), coefficient in poly.items():
        add(out, (x_mask, y_exp, q_exp + 1), coefficient * q_coefficient)
        for u in component_list:
            add(out, (x_mask | (1 << u), y_exp, q_exp), coefficient)
    return out


def build_forest_polynomial(n: int, edges: list[Edge], rooted: bool) -> Polynomial:
    """Build the rooted (q|C|+x(C)) or unrooted (q+x(C)) polynomial."""
    m = len(edges)
    total: Polynomial = defaultdict(int)
    for edge_mask in range(1 << m):
        components = forest_components(n, edges, edge_mask)
        if components is None:
            continue
        y_exp = tuple(1 if (edge_mask >> k) & 1 else 0 for k in range(m))
        term: Polynomial = defaultdict(int)
        term[(0, y_exp, 0)] = 1
        for component in components:
            q_coefficient = len(component) if rooted else 1
            term = multiply_by_component_factor(term, component, q_coefficient)
        for key, coefficient in term.items():
            add(total, key, coefficient)
    return total


def apply_unrooting_factor(
    poly: Polynomial,
    edge_index: int,
    u: int,
    v: int,
) -> Polynomial:
    """Apply 1 - q*y_edge*d_u*d_v exactly to a multiaffine x-polynomial."""
    out: Polynomial = defaultdict(int)
    for key, coefficient in poly.items():
        add(out, key, coefficient)

    endpoint_bits = (1 << u) | (1 << v)
    for (x_mask, y_exp, q_exp), coefficient in poly.items():
        if x_mask & endpoint_bits != endpoint_bits:
            continue
        new_y_exp = list(y_exp)
        new_y_exp[edge_index] += 1
        add(
            out,
            (x_mask ^ endpoint_bits, tuple(new_y_exp), q_exp + 1),
            -coefficient,
        )
    return out


def verify_graph(n: int, edges: list[Edge]) -> bool:
    left = build_forest_polynomial(n, edges, rooted=True)
    for edge_index, (u, v) in enumerate(edges):
        left = apply_unrooting_factor(left, edge_index, u, v)
    right = build_forest_polynomial(n, edges, rooted=False)
    return dict(left) == dict(right)


def main() -> None:
    total_simple = 0
    for n in range(1, 6):
        possible_edges = list(itertools.combinations(range(n), 2))
        graph_count = 0
        for graph_mask in range(1 << len(possible_edges)):
            edges = [
                possible_edges[k]
                for k in range(len(possible_edges))
                if (graph_mask >> k) & 1
            ]
            if not verify_graph(n, edges):
                raise AssertionError(f"identity failed for n={n}, edges={edges!r}")
            graph_count += 1
        total_simple += graph_count
        print(f"simple n={n}: {graph_count} graphs verified")

    parallel_cases: list[list[Edge]] = [
        [(0, 1), (0, 1)],
        [(0, 1), (0, 1), (1, 2)],
        [(0, 1), (0, 1), (1, 2), (0, 2)],
        [(0, 1), (0, 1), (1, 2), (1, 2), (0, 2)],
    ]
    for edges in parallel_cases:
        n = 1 + max(max(edge) for edge in edges)
        if not verify_graph(n, edges):
            raise AssertionError(f"identity failed for multigraph edges={edges!r}")

    print(f"parallel multigraph cases: {len(parallel_cases)} verified")
    print(f"total simple graphs: {total_simple}")
    print("RESULT: PASS (exact integer coefficient comparison)")


if __name__ == "__main__":
    main()
