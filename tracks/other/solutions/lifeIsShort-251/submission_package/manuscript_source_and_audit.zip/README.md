# Manuscript source and audit materials

- `main.tex` — self-contained manuscript source.
- `audit/verify_unrooting_identity.py` — exact standard-library-only finite regression test.
- `audit/regression.log` — deterministic successful output.
- `audit/regression_resources.log` — recorded runtime/resource summary.
- `NOVELTY_AND_CLAIMS.md` — claim boundary and prior-art positioning.
- `REQUIRED_AUTHOR_ACTIONS.md` — actions the named author must personally complete.

The regression is diagnostic only. No theorem in the manuscript depends on computation.
